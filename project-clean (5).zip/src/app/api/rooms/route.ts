import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamelArr, toCamel } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const hotelId = searchParams.get('hotelId');

    let query = supabase
      .from('rooms')
      .select('*, inventory(*)')
      .order('date', { foreignTable: 'inventory', ascending: false })
      .order('created_at', { ascending: false });

    if (hotelId) {
      query = query.eq('hotel_id', hotelId);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Rooms list error:', error);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    const todayStr = new Date().toISOString().split('T')[0];

    const roomsWithInventory = toCamelArr(data || []).map((room: Record<string, unknown>) => {
      const inventory = toCamelArr((room.inventory as Record<string, unknown>[]) || []);
      const todayInventory = inventory.find((inv: Record<string, unknown>) => inv.date === todayStr);
      const latestInventory = inventory[0];
      const activeInventory = todayInventory || latestInventory;

      const { inventory: _inventory, ...roomData } = room;

      return {
        ...roomData,
        inventorySummary: activeInventory
          ? {
              date: activeInventory.date,
              totalRooms: activeInventory.totalRooms,
              availableRooms: activeInventory.availableRooms,
              soldRooms: activeInventory.soldRooms,
              blockedRooms: activeInventory.blockedRooms,
            }
          : null,
      };
    });

    return NextResponse.json(roomsWithInventory);
  } catch (error) {
    console.error('Rooms list error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

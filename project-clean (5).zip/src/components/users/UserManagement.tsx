'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { Role } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import {
  Users,
  Shield,
  Plus,
  MoreHorizontal,
  Edit,
  Trash2,
  Lock,
  Hotel,
  Building2,
  BarChart3,
  Settings,
  Wallet,
  CalendarCheck,
  UserCheck,
  LayoutDashboard,
  ClipboardList,
  UserCog,
  KeyRound,
  Copy,
  RefreshCw,
  Key,
} from 'lucide-react';

// ===================== TYPES =====================

interface ApiUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  hotelId?: string | null;
  partnerCode?: string | null;
  isActive: boolean;
  phone?: string | null;
  hotel?: { id: string; name: string } | null;
  createdAt?: string;
}

interface RoleDef {
  name: string;
  key: Role;
  description: string;
  icon: React.ElementType;
  permissions: Record<string, boolean>;
}

const ALL_PERMISSIONS = [
  'Dashboard', 'Hotels', 'Rooms', 'Bookings', 'Customers',
  'Reports', 'Settings', 'Finance',
];

const roleDefinitions: RoleDef[] = [
  {
    name: 'Super Admin', key: 'super_admin',
    description: 'Full system access with all permissions. Can manage all users, hotels, and platform settings.',
    icon: Shield,
    permissions: { Dashboard: true, Hotels: true, Rooms: true, Bookings: true, Customers: true, Reports: true, Settings: true, Finance: true },
  },
  {
    name: 'Sub Admin', key: 'sub_admin',
    description: 'Administrative access with most permissions. Cannot modify platform-level settings.',
    icon: UserCog,
    permissions: { Dashboard: true, Hotels: true, Rooms: true, Bookings: true, Customers: true, Reports: true, Settings: false, Finance: true },
  },
  {
    name: 'Finance', key: 'finance',
    description: 'Access to financial reports, commission management, and payout processing.',
    icon: Wallet,
    permissions: { Dashboard: true, Hotels: false, Rooms: false, Bookings: true, Customers: false, Reports: true, Settings: false, Finance: true },
  },
  {
    name: 'Support', key: 'support',
    description: 'Customer support access for handling queries, complaints, and booking issues.',
    icon: UserCheck,
    permissions: { Dashboard: true, Hotels: true, Rooms: false, Bookings: true, Customers: true, Reports: false, Settings: false, Finance: false },
  },
  {
    name: 'Hotel Owner', key: 'hotel_owner',
    description: 'Full access to their own hotel(s) including rooms, rates, bookings, and reports.',
    icon: Building2,
    permissions: { Dashboard: true, Hotels: true, Rooms: true, Bookings: true, Customers: true, Reports: true, Settings: true, Finance: false },
  },
  {
    name: 'Hotel Manager', key: 'hotel_manager',
    description: 'Day-to-day hotel operations including room management, check-ins, and staff coordination.',
    icon: Hotel,
    permissions: { Dashboard: true, Hotels: true, Rooms: true, Bookings: true, Customers: true, Reports: true, Settings: false, Finance: false },
  },
  {
    name: 'Reception', key: 'reception',
    description: 'Front desk operations including check-in/check-out, booking management, and guest services.',
    icon: CalendarCheck,
    permissions: { Dashboard: true, Hotels: false, Rooms: false, Bookings: true, Customers: true, Reports: false, Settings: false, Finance: false },
  },
  {
    name: 'Housekeeping', key: 'housekeeping',
    description: 'Room status management, cleaning schedules, and maintenance requests.',
    icon: ClipboardList,
    permissions: { Dashboard: true, Hotels: false, Rooms: true, Bookings: false, Customers: false, Reports: false, Settings: false, Finance: false },
  },
  {
    name: 'Accountant', key: 'accountant',
    description: 'Financial record keeping, invoice management, and revenue tracking for the hotel.',
    icon: KeyRound,
    permissions: { Dashboard: true, Hotels: false, Rooms: false, Bookings: true, Customers: false, Reports: true, Settings: false, Finance: true },
  },
];

const ROLE_BADGE_COLORS: Record<Role, string> = {
  super_admin: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  sub_admin: 'bg-teal-100 text-teal-700 border-teal-200',
  finance: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  support: 'bg-amber-100 text-amber-700 border-amber-200',
  hotel_owner: 'bg-purple-100 text-purple-700 border-purple-200',
  hotel_manager: 'bg-indigo-100 text-indigo-700 border-indigo-200',
  reception: 'bg-pink-100 text-pink-700 border-pink-200',
  housekeeping: 'bg-orange-100 text-orange-700 border-orange-200',
  accountant: 'bg-sky-100 text-sky-700 border-sky-200',
};

function roleLabel(role: Role): string {
  return roleDefinitions.find((r) => r.key === role)?.name ?? role;
}

const PARTNER_ROLES: Role[] = ['hotel_owner', 'hotel_manager', 'reception', 'housekeeping', 'accountant'];

// ===================== COMPONENT =====================

export default function UserManagement() {
  const { hotels } = useAppStore();

  const [users, setUsers] = useState<ApiUser[]>([]);
  const [loading, setLoading] = useState(true);

  // Add user dialog
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<Role>('reception');
  const [newHotel, setNewHotel] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [creating, setCreating] = useState(false);

  // Created partner code (shown after creation)
  const [createdCode, setCreatedCode] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      if (data.users) {
        setUsers(data.users);
      }
    } catch {
      toast.error('Failed to fetch users');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleAddUser = useCallback(async () => {
    if (!newName.trim() || !newEmail.trim() || !newPassword.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }
    setCreating(true);
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newName.trim(),
          email: newEmail.trim(),
          password: newPassword.trim(),
          role: newRole,
          hotelId: newHotel || null,
        }),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        toast.success(`User "${newName}" created successfully`);
        if (PARTNER_ROLES.includes(newRole) && data.user.partnerCode) {
          setCreatedCode(data.user.partnerCode);
        }
        setNewName('');
        setNewEmail('');
        setNewRole('reception');
        setNewHotel('');
        setNewPassword('');
        setAddUserOpen(false);
        fetchUsers();
      } else {
        toast.error(data.error || 'Failed to create user');
      }
    } catch {
      toast.error('Failed to create user');
    } finally {
      setCreating(false);
    }
  }, [newName, newEmail, newRole, newHotel, newPassword, fetchUsers]);

  const toggleUserStatus = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/users/toggle?id=${id}`, { method: 'PATCH' });
      const data = await res.json();
      if (res.ok) {
        setUsers((prev) =>
          prev.map((u) => (u.id === id ? { ...u, isActive: !u.isActive } : u))
        );
        toast.success('User status updated');
      } else {
        toast.error(data.error || 'Failed to update status');
      }
    } catch {
      toast.error('Failed to update user status');
    }
  }, []);

  const deleteUser = useCallback(async (id: string, name: string) => {
    try {
      const res = await fetch(`/api/users?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        setUsers((prev) => prev.filter((u) => u.id !== id));
        toast.success(`User "${name}" deleted`);
      } else {
        toast.error('Failed to delete user');
      }
    } catch {
      toast.error('Failed to delete user');
    }
  }, []);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('Partner code copied!');
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User & Role Management</h1>
          <p className="text-sm text-gray-500 mt-1">Manage platform users, roles, and permissions</p>
        </div>
        <Button
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
          onClick={() => setAddUserOpen(true)}
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Add User
        </Button>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="bg-gray-100 p-1">
          <TabsTrigger
            value="users"
            className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white"
          >
            <Users className="h-4 w-4 mr-1.5" />
            Users
          </TabsTrigger>
          <TabsTrigger
            value="roles"
            className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white"
          >
            <Shield className="h-4 w-4 mr-1.5" />
            Roles
          </TabsTrigger>
        </TabsList>

        {/* ========== Users Tab ========== */}
        <TabsContent value="users" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                {loading ? (
                  <div className="flex items-center justify-center py-12 text-gray-500">
                    <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                    Loading users...
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-b border-gray-100 hover:bg-transparent">
                        <TableHead className="font-semibold text-gray-600">Name</TableHead>
                        <TableHead className="font-semibold text-gray-600">Email</TableHead>
                        <TableHead className="font-semibold text-gray-600">Role</TableHead>
                        <TableHead className="font-semibold text-gray-600">Hotel</TableHead>
                        <TableHead className="font-semibold text-gray-600">Partner Code</TableHead>
                        <TableHead className="font-semibold text-gray-600">Status</TableHead>
                        <TableHead className="font-semibold text-gray-600 w-24">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                            No users found. Click "Add User" to create one.
                          </TableCell>
                        </TableRow>
                      ) : (
                        users.map((user) => (
                          <TableRow key={user.id} className="border-b border-gray-50">
                            <TableCell className="font-medium">{user.name}</TableCell>
                            <TableCell className="text-gray-600">{user.email}</TableCell>
                            <TableCell>
                              <Badge className={`${ROLE_BADGE_COLORS[user.role]} hover:${ROLE_BADGE_COLORS[user.role]}`}>
                                {roleLabel(user.role)}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-600">{user.hotel?.name ?? '—'}</TableCell>
                            <TableCell>
                              {user.partnerCode ? (
                                <div className="flex items-center gap-1">
                                  <code className="text-xs bg-gray-100 px-2 py-0.5 rounded font-mono text-emerald-700">
                                    {user.partnerCode}
                                  </code>
                                  <button
                                    onClick={() => copyCode(user.partnerCode!)}
                                    className="text-gray-400 hover:text-emerald-600 transition-colors"
                                    title="Copy code"
                                  >
                                    <Copy className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              ) : '—'}
                            </TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  user.isActive
                                    ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                    : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-100'
                                }
                              >
                                {user.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Switch
                                  checked={user.isActive}
                                  onCheckedChange={() => toggleUserStatus(user.id)}
                                  className="data-[state=checked]:bg-emerald-600"
                                />
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-red-400 hover:text-red-600 hover:bg-red-50"
                                  onClick={() => deleteUser(user.id, user.name)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== Roles Tab ========== */}
        <TabsContent value="roles" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {roleDefinitions.map((roleDef) => {
              const enabledCount = Object.values(roleDef.permissions).filter(Boolean).length;
              const RoleIcon = roleDef.icon;
              return (
                <Card key={roleDef.key} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-emerald-50">
                          <RoleIcon className="h-5 w-5 text-emerald-600" />
                        </div>
                        <div>
                          <CardTitle className="text-base font-semibold text-gray-800">
                            {roleDef.name}
                          </CardTitle>
                          <p className="text-xs text-emerald-600 font-medium">
                            {enabledCount}/{ALL_PERMISSIONS.length} permissions
                          </p>
                        </div>
                      </div>
                    </div>
                    <CardDescription className="mt-2 text-sm text-gray-500">
                      {roleDef.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {ALL_PERMISSIONS.map((perm) => (
                        <div key={perm} className="flex items-center gap-2">
                          <Checkbox
                            checked={roleDef.permissions[perm]}
                            disabled
                            className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                          />
                          <span
                            className={`text-xs ${
                              roleDef.permissions[perm] ? 'text-gray-700 font-medium' : 'text-gray-400'
                            }`}
                          >
                            {perm}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* ========== Add User Dialog ========== */}
      <Dialog open={addUserOpen} onOpenChange={(open) => { setAddUserOpen(open); if (!open) setCreatedCode(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Add New User</DialogTitle>
            <DialogDescription>Create a new user account on the platform</DialogDescription>
          </DialogHeader>

          {createdCode ? (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                  <Key className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">User Created Successfully!</h3>
                <p className="text-sm text-gray-500 mt-1">Share this partner code with the user</p>
              </div>
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-center">
                <p className="text-xs text-emerald-600 mb-1 font-medium">PARTNER CODE</p>
                <p className="text-2xl font-mono font-bold text-emerald-800 tracking-wider">{createdCode}</p>
              </div>
              <Button
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={() => copyCode(createdCode)}
              >
                <Copy className="h-4 w-4 mr-1.5" />
                Copy Partner Code
              </Button>
              <p className="text-xs text-center text-gray-500">
                The user will use this code when registering their hotel to link it to their account.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name <span className="text-red-500">*</span></Label>
                <Input
                  placeholder="Enter full name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Email Address <span className="text-red-500">*</span></Label>
                <Input
                  type="email"
                  placeholder="user@example.com"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Password <span className="text-red-500">*</span></Label>
                <Input
                  type="password"
                  placeholder="Set initial password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select value={newRole} onValueChange={(v) => setNewRole(v as Role)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roleDefinitions.map((rd) => (
                      <SelectItem key={rd.key} value={rd.key}>
                        {rd.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {PARTNER_ROLES.includes(newRole) && (
                <div className="space-y-2">
                  <Label>Assign Hotel (optional)</Label>
                  <Select value={newHotel} onValueChange={setNewHotel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a hotel..." />
                    </SelectTrigger>
                    <SelectContent>
                      {hotels
                        .filter((h) => h.status === 'approved')
                        .map((h) => (
                          <SelectItem key={h.id} value={h.id}>
                            {h.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {PARTNER_ROLES.includes(newRole) && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="text-xs text-amber-700">
                    <strong>Note:</strong> A unique partner code will be generated for this user after creation. The user can use this code when registering a hotel to link it to their account.
                  </p>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            {!createdCode && (
              <>
                <Button variant="outline" onClick={() => setAddUserOpen(false)}>
                  Cancel
                </Button>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  onClick={handleAddUser}
                  disabled={creating}
                >
                  <Plus className="h-4 w-4 mr-1.5" />
                  {creating ? 'Creating...' : 'Create User'}
                </Button>
              </>
            )}
            {createdCode && (
              <Button onClick={() => { setAddUserOpen(false); setCreatedCode(null); }}>
                Done
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import {
  Building2,
  MapPin,
  Phone,
  Star,
  FileText,
  CreditCard,
  Check,
  ChevronRight,
  ChevronLeft,
  Upload,
  ArrowRight,
  AlertCircle,
  Link2,
} from 'lucide-react';

const STEPS = [
  { number: 1, label: 'Business', icon: Building2 },
  { number: 2, label: 'Location', icon: MapPin },
  { number: 3, label: 'Contact', icon: Phone },
  { number: 4, label: 'Hotel Details', icon: Star },
  { number: 5, label: 'Documents', icon: FileText },
  { number: 6, label: 'Bank & Review', icon: CreditCard },
];

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
  'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu',
  'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry',
];

const AMENITIES = [
  'WiFi', 'Parking', 'Restaurant', 'Pool', 'Spa', 'Gym',
  'Room Service', 'Laundry', 'Airport Shuttle', 'Business Center',
  'Conference Room', 'Lounge', 'Bar', 'Garden', 'Terrace',
];

const LANGUAGES = ['English', 'Hindi', 'Regional'];

const BANKS = ['HDFC', 'ICICI', 'SBI', 'Axis', 'Kotak', 'PNB', 'BOB', 'Yes Bank', 'Other'];

const GST_STATE_CODES: Record<string, string> = {
  '27': 'Maharashtra', '29': 'Karnataka', '10': 'Bihar', '33': 'Tamil Nadu',
  '05': 'Uttar Pradesh', '07': 'Delhi', '03': 'Andhra Pradesh', '08': 'West Bengal',
  '09': 'Gujarat', '11': 'Sikkim', '12': 'Himachal Pradesh', '13': 'Arunachal Pradesh',
  '14': 'Goa', '15': 'Jammu and Kashmir', '16': 'Jharkhand', '17': 'Assam',
  '19': 'Chhattisgarh', '20': 'Madhya Pradesh', '22': 'Haryana',
  '24': 'Gujarat', '26': 'Karnataka', '28': 'Kerala', '30': 'Goa',
  '32': 'Manipur', '34': 'Puducherry', '36': 'Telangana', '37': 'Uttarakhand',
  '38': 'Uttarakhand', '39': 'West Bengal', '35': 'Andaman and Nicobar Islands',
};

interface FormData {
  // Step 1
  hotelName: string;
  legalName: string;
  gstNumber: string;
  ownerName: string;
  panNumber: string;
  businessType: string;
  partnerCode: string;
  // Step 2
  country: string;
  state: string;
  city: string;
  address: string;
  postalCode: string;
  // Step 3
  phone: string;
  email: string;
  website: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  // Step 4
  starRating: number;
  checkInTime: string;
  checkOutTime: string;
  description: string;
  amenities: string[];
  languages: string[];
  // Step 6
  bankName: string;
  accountName: string;
  accountNumber: string;
  ifscCode: string;
  upiId: string;
  agreeTerms: boolean;
}

const initialFormData: FormData = {
  hotelName: '',
  legalName: '',
  gstNumber: '',
  ownerName: '',
  panNumber: '',
  businessType: '',
  partnerCode: '',
  country: 'India',
  state: '',
  city: '',
  address: '',
  postalCode: '',
  phone: '',
  email: '',
  website: '',
  emergencyContactName: '',
  emergencyContactPhone: '',
  starRating: 0,
  checkInTime: '14:00',
  checkOutTime: '11:00',
  description: '',
  amenities: [],
  languages: [],
  bankName: '',
  accountName: '',
  accountNumber: '',
  ifscCode: '',
  upiId: '',
  agreeTerms: false,
};

export default function HotelRegistration() {
  const { user, setCurrentView, login } = useAppStore();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [warnings, setWarnings] = useState<Record<string, string>>({});

  const handleInput = useCallback((field: keyof FormData, value: string | number | boolean | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => prev[field] ? (() => { const n = { ...prev }; delete n[field]; return n; })() : prev);
    setWarnings((prev) => prev[field] ? (() => { const n = { ...prev }; delete n[field]; return n; })() : prev);
  }, []);

  const updateField = handleInput;

  const toggleAmenity = (amenity: string) => {
    setFormData((prev) => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter((a) => a !== amenity)
        : [...prev.amenities, amenity],
    }));
    clearFieldError('amenities');
  };

  const toggleLanguage = (lang: string) => {
    setFormData((prev) => ({
      ...prev,
      languages: prev.languages.includes(lang)
        ? prev.languages.filter((l) => l !== lang)
        : [...prev.languages, lang],
    }));
  };

  const clearFieldError = (field: string) => {
    setErrors((prev) => { const n = { ...prev }; delete n[field]; return n; });
    setWarnings((prev) => { const n = { ...prev }; delete n[field]; return n; });
  };

  const validateStep = (step: number): Record<string, string> => {
    const errs: Record<string, string> = {};
    if (step === 1) {
      if (!formData.hotelName.trim()) errs.hotelName = 'Hotel name is required';
      else if (formData.hotelName.trim().length < 3) errs.hotelName = 'Hotel name must be at least 3 characters';
      else if (!/^[A-Za-z0-9\s\-'/]+$/.test(formData.hotelName.trim())) errs.hotelName = 'Hotel name contains invalid characters';
      if (!formData.legalName.trim()) errs.legalName = 'Legal name is required';
      else if (formData.legalName.trim().length < 3) errs.legalName = 'Legal name must be at least 3 characters';
      if (formData.gstNumber.trim() && !/^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}$/.test(formData.gstNumber.trim().toUpperCase()))
        errs.gstNumber = 'Invalid GST format (e.g. 22AAAAA0000A1Z5)';
      if (!formData.ownerName.trim()) errs.ownerName = 'Owner name is required';
      else if (!/^[A-Za-z\s.]+$/.test(formData.ownerName.trim())) errs.ownerName = 'Owner name should only contain letters and spaces';
      else if (formData.ownerName.trim().length < 2) errs.ownerName = 'Owner name must be at least 2 characters';
      if (formData.panNumber.trim() && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(formData.panNumber.trim()))
        errs.panNumber = 'Invalid PAN format (e.g. ABCDE1234F)';
      if (!formData.businessType) errs.businessType = 'Please select a business type';
    }
    if (step === 2) {
      if (!formData.state) errs.state = 'State is required';
      if (!formData.city.trim()) errs.city = 'City is required';
      else if (formData.city.trim().length < 2) errs.city = 'City must be at least 2 characters';
      if (!formData.address.trim()) errs.address = 'Address is required';
      else if (formData.address.trim().length < 10) errs.address = 'Please enter a complete address (min 10 characters)';
      if (!formData.postalCode.trim()) errs.postalCode = 'Postal code is required';
      else if (!/^\d{6}$/.test(formData.postalCode.trim())) errs.postalCode = 'Postal code must be exactly 6 digits';
    }
    if (step === 3) {
      const phoneDigits = formData.phone.replace(/[^0-9]/g, '');
      if (!phoneDigits) errs.phone = 'Phone number is required';
      else if (!/^[6-9]\d{9}$/.test(phoneDigits)) errs.phone = 'Enter a valid 10-digit Indian mobile number';
      if (!formData.email.trim()) errs.email = 'Email is required';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) errs.email = 'Enter a valid email address';
      if (formData.website.trim() && !/^https?:\/\//.test(formData.website.trim()))
        errs.website = 'Website must start with http:// or https://';
      if (!formData.emergencyContactName.trim()) errs.emergencyContactName = 'Emergency contact name is required';
      const emPhoneDigits = formData.emergencyContactPhone.replace(/[^0-9]/g, '');
      if (!emPhoneDigits) errs.emergencyContactPhone = 'Emergency contact phone is required';
      else if (!/^[6-9]\d{9}$/.test(emPhoneDigits)) errs.emergencyContactPhone = 'Enter a valid 10-digit Indian mobile number';
    }
    if (step === 4) {
      if (formData.starRating === 0) errs.starRating = 'Please select a star rating';
      if (formData.amenities.length === 0) errs.amenities = 'Please select at least one amenity';
    }
    if (step === 6) {
      if (!formData.bankName) errs.bankName = 'Bank name is required';
      if (!formData.accountName.trim()) errs.accountName = 'Account name is required';
      if (!formData.accountNumber.trim()) errs.accountNumber = 'Account number is required';
      else if (!/^\d{9,18}$/.test(formData.accountNumber.trim())) errs.accountNumber = 'Account number must be 9-18 digits only';
      if (!formData.ifscCode.trim()) errs.ifscCode = 'IFSC code is required';
      else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(formData.ifscCode.trim())) errs.ifscCode = 'Invalid IFSC format (e.g. HDFC0001234)';
      if (formData.upiId.trim() && !/^[\w.\-]+@[\w]+$/.test(formData.upiId.trim()))
        errs.upiId = 'Invalid UPI format (e.g. hotel@upi)';
      if (!formData.agreeTerms) errs.agreeTerms = 'You must agree to the terms and conditions';
    }
    return errs;
  };

  const getStepWarnings = (step: number): Record<string, string> => {
    const w: Record<string, string> = {};
    if (step === 1) {
      if (formData.gstNumber.trim() && formData.state) {
        const gstCode = formData.gstNumber.trim().substring(0, 2);
        const gstState = GST_STATE_CODES[gstCode];
        if (gstState && gstState !== formData.state) w.gstNumber = `GST state code indicates ${gstState}, but you selected ${formData.state}`;
      }
      if (formData.panNumber.trim() && formData.ownerName.trim()) {
        const panInit = formData.panNumber.trim().substring(0, 4).toLowerCase();
        const lastName = formData.ownerName.trim().split(' ').pop()?.toLowerCase() || '';
        if (lastName.length >= 4 && !lastName.startsWith(panInit.substring(0, 3)))
          w.panNumber = 'PAN initials may not match owner name. Please verify.';
      }
    }
    if (step === 3) {
      const main = formData.phone.replace(/[^0-9]/g, '');
      const em = formData.emergencyContactPhone.replace(/[^0-9]/g, '');
      if (main && em && main === em) w.emergencyContactPhone = 'Emergency contact should be different from the main phone';
    }
    if (step === 6) {
      if (formData.accountName.trim() && (formData.ownerName.trim() || formData.legalName.trim())) {
        const acct = formData.accountName.trim().toLowerCase();
        const owner = formData.ownerName.trim().toLowerCase();
        const legal = formData.legalName.trim().toLowerCase();
        if (acct !== owner && acct !== legal && !owner.includes(acct) && !legal.includes(acct))
          w.accountName = 'Account name does not match owner name or legal name. Please verify.';
      }
    }
    return w;
  };

  const nextStep = () => {
    const stepErrors = validateStep(currentStep);
    const stepWarnings = getStepWarnings(currentStep);
    setWarnings(stepWarnings);
    if (Object.keys(stepErrors).length > 0) {
      setErrors(stepErrors);
      const firstKey = Object.keys(stepErrors)[0];
      document.getElementById(firstKey)?.focus();
      toast.error('Please fix the highlighted errors before proceeding');
      return;
    }
    setErrors({});
    if (Object.keys(stepWarnings).length > 0) toast.warning('Some warnings found. Review them or proceed.');
    setCurrentStep((s) => Math.min(s + 1, 6));
  };
  const prevStep = () => setCurrentStep((s) => Math.max(s - 1, 1));

  const handleSubmit = async () => {
    const stepErrors = validateStep(6);
    if (Object.keys(stepErrors).length > 0) {
      setErrors(stepErrors);
      toast.error('Please fix the errors before submitting');
      return;
    }
    if (!formData.agreeTerms) {
      toast.error('Please agree to the terms and conditions');
      return;
    }
    setIsLoading(true);
    try {
      const res = await fetch('/api/hotels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.hotelName,
          brand: formData.legalName,
          gst: formData.gstNumber,
          partnerCode: formData.partnerCode || null,
          ownerName: formData.ownerName,
          contactPerson: formData.ownerName,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          country: formData.country,
          pincode: formData.postalCode,
          description: formData.description,
          starRating: formData.starRating || 3,
          checkInTime: formData.checkInTime,
          checkOutTime: formData.checkOutTime,
          amenities: formData.amenities,
          languages: formData.languages,
          hasParking: formData.amenities.includes('Parking'),
          hasRestaurant: formData.amenities.includes('Restaurant'),
          hasPool: formData.amenities.includes('Swimming Pool'),
          hasSpa: formData.amenities.includes('Spa & Wellness'),
          hasWiFi: true,
          allowsPets: formData.amenities.includes('Pet Friendly'),
          userId: user?.id,
          bankName: formData.bankName,
          accountName: formData.accountName,
          accountNumber: formData.accountNumber,
          ifsc: formData.ifscCode,
          upiId: formData.upiId,
        }),
      });

      const data = await res.json();

      if (res.ok && data.hotel) {
        toast.success('Hotel registered successfully! It is now pending admin approval.');

        // Update the user's hotelId in the store so the partner can see their hotel
        if (user) {
          login({ ...user, hotelId: data.hotel.id });
        }

        // Navigate to partner dashboard
        setCurrentView('partner-dashboard');
      } else {
        toast.error(data.error || 'Registration failed. Please try again.');
      }
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const progressPercent = ((currentStep - 1) / 5) * 100;

  const errBorder = (f: string) => errors[f] ? 'border-red-400 focus-visible:ring-red-400' : '';
  const errMsg = (f: string) => errors[f] ? <p className="text-xs text-red-500 flex items-center gap-1 mt-1"><AlertCircle className="w-3 h-3 shrink-0"/>{errors[f]}</p> : null;
  const warnMsg = (f: string) => warnings[f] && !errors[f] ? <p className="text-xs text-amber-600 flex items-center gap-1 mt-1"><AlertCircle className="w-3 h-3 shrink-0"/>{warnings[f]}</p> : null;

  /* ------------------------------------------------------------------ */
  /*  Progress Stepper                                                   */
  /* ------------------------------------------------------------------ */
  const stepIndicator = () => {
    return (
      <div className="w-full mb-8">
        {/* Mobile: just a progress bar + step number + label */}
        <div className="md:hidden mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-emerald-700">
              Step {currentStep} of 6
            </span>
            <span className="text-sm text-muted-foreground">
              {STEPS[currentStep - 1].label}
            </span>
          </div>
          <Progress value={progressPercent} className="h-2 [&>div]:bg-emerald-500" />
        </div>

        {/* Desktop: full stepper */}
        <div className="hidden md:block">
          <Progress value={progressPercent} className="h-1.5 mb-6 [&>div]:bg-emerald-500" />
          <div className="flex items-center justify-between">
            {STEPS.map((step, idx) => {
              const isCompleted = currentStep > step.number;
              const isActive = currentStep === step.number;
              const Icon = step.icon;

              return (
                <div key={step.number} className="flex items-center flex-1 last:flex-none">
                  {/* Step circle + labels */}
                  <div className="flex flex-col items-center relative z-10">
                    <div
                      className={`
                        w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300
                        ${
                          isCompleted
                            ? 'bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                            : isActive
                              ? 'bg-emerald-50 border-emerald-500 text-emerald-600 shadow-md shadow-emerald-500/20'
                              : 'bg-white border-gray-300 text-gray-400'
                        }
                      `}
                    >
                      {isCompleted ? (
                        <Check className="w-5 h-5" />
                      ) : (
                        <Icon className="w-4.5 h-4.5" />
                      )}
                    </div>
                    <span
                      className={`
                        mt-2 text-xs font-medium transition-colors duration-300
                        ${isCompleted ? 'text-emerald-600' : isActive ? 'text-emerald-700' : 'text-gray-400'}
                      `}
                    >
                      {step.label}
                    </span>
                  </div>

                  {/* Connecting line */}
                  {idx < STEPS.length - 1 && (
                    <div className="flex-1 mx-2 relative -top-3">
                      <div
                        className={`
                          h-0.5 rounded-full transition-all duration-500
                          ${currentStep > step.number ? 'bg-emerald-500' : 'bg-gray-200'}
                        `}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 1 — Business Information                                      */
  /* ------------------------------------------------------------------ */
  const step1 = () => {
    return (
      <Card className="border-0 shadow-lg shadow-emerald-500/5">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Business Information</CardTitle>
              <CardDescription>Enter your hotel's legal & business details</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="hotelName">Hotel Name <span className="text-red-500">*</span></Label>
              <Input
                id="hotelName"
                placeholder="e.g. The Grand Palace"
                value={formData.hotelName}
                onChange={(e) => updateField('hotelName', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('hotelName')}`}
              />
              {errMsg('hotelName')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="legalName">Legal Name <span className="text-red-500">*</span></Label>
              <Input
                id="legalName"
                placeholder="Registered business name"
                value={formData.legalName}
                onChange={(e) => updateField('legalName', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('legalName')}`}
              />
              {errMsg('legalName')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="gstNumber">GST Number</Label>
              <Input
                id="gstNumber"
                placeholder="22AAAAA0000A1Z5"
                value={formData.gstNumber}
                onChange={(e) => updateField('gstNumber', e.target.value.toUpperCase())}
                className={`focus-visible:ring-emerald-500 ${errBorder('gstNumber')}`}
                maxLength={15}
              />
              {errMsg('gstNumber')}
              {warnMsg('gstNumber')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="ownerName">Owner Name <span className="text-red-500">*</span></Label>
              <Input
                id="ownerName"
                placeholder="Full name of owner"
                value={formData.ownerName}
                onChange={(e) => updateField('ownerName', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('ownerName')}`}
              />
              {errMsg('ownerName')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="panNumber">PAN Number</Label>
              <Input
                id="panNumber"
                placeholder="ABCDE1234F"
                value={formData.panNumber}
                onChange={(e) => updateField('panNumber', e.target.value.toUpperCase())}
                className={`focus-visible:ring-emerald-500 ${errBorder('panNumber')}`}
                maxLength={10}
              />
              {errMsg('panNumber')}
              {warnMsg('panNumber')}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="partnerCode">Partner Code</Label>
            <div className="relative">
              <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="partnerCode"
                placeholder="Enter partner code (e.g. PART-XXXXX)"
                value={formData.partnerCode}
                onChange={(e) => updateField('partnerCode', e.target.value.toUpperCase())}
                className={`pl-10 focus-visible:ring-emerald-500 ${errBorder('partnerCode')}`}
                maxLength={15}
              />
            </div>
            <p className="text-xs text-muted-foreground">If an admin created your account, enter the partner code provided to link your hotel.</p>
            {errMsg('partnerCode')}
          </div>
          <div className="space-y-2">
            <Label htmlFor="businessType">Business Type <span className="text-red-500">*</span></Label>
            <Select value={formData.businessType} onValueChange={(v) => updateField('businessType', v)}>
              <SelectTrigger id="businessType" className={`focus:ring-emerald-500 ${errBorder('businessType')}`}>
                <SelectValue placeholder="Select business type" />
              </SelectTrigger>
              <SelectContent>
                {['Individual', 'Partnership', 'LLP', 'Private Limited', 'Public Limited'].map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errMsg('businessType')}
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 2 — Location                                                  */
  /* ------------------------------------------------------------------ */
  const step2 = () => {
    return (
      <Card className="border-0 shadow-lg shadow-emerald-500/5">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Location</CardTitle>
              <CardDescription>Where is your hotel located?</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input id="country" value={formData.country} disabled className="bg-muted" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="state">State <span className="text-red-500">*</span></Label>
              <Select value={formData.state} onValueChange={(v) => updateField('state', v)}>
                <SelectTrigger id="state" className={`focus:ring-emerald-500 ${errBorder('state')}`}>
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {INDIAN_STATES.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errMsg('state')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City <span className="text-red-500">*</span></Label>
              <Input
                id="city"
                placeholder="e.g. Mumbai"
                value={formData.city}
                onChange={(e) => updateField('city', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('city')}`}
              />
              {errMsg('city')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="postalCode">Postal Code <span className="text-red-500">*</span></Label>
              <Input
                id="postalCode"
                placeholder="400001"
                value={formData.postalCode}
                onChange={(e) => updateField('postalCode', e.target.value.replace(/\D/g, ''))}
                className={`focus-visible:ring-emerald-500 ${errBorder('postalCode')}`}
                maxLength={6}
              />
              {errMsg('postalCode')}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Address <span className="text-red-500">*</span></Label>
            <Textarea
              id="address"
              placeholder="Full street address"
              value={formData.address}
              onChange={(e) => updateField('address', e.target.value)}
              className={`focus-visible:ring-emerald-500 min-h-[90px] ${errBorder('address')}`}
            />
            {errMsg('address')}
          </div>
          <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-700">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>Google Map integration coming soon. You'll be able to pin your exact location.</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 3 — Contact Information                                       */
  /* ------------------------------------------------------------------ */
  const step3 = () => {
    return (
      <Card className="border-0 shadow-lg shadow-emerald-500/5">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <Phone className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Contact Information</CardTitle>
              <CardDescription>How can guests and we reach you?</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone <span className="text-red-500">*</span></Label>
              <Input
                id="phone"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={(e) => updateField('phone', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('phone')}`}
              />
              {errMsg('phone')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email <span className="text-red-500">*</span></Label>
              <Input
                id="email"
                type="email"
                placeholder="hotel@example.com"
                value={formData.email}
                onChange={(e) => updateField('email', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('email')}`}
              />
              {errMsg('email')}
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                placeholder="https://www.yourhotel.com"
                value={formData.website}
                onChange={(e) => updateField('website', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('website')}`}
              />
              {errMsg('website')}
            </div>
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium text-muted-foreground mb-4">Emergency Contact</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="emergencyContactName">Emergency Contact Name <span className="text-red-500">*</span></Label>
                <Input
                  id="emergencyContactName"
                  placeholder="Full name"
                  value={formData.emergencyContactName}
                  onChange={(e) => updateField('emergencyContactName', e.target.value)}
                  className={`focus-visible:ring-emerald-500 ${errBorder('emergencyContactName')}`}
                />
                {errMsg('emergencyContactName')}
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyContactPhone">Emergency Contact Phone <span className="text-red-500">*</span></Label>
                <Input
                  id="emergencyContactPhone"
                  placeholder="+91 98765 43210"
                  value={formData.emergencyContactPhone}
                  onChange={(e) => updateField('emergencyContactPhone', e.target.value)}
                  className={`focus-visible:ring-emerald-500 ${errBorder('emergencyContactPhone')}`}
                />
                {errMsg('emergencyContactPhone')}
                {warnMsg('emergencyContactPhone')}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 4 — Hotel Details                                             */
  /* ------------------------------------------------------------------ */
  const step4 = () => {
    return (
      <Card className="border-0 shadow-lg shadow-emerald-500/5">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <Star className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Hotel Details</CardTitle>
              <CardDescription>Tell us about your hotel's features</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Star Rating */}
          <div className="space-y-2">
            <Label>Star Rating <span className="text-red-500">*</span></Label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => updateField('starRating', star)}
                  className="group transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-md p-0.5"
                >
                  <Star
                    className={`
                      w-8 h-8 transition-colors duration-200
                      ${star <= formData.starRating
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-gray-200 text-gray-200 group-hover:fill-amber-200 group-hover:text-amber-200'
                      }
                    `}
                  />
                </button>
              ))}
              {formData.starRating > 0 && (
                <span className="ml-2 text-sm font-medium text-emerald-700">
                  {formData.starRating} Star{formData.starRating > 1 ? 's' : ''}
                </span>
              )}
            </div>
            {errMsg('starRating')}
          </div>

          {/* Check-in / Check-out */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="checkInTime">Check-in Time</Label>
              <Input
                id="checkInTime"
                type="time"
                value={formData.checkInTime}
                onChange={(e) => updateField('checkInTime', e.target.value)}
                className="focus-visible:ring-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="checkOutTime">Check-out Time</Label>
              <Input
                id="checkOutTime"
                type="time"
                value={formData.checkOutTime}
                onChange={(e) => updateField('checkOutTime', e.target.value)}
                className="focus-visible:ring-emerald-500"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your hotel, its unique features, and what makes it special..."
              value={formData.description}
              onChange={(e) => updateField('description', e.target.value)}
              className="focus-visible:ring-emerald-500 min-h-[100px]"
            />
          </div>

          {/* Amenities */}
          <div className="space-y-3">
            <Label>Amenities <span className="text-red-500">*</span></Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {AMENITIES.map((amenity) => {
                const checked = formData.amenities.includes(amenity);
                return (
                  <label
                    key={amenity}
                    className={`
                      flex items-center gap-2.5 rounded-lg border px-3 py-2.5 text-sm cursor-pointer transition-all duration-200
                      ${checked
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700 shadow-sm'
                        : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                      }
                    `}
                  >
                    <Checkbox
                      checked={checked}
                      onCheckedChange={() => toggleAmenity(amenity)}
                      className="data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                    />
                    {amenity}
                  </label>
                );
              })}
            </div>
            {errMsg('amenities')}
          </div>

          {/* Languages */}
          <div className="space-y-3">
            <Label>Languages Spoken</Label>
            <div className="flex flex-wrap gap-3">
              {LANGUAGES.map((lang) => {
                const checked = formData.languages.includes(lang);
                return (
                  <label
                    key={lang}
                    className={`
                      flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm cursor-pointer transition-all duration-200
                      ${checked
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700 shadow-sm'
                        : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                      }
                    `}
                  >
                    <Checkbox
                      checked={checked}
                      onCheckedChange={() => toggleLanguage(lang)}
                      className="data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                    />
                    {lang}
                  </label>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 5 — Documents Upload                                          */
  /* ------------------------------------------------------------------ */
  const step5 = () => {
    const uploadItems = [
      { label: 'Business License', hint: 'PDF, JPG, PNG up to 5MB' },
      { label: 'GST Certificate', hint: 'PDF, JPG, PNG up to 5MB' },
      { label: 'Hotel Images', hint: 'JPG, PNG up to 5MB (multiple)', multiple: true },
      { label: 'Logo', hint: 'JPG, PNG up to 5MB' },
      { label: 'Owner ID Proof', hint: 'PDF, JPG, PNG up to 5MB' },
      { label: 'Bank Proof', hint: 'PDF, JPG, PNG up to 5MB' },
    ];

    return (
      <Card className="border-0 shadow-lg shadow-emerald-500/5">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">Documents Upload</CardTitle>
              <CardDescription>Upload required documents for verification</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {uploadItems.map((item) => (
              <label
                key={item.label}
                className="
                  group relative flex flex-col items-center justify-center gap-3
                  rounded-xl border-2 border-dashed border-gray-300
                  hover:border-emerald-400 hover:bg-emerald-50/40
                  cursor-pointer transition-all duration-200
                  p-6 min-h-[160px]
                "
              >
                <input type="file" className="sr-only" disabled={item.multiple} />
                {item.multiple && <input type="file" multiple className="sr-only" />}
                <div className="
                  w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center
                  group-hover:bg-emerald-100 transition-colors duration-200
                ">
                  <Upload className="w-5 h-5 text-emerald-500" />
                </div>
                <span className="text-sm font-medium text-gray-700 group-hover:text-emerald-700 transition-colors">
                  {item.label}
                </span>
                <span className="text-[11px] text-gray-400">Click to upload</span>
                <span className="text-[10px] text-gray-400">{item.hint}</span>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Step 6 — Bank Details & Review                                     */
  /* ------------------------------------------------------------------ */
  const step6 = () => {
    return (
      <div className="space-y-6">
        {/* Bank Details Card */}
        <Card className="border-0 shadow-lg shadow-emerald-500/5">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <CardTitle className="text-xl">Bank Details</CardTitle>
                <CardDescription>Payment information for settlements</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="bankName">Bank Name <span className="text-red-500">*</span></Label>
                <Select value={formData.bankName} onValueChange={(v) => updateField('bankName', v)}>
                  <SelectTrigger id="bankName" className={`focus:ring-emerald-500 ${errBorder('bankName')}`}>
                    <SelectValue placeholder="Select bank" />
                  </SelectTrigger>
                  <SelectContent>
                    {BANKS.map((b) => (
                      <SelectItem key={b} value={b}>{b}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errMsg('bankName')}
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountName">Account Name <span className="text-red-500">*</span></Label>
                <Input
                  id="accountName"
                  placeholder="Name on bank account"
                  value={formData.accountName}
                  onChange={(e) => updateField('accountName', e.target.value)}
                  className={`focus-visible:ring-emerald-500 ${errBorder('accountName')}`}
                />
                {errMsg('accountName')}
                {warnMsg('accountName')}
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number <span className="text-red-500">*</span></Label>
                <Input
                  id="accountNumber"
                  placeholder="Bank account number"
                  value={formData.accountNumber}
                  onChange={(e) => updateField('accountNumber', e.target.value.replace(/\D/g, ''))}
                  className={`focus-visible:ring-emerald-500 ${errBorder('accountNumber')}`}
                />
                {errMsg('accountNumber')}
              </div>
              <div className="space-y-2">
                <Label htmlFor="ifscCode">IFSC Code <span className="text-red-500">*</span></Label>
                <Input
                  id="ifscCode"
                  placeholder="e.g. HDFC0001234"
                  value={formData.ifscCode}
                  onChange={(e) => updateField('ifscCode', e.target.value.toUpperCase())}
                  className={`focus-visible:ring-emerald-500 ${errBorder('ifscCode')}`}
                  maxLength={11}
                />
                {errMsg('ifscCode')}
              </div>
            </div>
            <div className="max-w-md space-y-2">
              <Label htmlFor="upiId">UPI ID</Label>
              <Input
                id="upiId"
                placeholder="hotel@upi"
                value={formData.upiId}
                onChange={(e) => updateField('upiId', e.target.value)}
                className={`focus-visible:ring-emerald-500 ${errBorder('upiId')}`}
              />
              {errMsg('upiId')}
            </div>
          </CardContent>
        </Card>

        {/* Review Summary Card */}
        <Card className="border-0 shadow-lg shadow-emerald-500/5">
          <CardHeader className="pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <CardTitle className="text-xl">Review Your Application</CardTitle>
                <CardDescription>Please verify all details before submitting</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Business Info */}
              <ReviewSection title="Business Information" icon={<Building2 className="w-4 h-4" />}>
                <ReviewRow label="Hotel Name" value={formData.hotelName} />
                <ReviewRow label="Legal Name" value={formData.legalName} />
                <ReviewRow label="GST Number" value={formData.gstNumber} />
                <ReviewRow label="License Number" value={formData.licenseNumber} />
                <ReviewRow label="Owner Name" value={formData.ownerName} />
                <ReviewRow label="PAN Number" value={formData.panNumber} />
                <ReviewRow label="Business Type" value={formData.businessType} />
              </ReviewSection>

              {/* Location */}
              <ReviewSection title="Location" icon={<MapPin className="w-4 h-4" />}>
                <ReviewRow label="Country" value={formData.country} />
                <ReviewRow label="State" value={formData.state} />
                <ReviewRow label="City" value={formData.city} />
                <ReviewRow label="Address" value={formData.address} />
                <ReviewRow label="Postal Code" value={formData.postalCode} />
              </ReviewSection>

              {/* Contact */}
              <ReviewSection title="Contact Information" icon={<Phone className="w-4 h-4" />}>
                <ReviewRow label="Phone" value={formData.phone} />
                <ReviewRow label="Email" value={formData.email} />
                <ReviewRow label="Website" value={formData.website} />
                <ReviewRow label="Emergency Contact" value={`${formData.emergencyContactName} (${formData.emergencyContactPhone})`} />
              </ReviewSection>

              {/* Hotel Details */}
              <ReviewSection title="Hotel Details" icon={<Star className="w-4 h-4" />}>
                <ReviewRow
                  label="Star Rating"
                  value={formData.starRating > 0 ? `${'★'.repeat(formData.starRating)}` : 'Not set'}
                />
                <ReviewRow label="Check-in" value={formData.checkInTime} />
                <ReviewRow label="Check-out" value={formData.checkOutTime} />
                <ReviewRow label="Amenities" value={formData.amenities.length > 0 ? formData.amenities.join(', ') : 'None selected'} />
                <ReviewRow label="Languages" value={formData.languages.length > 0 ? formData.languages.join(', ') : 'None selected'} />
              </ReviewSection>

              {/* Bank Details */}
              <ReviewSection title="Bank Details" icon={<CreditCard className="w-4 h-4" />} className="md:col-span-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                  <ReviewRow label="Bank Name" value={formData.bankName} />
                  <ReviewRow label="Account Name" value={formData.accountName} />
                  <ReviewRow label="Account Number" value={formData.accountNumber} />
                  <ReviewRow label="IFSC Code" value={formData.ifscCode} />
                  <ReviewRow label="UPI ID" value={formData.upiId} />
                </div>
              </ReviewSection>
            </div>

            <Separator className="my-6" />

            {/* Terms */}
            <div className="flex items-start gap-3">
              <Checkbox
                id="agreeTerms"
                checked={formData.agreeTerms}
                onCheckedChange={(checked) => updateField('agreeTerms', checked === true)}
                className="data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500 mt-0.5"
              />
              <Label htmlFor="agreeTerms" className="text-sm leading-relaxed cursor-pointer">
                I agree to the{' '}
                <span className="text-emerald-600 font-medium underline underline-offset-2 hover:text-emerald-700 cursor-pointer">
                  terms and conditions
                </span>
              </Label>
            </div>
            {errMsg('agreeTerms')}
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Review helpers                                                     */
  /* ------------------------------------------------------------------ */
  function ReviewSection({
    title,
    icon,
    children,
    className = '',
  }: {
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    className?: string;
  }) {
    return (
      <div className={`rounded-lg border border-gray-200 bg-gray-50/50 p-4 ${className}`}>
        <div className="flex items-center gap-2 mb-3 text-emerald-700 font-semibold text-sm">
          {icon}
          {title}
        </div>
        <div className="space-y-1.5 text-sm">{children}</div>
      </div>
    );
  }

  function ReviewRow({ label, value }: { label: string; value: string }) {
    return (
      <div className="flex justify-between gap-4">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className="text-gray-900 font-medium text-right break-all">
          {value || <span className="text-gray-300 italic">Not provided</span>}
        </span>
      </div>
    );
  }

  /* ------------------------------------------------------------------ */
  /*  Main render                                                        */
  /* ------------------------------------------------------------------ */
  const renderStep = () => {
    switch (currentStep) {
      case 1: return step1();
      case 2: return step2();
      case 3: return step3();
      case 4: return step4();
      case 5: return step5();
      case 6: return step6();
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 flex items-start justify-center py-8 px-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
            REVYORA HOSPITALITY
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">Hotel Partner Registration</p>
        </div>

        {/* Step Indicator */}
        {stepIndicator()}

        {/* Step Content with animation */}
        <div
          key={currentStep}
          className="animate-in fade-in-0 slide-in-from-bottom-4 duration-400"
        >
          {renderStep()}
        </div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-6 px-1">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
            className="gap-2 border-gray-300 hover:bg-gray-50"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </Button>

          {currentStep < 6 ? (
            <Button
              onClick={nextStep}
              className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/25 transition-all duration-200 hover:shadow-lg hover:shadow-emerald-500/30"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isLoading}
              size="lg"
              className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/25 transition-all duration-200 hover:shadow-lg hover:shadow-emerald-500/30 px-8 text-base"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  Submit for Approval
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Hotel, Booking, PartnerDashboardStats } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  CalendarCheck,
  DollarSign,
  BedDouble,
  TrendingUp,
  Star,
  LogIn,
  LogOut,
  MessageSquare,
  ArrowUpRight,
  ArrowDownRight,
  Building2,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatShortDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

// ---------- zero chart data ----------

const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const bookingChartData = dayLabels.map((day) => ({
  name: day,
  bookings: 0,
}));

const revenueChartData = dayLabels.map((day) => ({
  name: day,
  revenue: 0,
}));

// ---------- component ----------

export default function PartnerDashboard() {
  const { user, setPartnerStats, setBookings, setCurrentHotel, partnerStats, bookings, currentHotel } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [hotel, setHotel] = useState<Hotel | null>(currentHotel);

  const hotelId = user?.hotelId;

  useEffect(() => {
    // If no hotelId, just stop loading and show zero-state
    if (!hotelId) {
      setLoading(false);
      setPartnerStats({
        todayBookings: 0,
        monthlyBookings: 0,
        revenue: 0,
        availableRooms: 0,
        occupancy: 0,
        upcomingCheckIns: 0,
        upcomingCheckOuts: 0,
        avgRating: 0,
        totalReviews: 0,
      });
      setBookings([]);
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch dashboard stats
        const dashRes = await fetch(`/api/partner/dashboard?hotelId=${hotelId}`);
        if (dashRes.ok) {
          const data = await dashRes.json();
          setPartnerStats(data);
        } else {
          setPartnerStats({
            todayBookings: 0, monthlyBookings: 0, revenue: 0,
            availableRooms: 0, occupancy: 0, upcomingCheckIns: 0,
            upcomingCheckOuts: 0, avgRating: 0, totalReviews: 0,
          });
        }

        // Fetch bookings
        const bookRes = await fetch(`/api/bookings?hotelId=${hotelId}`);
        if (bookRes.ok) {
          const data = await bookRes.json();
          setBookings(Array.isArray(data) ? data : []);
        } else {
          setBookings([]);
        }

        // Fetch hotel data
        const hotelRes = await fetch(`/api/hotels/${hotelId}`);
        if (hotelRes.ok) {
          const data = await hotelRes.json();
          setHotel(data);
          setCurrentHotel(data);
        }
      } catch (err) {
        console.error('Failed to fetch partner dashboard data:', err);
        setPartnerStats({
          todayBookings: 0, monthlyBookings: 0, revenue: 0,
          availableRooms: 0, occupancy: 0, upcomingCheckIns: 0,
          upcomingCheckOuts: 0, avgRating: 0, totalReviews: 0,
        });
        setBookings([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [hotelId, setPartnerStats, setBookings, setCurrentHotel]);

  const stats = partnerStats;

  // Filter upcoming check-ins and check-outs (next 3 days)
  const now = new Date();
  const threeDaysLater = new Date(now);
  threeDaysLater.setDate(threeDaysLater.getDate() + 3);

  const upcomingCheckIns = (bookings || [])
    .filter((b) => {
      if (b.status !== 'confirmed') return false;
      const checkIn = new Date(b.checkIn);
      return checkIn >= now && checkIn <= threeDaysLater;
    })
    .slice(0, 5);

  const upcomingCheckOuts = (bookings || [])
    .filter((b) => {
      if (b.status !== 'checked_in') return false;
      const checkOut = new Date(b.checkOut);
      return checkOut >= now && checkOut <= threeDaysLater;
    })
    .slice(0, 5);

  const renderStars = (rating: number) => (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-3.5 w-3.5 ${i < rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`}
        />
      ))}
    </div>
  );

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-40 w-full rounded-xl" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      </div>
    );
  }

  // Zero-state: no hotel assigned
  const hasNoHotel = !hotelId;

  return (
    <div className="p-6 space-y-6">
      {/* 1. Welcome Banner */}
      <Card className="border-0 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white overflow-hidden relative">
        <CardContent className="p-6 relative z-10">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold">Welcome back, {hotel?.name || user?.name || 'Partner'}!</h1>
              <div className="flex items-center gap-2 mt-1">
                {renderStars(hotel?.starRating || 0)}
                <span className="text-emerald-100 text-sm">
                  {hotel?.city ? `${hotel.city}, ${hotel.state}` : hasNoHotel ? 'No hotel assigned yet' : 'Your Hotel'}
                </span>
              </div>
            </div>
            <div className="flex gap-6 text-sm">
              <div className="text-center">
                <p className="text-2xl font-bold">{stats?.upcomingCheckIns ?? 0}</p>
                <p className="text-emerald-100">Check-ins Today</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{stats?.upcomingCheckOuts ?? 0}</p>
                <p className="text-emerald-100">Check-outs Today</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{stats?.avgRating?.toFixed(1) ?? '0.0'}</p>
                <p className="text-emerald-100">Avg Rating</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 2. KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Bookings */}
        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                <CalendarCheck className="h-5 w-5" />
              </div>
              <Badge className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
                <ArrowUpRight className="h-3 w-3" />
                0%
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stats?.todayBookings ?? 0}</p>
            <p className="text-sm text-muted-foreground">Today's Bookings</p>
          </CardContent>
        </Card>

        {/* Revenue */}
        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-teal-100 text-teal-700">
                <DollarSign className="h-5 w-5" />
              </div>
              <Badge className="bg-teal-50 text-teal-700 hover:bg-teal-100 border-teal-200">
                <ArrowUpRight className="h-3 w-3" />
                0%
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(stats?.revenue ?? 0)}</p>
            <p className="text-sm text-muted-foreground">Revenue</p>
          </CardContent>
        </Card>

        {/* Available Rooms */}
        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-cyan-100 text-cyan-700">
                <BedDouble className="h-5 w-5" />
              </div>
              <Badge className="bg-cyan-50 text-cyan-700 hover:bg-cyan-100 border-cyan-200">
                <ArrowDownRight className="h-3 w-3" />
                0
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stats?.availableRooms ?? 0}</p>
            <p className="text-sm text-muted-foreground">Available Rooms</p>
          </CardContent>
        </Card>

        {/* Occupancy Rate */}
        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
                <TrendingUp className="h-5 w-5" />
              </div>
              <Badge className="bg-amber-50 text-amber-700 hover:bg-amber-100 border-amber-200">
                <ArrowUpRight className="h-3 w-3" />
                0%
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stats?.occupancy ?? 0}%</p>
            <p className="text-sm text-muted-foreground">Occupancy Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* 3. Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bookings Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Bookings - Last 7 Days</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={bookingChartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="bookings" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} name="Bookings" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Revenue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Revenue - Last 7 Days</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={revenueChartData}>
                <defs>
                  <linearGradient id="emeraldRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(value: number) => [formatINR(value), 'Revenue']}
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#emeraldRevenue)"
                  name="Revenue"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* 4. Upcoming Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Check-ins */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <LogIn className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base">Upcoming Check-ins</CardTitle>
              <Badge variant="secondary" className="ml-auto">Next 3 Days</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingCheckIns.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No upcoming check-ins</p>
            ) : (
              <div className="space-y-3">
                {upcomingCheckIns.map((booking) => (
                  <div
                    key={booking.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div>
                      <p className="font-medium text-sm">{booking.customerName}</p>
                      <p className="text-xs text-muted-foreground">{booking.roomName || 'Room'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-emerald-700">{formatShortDate(booking.checkIn)}</p>
                      <p className="text-xs text-muted-foreground">{booking.bookingNumber}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Check-outs */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <LogOut className="h-5 w-5 text-teal-600" />
              <CardTitle className="text-base">Upcoming Check-outs</CardTitle>
              <Badge variant="secondary" className="ml-auto">Next 3 Days</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingCheckOuts.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No upcoming check-outs</p>
            ) : (
              <div className="space-y-3">
                {upcomingCheckOuts.map((booking) => (
                  <div
                    key={booking.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div>
                      <p className="font-medium text-sm">{booking.customerName}</p>
                      <p className="text-xs text-muted-foreground">{booking.roomName || 'Room'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-teal-700">{formatShortDate(booking.checkOut)}</p>
                      <p className="text-xs text-muted-foreground">{booking.bookingNumber}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 5. No Hotel Assigned Notice */}
      {hasNoHotel && (
        <Card className="border-dashed border-2 border-primary/30 bg-primary/5">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 rounded-full bg-primary/10">
              <Building2 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">No Hotel Assigned</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Your account is not linked to any hotel yet. Please contact the administrator to assign a hotel to your account.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

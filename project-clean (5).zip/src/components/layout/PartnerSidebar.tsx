'use client';

import { useAppStore } from '@/lib/store';
import type { ViewType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard,
  BedDouble,
  CalendarDays,
  Users,
  Bell,
  Settings,
  DollarSign,
  BarChart3,
  Megaphone,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Hotel,
  Image,
  Star,
  Package,
  Receipt,
} from 'lucide-react';

type NavItem = {
  icon: React.ElementType;
  label: string;
  view: ViewType;
  badge?: number;
};

type NavGroup = {
  title: string;
  items: NavItem[];
};

const navGroups: NavGroup[] = [
  {
    title: 'OVERVIEW',
    items: [
      { icon: LayoutDashboard, label: 'Dashboard', view: 'partner-dashboard' },
      { icon: BedDouble, label: 'My Rooms', view: 'partner-rooms' },
      { icon: CalendarDays, label: 'Bookings', view: 'partner-bookings' },
    ],
  },
  {
    title: 'MANAGEMENT',
    items: [
      { icon: Package, label: 'Inventory', view: 'partner-inventory' },
      { icon: DollarSign, label: 'Pricing', view: 'partner-pricing' },
      { icon: Users, label: 'Guests', view: 'partner-guests' },
    ],
  },
  {
    title: 'MARKETING',
    items: [
      { icon: Image, label: 'Gallery', view: 'partner-gallery' },
      { icon: Megaphone, label: 'Promotions', view: 'partner-promotions' },
      { icon: Star, label: 'Reviews', view: 'partner-reviews' },
    ],
  },
  {
    title: 'FINANCE',
    items: [
      { icon: Receipt, label: 'Financials', view: 'partner-financials' },
    ],
  },
  {
    title: 'OTHER',
    items: [
      { icon: Bell, label: 'Notifications', view: 'partner-notifications', badge: 3 },
      { icon: Settings, label: 'Settings', view: 'partner-settings' },
    ],
  },
];

export default function PartnerSidebar() {
  const { sidebarOpen, currentView, setCurrentView, user, logout, notifications } = useAppStore();

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const activeNavGroups = navGroups.map((group) => ({
    ...group,
    items: group.items.map((item) =>
      item.view === 'partner-notifications'
        ? { ...item, badge: unreadCount > 0 ? unreadCount : undefined }
        : item
    ),
  }));

  const handleNavClick = (view: ViewType) => {
    setCurrentView(view);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <aside
      className={`flex flex-col h-screen border-r border-border bg-sidebar transition-all duration-300 shadow-sm ${
        sidebarOpen ? 'w-64' : 'w-[72px]'
      }`}
    >
      {/* Branding */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-border shrink-0">
        <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary text-primary-foreground">
          <Hotel className="w-5 h-5" />
        </div>
        {sidebarOpen && (
          <div className="flex flex-col min-w-0">
            <span className="text-sm font-bold text-foreground tracking-wide truncate">
              REVYORA HOSPITALITY
            </span>
            <span className="text-[11px] text-muted-foreground truncate">
              Partner Portal
            </span>
          </div>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-2 py-4">
        <nav className="flex flex-col gap-1">
          {activeNavGroups.map((group) => (
            <div key={group.title} className="mb-3">
              {sidebarOpen && (
                <p className="px-3 mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  {group.title}
                </p>
              )}
              {!sidebarOpen && <Separator className="mb-2" />}
              {group.items.map((item) => {
                const isActive = currentView === item.view;
                const Icon = item.icon;

                if (sidebarOpen) {
                  return (
                    <Button
                      key={item.view}
                      variant="ghost"
                      className={`w-full justify-start gap-3 h-10 px-3 mb-0.5 font-normal border-l-2 ${
                        isActive
                          ? 'bg-primary/10 border-primary text-primary hover:bg-primary/15'
                          : 'border-transparent text-muted-foreground hover:bg-muted hover:text-foreground'
                      }`}
                      onClick={() => handleNavClick(item.view)}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-primary' : ''
                        }`}
                      />
                      <span className="truncate text-sm">{item.label}</span>
                      {item.badge !== undefined && item.badge > 0 && (
                        <Badge className="ml-auto h-5 min-w-5 px-1.5 text-[10px] bg-primary text-primary-foreground hover:bg-primary/90">
                          {item.badge}
                        </Badge>
                      )}
                    </Button>
                  );
                }

                return (
                  <Tooltip key={item.view} delayDuration={0}>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        className={`w-full justify-center h-10 px-0 mb-0.5 relative ${
                          isActive
                            ? 'bg-primary/10 text-primary hover:bg-primary/15'
                            : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                        }`}
                        onClick={() => handleNavClick(item.view)}
                      >
                        <Icon
                          className={`w-4 h-4 shrink-0 ${
                            isActive ? 'text-primary' : ''
                          }`}
                        />
                        {item.badge !== undefined && item.badge > 0 && (
                          <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-primary text-primary-foreground text-[9px] flex items-center justify-center font-medium">
                            {item.badge > 9 ? '9+' : item.badge}
                          </span>
                        )}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="font-medium">
                      {item.label}
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>
          ))}
        </nav>
      </ScrollArea>

      {/* User Info */}
      <div className="border-t border-border shrink-0">
        {sidebarOpen ? (
          <div className="px-3 py-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10 text-primary text-sm font-semibold shrink-0">
                {user?.name
                  ?.split(' ')
                  .map((n) => n[0])
                  .join('')
                  .toUpperCase()
                  .slice(0, 2) || 'HO'}
              </div>
              <div className="flex flex-col min-w-0 flex-1">
                <span className="text-sm font-medium text-foreground truncate">
                  {user?.name || 'Hotel Owner'}
                </span>
                <Badge
                  variant="secondary"
                  className="w-fit text-[10px] px-1.5 py-0 h-4 bg-primary/8 text-primary"
                >
                  {user?.role?.replace('_', ' ') || 'hotel_owner'}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-red-500 shrink-0"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 py-3 px-2">
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10 text-primary text-sm font-semibold cursor-default">
                  {user?.name
                    ?.split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()
                    .slice(0, 2) || 'HO'}
                </div>
              </TooltipTrigger>
              <TooltipContent side="right">{user?.name || 'Hotel Owner'}</TooltipContent>
            </Tooltip>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-red-500"
                  onClick={handleLogout}
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Logout</TooltipContent>
            </Tooltip>
          </div>
        )}

        {/* Collapse Toggle */}
        <Separator />
        <div className="flex justify-center py-2">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-full text-muted-foreground hover:text-foreground hover:bg-muted"
            onClick={() => useAppStore.getState().setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? (
              <>
                <ChevronLeft className="w-4 h-4 mr-2" />
                <span className="text-xs">Collapse</span>
              </>
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </aside>
  );
}

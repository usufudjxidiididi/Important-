'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from 'sonner';
import {
  HelpCircle,
  FileText,
  Gift,
  ImageIcon,
  PenLine,
  Megaphone,
  Plus,
  Edit,
  Trash2,
  Eye,
  Percent,
  CalendarDays,
} from 'lucide-react';

// ===================== MOCK DATA =====================

interface FAQ {
  id: string;
  question: string;
  answer: string;
  active: boolean;
}

interface Offer {
  id: string;
  title: string;
  description: string;
  discount: string;
  validFrom: string;
  validTo: string;
  active: boolean;
}

interface Banner {
  id: string;
  title: string;
  position: string;
  bgClass: string;
  active: boolean;
}

interface BlogPost {
  id: string;
  title: string;
  author: string;
  date: string;
  status: 'published' | 'draft' | 'archived';
}

interface Announcement {
  id: string;
  title: string;
  message: string;
  audience: string;
  date: string;
  status: 'active' | 'expired' | 'scheduled';
}

const initialFAQs: FAQ[] = [
  { id: '1', question: 'How do I make a booking?', answer: 'You can book a hotel through our website by searching for your destination, selecting dates, choosing a room, and completing the payment process. Bookings are confirmed instantly via email.', active: true },
  { id: '2', question: 'What is the cancellation policy?', answer: "Cancellations made 24 hours before check-in are fully refundable. Cancellations within 24 hours may incur a charge equivalent to one night's stay. Some special rate bookings are non-refundable.", active: true },
  { id: '3', question: 'Can I modify my booking dates?', answer: 'Yes, you can modify your booking dates through the booking management section or by contacting our support team. Date changes are subject to availability and rate differences.', active: true },
  { id: '4', question: 'What payment methods are accepted?', answer: 'We accept all major credit/debit cards, UPI, net banking, and popular wallets. Payments are processed securely through our payment partners.', active: true },
  { id: '5', question: 'How do I check-in to my hotel?', answer: 'Present your booking confirmation and valid ID at the hotel reception. Some hotels support express check-in through our mobile app.', active: false },
  { id: '6', question: 'Is there a loyalty program?', answer: 'Yes! You earn 100 loyalty points for every booking. Points can be redeemed for discounts on future bookings. Premium members get additional benefits like late check-out and room upgrades.', active: true },
];

const initialOffers: Offer[] = [
  { id: '1', title: 'Monsoon Madness', description: 'Get 30% off on all hill station hotels this monsoon season. Applicable on bookings made before August 31.', discount: '30%', validFrom: '2025-06-01', validTo: '2025-08-31', active: true },
  { id: '2', title: 'Weekend Getaway', description: 'Flat \u20B92000 off on weekend stays at premium hotels. Minimum 2-night stay required.', discount: '\u20B92000', validFrom: '2025-01-01', validTo: '2025-12-31', active: true },
  { id: '3', title: 'Early Bird Special', description: 'Book 14 days in advance and get 15% off. Valid for all room types across our partner hotels.', discount: '15%', validFrom: '2025-01-01', validTo: '2025-12-31', active: true },
  { id: '4', title: 'New User Welcome', description: 'First-time users get 25% off on their first booking. No minimum stay required.', discount: '25%', validFrom: '2025-01-01', validTo: '2025-12-31', active: false },
];

const initialBanners: Banner[] = [
  { id: '1', title: 'Summer Sale Hero Banner', position: 'Homepage Top', bgClass: 'bg-emerald-500', active: true },
  { id: '2', title: 'Beach Resort Collection', position: 'Homepage Middle', bgClass: 'bg-teal-500', active: true },
  { id: '3', title: 'Loyalty Program Launch', position: 'Sidebar', bgClass: 'bg-cyan-500', active: false },
  { id: '4', title: 'New Year Celebration', position: 'Homepage Top', bgClass: 'bg-amber-500', active: false },
];

const initialBlogs: BlogPost[] = [
  { id: '1', title: 'Top 10 Hill Stations to Visit This Monsoon', author: 'Travel Team', date: '2025-06-15', status: 'published' },
  { id: '2', title: 'A Guide to Choosing the Perfect Hotel', author: 'Editorial', date: '2025-06-10', status: 'published' },
  { id: '3', title: 'Heritage Hotels of Rajasthan', author: 'Travel Team', date: '2025-06-05', status: 'draft' },
  { id: '4', title: 'Sustainable Tourism: Our Commitment', author: 'Admin', date: '2025-05-28', status: 'published' },
  { id: '5', title: 'Beach Destinations Under \u20B95000/Night', author: 'Travel Team', date: '2025-05-20', status: 'archived' },
];

const initialAnnouncements: Announcement[] = [
  { id: '1', title: 'Platform Maintenance Window', message: 'Scheduled maintenance on July 20, 2025 from 2:00 AM to 4:00 AM IST. Services may be temporarily unavailable.', audience: 'All Users', date: '2025-07-18', status: 'scheduled' },
  { id: '2', title: 'New Payment Partner Integration', message: 'We have partnered with Razorpay for faster and more secure payment processing.', audience: 'Hotel Partners', date: '2025-07-10', status: 'active' },
  { id: '3', title: 'GST Update for Hotel Bookings', message: 'Updated GST rates effective from July 1, 2025. All invoices will reflect the revised rates.', audience: 'All Users', date: '2025-07-01', status: 'active' },
  { id: '4', title: 'Festive Season Commission Offer', message: 'Reduced commission rates during Diwali season. Contact your account manager for details.', audience: 'Hotel Partners', date: '2025-06-25', status: 'expired' },
];

// ===================== COMPONENT =====================

export default function CMSView() {
  const {} = useAppStore();

  const [faqs, setFaqs] = useState<FAQ[]>(initialFAQs);
  const [offers, setOffers] = useState<Offer[]>(initialOffers);
  const [banners, setBanners] = useState<Banner[]>(initialBanners);
  const [blogs] = useState<BlogPost[]>(initialBlogs);
  const [announcements] = useState<Announcement[]>(initialAnnouncements);

  const [faqDialogOpen, setFaqDialogOpen] = useState(false);
  const [faqQuestion, setFaqQuestion] = useState('');
  const [faqAnswer, setFaqAnswer] = useState('');

  const [offerDialogOpen, setOfferDialogOpen] = useState(false);

  const handleAddFaq = useCallback(() => {
    if (!faqQuestion.trim() || !faqAnswer.trim()) {
      toast.error('Please fill in both question and answer');
      return;
    }
    setFaqs((prev) => [
      ...prev,
      { id: String(Date.now()), question: faqQuestion, answer: faqAnswer, active: true },
    ]);
    setFaqQuestion('');
    setFaqAnswer('');
    setFaqDialogOpen(false);
    toast.success('FAQ added successfully');
  }, [faqQuestion, faqAnswer]);

  const toggleFaq = useCallback((id: string) => {
    setFaqs((prev) => prev.map((f) => (f.id === id ? { ...f, active: !f.active } : f)));
  }, []);

  const deleteFaq = useCallback((id: string) => {
    setFaqs((prev) => prev.filter((f) => f.id !== id));
    toast.success('FAQ deleted');
  }, []);

  const toggleOffer = useCallback((id: string) => {
    setOffers((prev) => prev.map((o) => (o.id === id ? { ...o, active: !o.active } : o)));
  }, []);

  const toggleBanner = useCallback((id: string) => {
    setBanners((prev) => prev.map((b) => (b.id === id ? { ...b, active: !b.active } : b)));
  }, []);

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Content Management</h1>
        <p className="text-sm text-gray-500 mt-1">Manage website content, FAQs, offers, and communications</p>
      </div>

      <Tabs defaultValue="faqs" className="w-full">
        <TabsList className="bg-gray-100 p-1 h-auto flex-wrap">
          <TabsTrigger value="faqs" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <HelpCircle className="h-4 w-4 mr-1.5" /> FAQs
          </TabsTrigger>
          <TabsTrigger value="terms" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <FileText className="h-4 w-4 mr-1.5" /> Terms & Policies
          </TabsTrigger>
          <TabsTrigger value="offers" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <Gift className="h-4 w-4 mr-1.5" /> Offers
          </TabsTrigger>
          <TabsTrigger value="banners" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <ImageIcon className="h-4 w-4 mr-1.5" /> Banners
          </TabsTrigger>
          <TabsTrigger value="blog" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <PenLine className="h-4 w-4 mr-1.5" /> Blog
          </TabsTrigger>
          <TabsTrigger value="announcements" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
            <Megaphone className="h-4 w-4 mr-1.5" /> Announcements
          </TabsTrigger>
        </TabsList>

        {/* FAQs Tab */}
        <TabsContent value="faqs" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => setFaqDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-1.5" /> Add FAQ
            </Button>
          </div>
          <Accordion type="multiple" className="space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={faq.id}
                value={faq.id}
                className="border rounded-lg px-4 data-[state=open]:border-emerald-200 data-[state=open]:bg-emerald-50/30"
              >
                <div className="flex items-center justify-between">
                  <AccordionTrigger className="flex-1 text-left hover:no-underline py-4">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-gray-400">#{index + 1}</span>
                      <span className="font-medium text-gray-800">{faq.question}</span>
                    </div>
                  </AccordionTrigger>
                  <div className="flex items-center gap-2 pr-2">
                    <Switch checked={faq.active} onCheckedChange={() => toggleFaq(faq.id)} className="data-[state=checked]:bg-emerald-600" />
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-400 hover:text-red-600 hover:bg-red-50" onClick={() => deleteFaq(faq.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <AccordionContent className="text-gray-600 pb-4 pl-8">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          {faqs.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-gray-400">
              <HelpCircle className="h-12 w-12 mb-3" />
              <p className="text-lg font-medium">No FAQs yet</p>
            </div>
          )}
        </TabsContent>

        {/* Terms Tab */}
        <TabsContent value="terms" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
                <FileText className="h-5 w-5 text-emerald-600" /> Terms of Service
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                defaultValue={'1. Acceptance of Terms\nBy accessing and using REVYORA HOSPITALITY, you agree to be bound by these Terms of Service.\n\n2. Booking Policy\nAll bookings are subject to availability and confirmation.\n\n3. Cancellation & Refund\nRefunds are processed within 5-7 business days.'}
                rows={12}
                className="resize-y"
              />
              <div className="flex justify-end mt-4">
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">Save Changes</Button>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
                <FileText className="h-5 w-5 text-teal-600" /> Privacy Policy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                defaultValue={'1. Information Collection\nWe collect personal information provided during registration, booking, and communication.\n\n2. Data Usage\nYour data is used to process bookings, improve services, and communicate important updates.'}
                rows={12}
                className="resize-y"
              />
              <div className="flex justify-end mt-4">
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Offers Tab */}
        <TabsContent value="offers" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => setOfferDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-1.5" /> Create Offer
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {offers.map((offer) => (
              <Card key={offer.id} className={offer.active ? 'border-0 shadow-sm transition-all' : 'border-0 shadow-sm transition-all opacity-60'}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base font-semibold text-gray-800">{offer.title}</CardTitle>
                    <Badge className={offer.active ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-gray-100 text-gray-600 border-gray-200'}>
                      {offer.active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-gray-600">{offer.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                      <Percent className="h-4 w-4" />
                      {offer.discount} off
                    </div>
                    <div className="flex items-center gap-1 text-gray-500">
                      <CalendarDays className="h-3.5 w-3.5" />
                      {offer.validFrom} - {offer.validTo}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                    <Switch checked={offer.active} onCheckedChange={() => toggleOffer(offer.id)} className="data-[state=checked]:bg-emerald-600" />
                    <span className="text-sm text-gray-600">{offer.active ? 'Enabled' : 'Disabled'}</span>
                    <div className="ml-auto flex gap-1">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0"><Edit className="h-4 w-4 text-gray-400" /></Button>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0"><Eye className="h-4 w-4 text-gray-400" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Banners Tab */}
        <TabsContent value="banners" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Banner</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Title</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Position</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Status</TableHead>
                    <TableHead className="text-right font-semibold text-gray-600 text-sm">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {banners.map((banner) => (
                    <TableRow key={banner.id}>
                      <TableCell>
                        <div className={banner.bgClass + ' w-20 h-10 rounded-md flex items-center justify-center'}>
                          <ImageIcon className="h-4 w-4 text-white" />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-sm">{banner.title}</TableCell>
                      <TableCell className="text-sm text-gray-600">{banner.position}</TableCell>
                      <TableCell>
                        <Switch checked={banner.active} onCheckedChange={() => toggleBanner(banner.id)} className="data-[state=checked]:bg-emerald-600" />
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 mr-1"><Edit className="h-4 w-4 text-gray-400" /></Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0"><Trash2 className="h-4 w-4 text-red-400" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Blog Tab */}
        <TabsContent value="blog" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Title</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Author</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Date</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Status</TableHead>
                    <TableHead className="text-right font-semibold text-gray-600 text-sm">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {blogs.map((post) => (
                    <TableRow key={post.id}>
                      <TableCell className="font-medium text-sm">{post.title}</TableCell>
                      <TableCell className="text-sm text-gray-600">{post.author}</TableCell>
                      <TableCell className="text-sm text-gray-600">{post.date}</TableCell>
                      <TableCell>
                        <Badge className={post.status === 'published' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : post.status === 'draft' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-gray-100 text-gray-600 border-gray-200'}>
                          {post.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 mr-1"><Eye className="h-4 w-4 text-gray-400" /></Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 mr-1"><Edit className="h-4 w-4 text-gray-400" /></Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0"><Trash2 className="h-4 w-4 text-red-400" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Announcements Tab */}
        <TabsContent value="announcements" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Title</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Message</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Audience</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Date</TableHead>
                    <TableHead className="text-left font-semibold text-gray-600 text-sm">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {announcements.map((ann) => (
                    <TableRow key={ann.id}>
                      <TableCell className="font-medium text-sm">{ann.title}</TableCell>
                      <TableCell className="text-sm text-gray-600 max-w-xs truncate">{ann.message}</TableCell>
                      <TableCell>
                        <Badge className="bg-teal-100 text-teal-700 border-teal-200">{ann.audience}</Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{ann.date}</TableCell>
                      <TableCell>
                        <Badge className={ann.status === 'active' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : ann.status === 'scheduled' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-gray-100 text-gray-500 border-gray-200'}>
                          {ann.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* FAQ Dialog */}
      <Dialog open={faqDialogOpen} onOpenChange={setFaqDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Add FAQ</DialogTitle>
            <DialogDescription>Add a new frequently asked question</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Question</Label>
              <Input placeholder="Enter the question..." value={faqQuestion} onChange={(e) => setFaqQuestion(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Answer</Label>
              <Textarea placeholder="Enter the answer..." value={faqAnswer} onChange={(e) => setFaqAnswer(e.target.value)} rows={4} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFaqDialogOpen(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleAddFaq}>Add FAQ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Offer Dialog */}
      <Dialog open={offerDialogOpen} onOpenChange={setOfferDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Create Offer</DialogTitle>
            <DialogDescription>Create a new promotional offer</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Offer Title</Label>
              <Input placeholder="e.g., Summer Sale" />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Offer details..." rows={3} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Discount</Label>
                <Input placeholder="e.g., 20%" />
              </div>
              <div className="space-y-2">
                <Label>Discount Type</Label>
                <Select>
                  <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage</SelectItem>
                    <SelectItem value="flat">Flat Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Valid From</Label>
                <Input type="date" />
              </div>
              <div className="space-y-2">
                <Label>Valid To</Label>
                <Input type="date" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOfferDialogOpen(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => { toast.success('Offer created'); setOfferDialogOpen(false); }}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
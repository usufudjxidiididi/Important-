'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Notification } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Calendar, CreditCard, Star, AlertTriangle, Settings, BarChart3,
  CheckCheck, Bell, Filter, BellOff, Inbox,
} from 'lucide-react';

const ICON_MAP = {
  booking: Calendar,
  payment: CreditCard,
  review: Star,
  alert: AlertTriangle,
  system: Settings,
  report: BarChart3,
} as const;

const COLOR_MAP: Record<string, string> = {
  booking: 'text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/30',
  payment: 'text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-900/30',
  review: 'text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30',
  alert: 'text-red-500 bg-red-100 dark:bg-red-900/30',
  system: 'text-violet-500 bg-violet-100 dark:bg-violet-900/30',
  report: 'text-cyan-600 dark:text-cyan-400 bg-cyan-100 dark:bg-cyan-900/30',
};

const FILTER_OPTIONS = ['all', 'unread', 'booking', 'payment', 'system'] as const;
type FilterType = (typeof FILTER_OPTIONS)[number];

function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks === 1) return '1 week ago';
  return `${weeks} weeks ago`;
}

function NotificationIcon({ type }: { type: Notification['type'] }) {
  const Icon = ICON_MAP[type] || Bell;
  return (
    <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${COLOR_MAP[type] || COLOR_MAP.system}`}>
      <Icon className="h-5 w-5" />
    </div>
  );
}

function NotificationSkeleton() {
  return (
    <div className="flex items-start gap-4 p-4">
      <Skeleton className="h-10 w-10 rounded-full" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-3 w-1/2" />
      </div>
      <Skeleton className="h-4 w-16" />
    </div>
  );
}

export default function NotificationsView() {
  const { notifications, setNotifications, markNotificationRead } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await fetch('/api/notifications');
        if (res.ok) {
          const data = await res.json();
          setNotifications(data);
        }
      } catch {
        // Silently handle
      } finally {
        setLoading(false);
      }
    };
    fetchNotifications();
  }, [setNotifications]);

  const filtered = notifications.filter((n) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'unread') return !n.isRead;
    return n.type === activeFilter;
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAllRead = () => {
 notifications.forEach((n) => {
   if (!n.isRead) markNotificationRead(n.id);
 });
  };

  const handleClick = (n: Notification) => {
    if (!n.isRead) markNotificationRead(n.id);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Bell className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
            Notifications
            {unreadCount > 0 && (
              <Badge className="bg-emerald-600 hover:bg-emerald-700 ml-2">{unreadCount} new</Badge>
            )}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">Stay updated with platform activities</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={handleMarkAllRead} className="gap-2">
            <CheckCheck className="h-4 w-4" />
            Mark all as read
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <Filter className="h-4 w-4 text-muted-foreground" />
        {FILTER_OPTIONS.map((f) => (
          <Button
            key={f}
            variant={activeFilter === f ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveFilter(f)}
            className={activeFilter === f ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </Button>
        ))}
      </div>

      {/* Notification List */}
      <ScrollArea className="flex-1">
        <div className="space-y-2">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}><CardContent className="p-0"><NotificationSkeleton /></CardContent></Card>
            ))
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <BellOff className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium">No notifications</h3>
              <p className="text-muted-foreground text-sm mt-1">
                {activeFilter === 'all'
                  ? 'You\'re all caught up!'
                  : `No ${activeFilter} notifications found.`}
              </p>
            </div>
          ) : (
            filtered.map((notification) => (
              <Card
                key={notification.id}
                className={`cursor-pointer transition-colors hover:bg-muted/50 ${!notification.isRead ? 'border-l-4 border-l-emerald-500' : ''}`}
                onClick={() => handleClick(notification)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <NotificationIcon type={notification.type} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className={`text-sm ${!notification.isRead ? 'font-semibold' : 'font-medium'}`}>
                          {notification.title}
                        </p>
                        {!notification.isRead && (
                          <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {notification.message}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-muted-foreground">{relativeTime(notification.createdAt)}</span>
                        <Badge variant="secondary" className="text-xs">
                          {notification.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

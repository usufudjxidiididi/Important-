'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Building2,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  Shield,
  Hotel,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

const ADMIN_ROLES = ['super_admin', 'sub_admin', 'finance', 'support'];

const features = [
  {
    icon: Building2,
    title: 'Multi-Property Management',
    desc: 'Manage all your hotels from a single dashboard',
  },
  {
    icon: Shield,
    title: 'Real-time Analytics',
    desc: 'Live insights into occupancy, revenue & performance',
  },
  {
    icon: Hotel,
    title: 'Seamless Bookings',
    desc: 'Streamlined reservation flow across all channels',
  },
  {
    icon: User,
    title: 'Revenue Optimization',
    desc: 'AI-powered pricing for maximum profitability',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15, delayChildren: 0.2 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (data && !data.error && data.user) {
        const user = data.user;

        // Check if user is active
        if (!user.isActive) {
          toast.error('Your account has been deactivated. Contact support.');
          setIsLoading(false);
          return;
        }

        // Route to correct dashboard based on role
        if (ADMIN_ROLES.includes(user.role)) {
          useAppStore.getState().login(user);
        } else {
          // Hotel roles (hotel_owner, hotel_manager, reception, etc.)
          useAppStore.getState().login({ ...user, role: 'hotel_owner' as const });
        }
      } else {
        // If no users exist, redirect to setup
        if (data.noUsers) {
          toast.error('No accounts found. Redirecting to setup...');
          setTimeout(() => { window.location.href = '/setup'; }, 1500);
        } else {
          toast.error(data.error || 'Invalid email or password.');
        }
      }
    } catch (err) {
      console.error('Login error:', err);
      toast.error('Cannot connect to server. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left Panel - Branding (stays dark for contrast) */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460]">
        {/* Decorative background shapes */}
        <div className="absolute inset-0">
          <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-[rgba(184,134,11,0.08)] blur-3xl" />
          <div className="absolute top-1/2 -right-32 h-[500px] w-[500px] rounded-full bg-[rgba(184,134,11,0.05)] blur-3xl" />
          <div className="absolute -bottom-24 left-1/3 h-72 w-72 rounded-full bg-[rgba(184,134,11,0.04)] blur-3xl" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.03)_0%,_transparent_70%)]" />
        </div>

        <motion.div
          className="relative z-10 flex flex-col justify-center px-16 xl:px-24 text-white"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Logo & Tagline */}
          <motion.div variants={itemVariants} className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[rgba(184,134,11,0.2)] backdrop-blur-sm border border-[rgba(184,134,11,0.35)]">
                <Building2 className="h-8 w-8 text-[#D4A843]" />
              </div>
              <span className="text-3xl font-bold tracking-tight">
                REVYORA <span className="text-[#D4A843]">HOSPITALITY</span>
              </span>
            </div>
            <p className="text-lg text-white/50 max-w-md leading-relaxed">
              Enterprise Hotel Management Platform
            </p>
          </motion.div>

          {/* Feature List */}
          <div className="space-y-5">
            {features.map((feature) => (
              <motion.div
                key={feature.title}
                variants={itemVariants}
                className="flex items-start gap-4 group"
              >
                <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[rgba(255,255,255,0.06)] backdrop-blur-sm border border-[rgba(255,255,255,0.1)] transition-colors group-hover:bg-[rgba(184,134,11,0.2)] group-hover:border-[rgba(184,134,11,0.3)]">
                  <feature.icon className="h-5 w-5 text-[#D4A843]" />
                </div>
                <div>
                  <h3 className="font-semibold text-white/90 text-[15px]">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-white/40 mt-0.5 leading-relaxed">
                    {feature.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Bottom accent */}
          <motion.div
            variants={itemVariants}
            className="mt-14 pt-8 border-t border-white/10"
          >
            <p className="text-sm text-white/25">
              Trusted by 2,000+ hotels worldwide
            </p>
          </motion.div>
        </motion.div>
      </div>

      {/* Right Panel - Form (light theme) */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-8 bg-[#FAFBFC]">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-2.5 justify-center mb-8">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
              <Building2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">
              REVYORA <span className="text-primary">HOSPITALITY</span>
            </span>
          </div>

          <Card className="border border-border bg-card shadow-xl shadow-black/5">
            <CardHeader className="text-center pb-2 pt-8 px-8">
              <CardTitle className="text-2xl font-bold text-foreground">
                Welcome back
              </CardTitle>
              <CardDescription className="text-muted-foreground mt-1.5">
                Sign in to your account to continue
              </CardDescription>
            </CardHeader>

            <CardContent className="px-8 pb-8 pt-4">
              <form onSubmit={handleLogin} className="space-y-5">
                {/* Email */}
                <div className="space-y-2">
                  <Label
                    htmlFor="email"
                    className="text-sm font-medium text-foreground"
                  >
                    Email address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="pl-10 h-11 bg-background border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary/20 transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-2">
                  <Label
                    htmlFor="password"
                    className="text-sm font-medium text-foreground"
                  >
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="pl-10 pr-10 h-11 bg-background border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary/20 transition-colors"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Login Button */}
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-sm transition-all hover:shadow-lg hover:shadow-primary/20 disabled:opacity-80"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <svg
                        className="animate-spin h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                        />
                      </svg>
                      Signing in…
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      Sign in
                    </span>
                  )}
                </Button>
              </form>

              {/* Setup link */}
              <div className="mt-4 text-center">
                <a
                  href="/setup"
                  className="text-xs text-primary hover:underline"
                >
                  First time? Click here to create admin account
                </a>
              </div>

              {/* Info hint */}
              <p className="mt-3 text-center text-xs text-muted-foreground leading-relaxed">
                Admin and hotel partner users are automatically routed to the correct panel.
              </p>
            </CardContent>
          </Card>

          {/* Footer */}
          <p className="mt-6 text-center text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} REVYORA HOSPITALITY. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Notification } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Bell,
  CalendarCheck,
  CreditCard,
  MessageSquare,
  AlertTriangle,
  Monitor,
  CheckCheck,
  Circle,
} from 'lucide-react';

// ---------- mock data ----------

const mockNotifications: Notification[] = [
  {
    id: 'n1',
    type: 'booking',
    title: 'New Booking Received',
    message: 'Rahul Sharma has booked a Deluxe Room for Jan 20-22, 2025. Booking #BK-2025-0145.',
    isRead: false,
    createdAt: '2025-01-18T10:30:00',
  },
  {
    id: 'n2',
    type: 'payment',
    title: 'Payment Received',
    message: 'Payment of ₹12,500 received for booking BK-2025-0142. Net payout: ₹10,625.',
    isRead: false,
    createdAt: '2025-01-18T09:15:00',
  },
  {
    id: 'n3',
    type: 'review',
    title: 'New Guest Review',
    message: 'Priya Mehta left a 5-star review: "Amazing stay! The staff was incredibly helpful."',
    isRead: true,
    createdAt: '2025-01-17T16:45:00',
  },
  {
    id: 'n4',
    type: 'alert',
    title: 'Low Availability Alert',
    message: 'Premium Suite has only 1 room available for the upcoming weekend (Jan 25-26).',
    isRead: false,
    createdAt: '2025-01-17T14:00:00',
  },
  {
    id: 'n5',
    type: 'system',
    title: 'Monthly Report Ready',
    message: 'Your December 2024 performance report is ready to view. Revenue: ₹18,50,000.',
    isRead: true,
    createdAt: '2025-01-15T08:00:00',
  },
];

// ---------- helpers ----------

function getNotificationIcon(type: Notification['type']) {
  switch (type) {
    case 'booking':
      return <CalendarCheck className="h-5 w-5 text-emerald-600" />;
    case 'payment':
      return <CreditCard className="h-5 w-5 text-teal-600" />;
    case 'review':
      return <MessageSquare className="h-5 w-5 text-amber-600" />;
    case 'alert':
      return <AlertTriangle className="h-5 w-5 text-rose-600" />;
    case 'system':
    default:
      return <Monitor className="h-5 w-5 text-slate-600" />;
  }
}

function formatTimestamp(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

// ---------- component ----------

export default function PartnerNotifications() {
  const { user, setNotifications, markNotificationRead } = useAppStore();
  const hotelId = user?.hotelId;

  const [notifications, setLocalNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    if (!hotelId) return;

    const fetchNotifications = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/notifications?hotelId=${hotelId}`);
        if (res.ok) {
          const data: Notification[] = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            setLocalNotifications(data);
            setNotifications(data);
          } else {
            setLocalNotifications(mockNotifications);
          }
        } else {
          setLocalNotifications(mockNotifications);
        }
      } catch {
        setLocalNotifications(mockNotifications);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, [hotelId, setNotifications]);

  const filtered = notifications.filter((n) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !n.isRead;
    if (activeTab === 'bookings') return n.type === 'booking' || n.type === 'payment';
    if (activeTab === 'system') return n.type === 'system' || n.type === 'alert';
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAllRead = () => {
    const updated = notifications.map((n) => ({ ...n, isRead: true }));
    setLocalNotifications(updated);
    setNotifications(updated);
  };

  const handleMarkRead = (id: string) => {
    const updated = notifications.map((n) =>
      n.id === id ? { ...n, isRead: true } : n
    );
    setLocalNotifications(updated);
    markNotificationRead(id);
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-10 w-40" />
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="h-6 w-6 text-emerald-600" />
          <h1 className="text-2xl font-bold">Notifications</h1>
          {unreadCount > 0 && (
            <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100 border-rose-200">
              {unreadCount} new
            </Badge>
          )}
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
            onClick={handleMarkAllRead}
          >
            <CheckCheck className="h-4 w-4 mr-2" />
            Mark all read
          </Button>
        )}
      </div>

      {/* Filter Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="unread" className="relative">
            Unread
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-rose-500" />
            )}
          </TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          <div className="space-y-3">
            {filtered.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Bell className="h-12 w-12 mx-auto text-muted-foreground/30" />
                  <p className="mt-3 text-muted-foreground">No notifications found.</p>
                </CardContent>
              </Card>
            ) : (
              filtered.map((notification) => (
                <Card
                  key={notification.id}
                  className={`transition-colors cursor-pointer hover:bg-muted/50 ${
                    !notification.isRead ? 'border-l-4 border-l-emerald-500 bg-emerald-50/30' : ''
                  }`}
                  onClick={() => {
                    if (!notification.isRead) handleMarkRead(notification.id);
                  }}
                >
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="mt-0.5">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className={`text-sm font-medium ${!notification.isRead ? 'font-semibold' : ''}`}>
                          {notification.title}
                        </h3>
                        {!notification.isRead && (
                          <Circle className="h-2 w-2 fill-emerald-500 text-emerald-500" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        {notification.message}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap mt-0.5">
                      {formatTimestamp(notification.createdAt)}
                    </span>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

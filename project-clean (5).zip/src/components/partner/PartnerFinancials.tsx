'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { toast } from 'sonner';
import {
  IndianRupee,
  TrendingUp,
  Clock,
  Receipt,
  Download,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '\u20b9' + value.toLocaleString('en-IN');
}

// ---------- mock data ----------

const revenueChartData = [
  { month: 'Aug', revenue: 485000 },
  { month: 'Sep', revenue: 520000 },
  { month: 'Oct', revenue: 610000 },
  { month: 'Nov', revenue: 575000 },
  { month: 'Dec', revenue: 720000 },
  { month: 'Jan', revenue: 680000 },
];

const mockPayments = [
  { id: 'p1', date: '2025-01-18', bookingNumber: 'BK-2025-0142', guest: 'Rahul Sharma', amount: 12500, commission: 1875, netPayout: 10625, status: 'paid' },
  { id: 'p2', date: '2025-01-17', bookingNumber: 'BK-2025-0141', guest: 'Priya Mehta', amount: 8400, commission: 1260, netPayout: 7140, status: 'paid' },
  { id: 'p3', date: '2025-01-16', bookingNumber: 'BK-2025-0140', guest: 'Amit Patel', amount: 22000, commission: 3300, netPayout: 18700, status: 'paid' },
  { id: 'p4', date: '2025-01-15', bookingNumber: 'BK-2025-0139', guest: 'Sneha Reddy', amount: 16800, commission: 2520, netPayout: 14280, status: 'pending' },
  { id: 'p5', date: '2025-01-14', bookingNumber: 'BK-2025-0138', guest: 'Vikram Singh', amount: 9500, commission: 1425, netPayout: 8075, status: 'paid' },
  { id: 'p6', date: '2025-01-13', bookingNumber: 'BK-2025-0137', guest: 'Ananya Gupta', amount: 32000, commission: 4800, netPayout: 27200, status: 'pending' },
  { id: 'p7', date: '2025-01-12', bookingNumber: 'BK-2025-0136', guest: 'Karthik Nair', amount: 11200, commission: 1680, netPayout: 9520, status: 'paid' },
  { id: 'p8', date: '2025-01-11', bookingNumber: 'BK-2025-0135', guest: 'Deepa Iyer', amount: 18500, commission: 2775, netPayout: 15725, status: 'paid' },
  { id: 'p9', date: '2025-01-10', bookingNumber: 'BK-2025-0134', guest: 'Rajesh Kumar', amount: 7800, commission: 1170, netPayout: 6630, status: 'pending' },
  { id: 'p10', date: '2025-01-09', bookingNumber: 'BK-2025-0133', guest: 'Meera Joshi', amount: 25000, commission: 3750, netPayout: 21250, status: 'paid' },
];

// ---------- component ----------

export default function PartnerFinancials() {
  const { user } = useAppStore();

  const summary = useMemo(() => {
    const totalRevenue = mockPayments.reduce((sum, p) => sum + p.amount, 0);
    const thisMonth = mockPayments
      .filter((p) => p.date.startsWith('2025-01'))
      .reduce((sum, p) => sum + p.amount, 0);
    const pendingPayouts = mockPayments
      .filter((p) => p.status === 'pending')
      .reduce((sum, p) => sum + p.netPayout, 0);
    const commissionPaid = mockPayments
      .filter((p) => p.status === 'paid')
      .reduce((sum, p) => sum + p.commission, 0);
    return { totalRevenue, thisMonth, pendingPayouts, commissionPaid };
  }, []);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <IndianRupee className="h-6 w-6 text-emerald-600" />
          <h1 className="text-2xl font-bold">Financials</h1>
        </div>
        <Button
          variant="outline"
          className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
          onClick={() => toast.info('Coming soon')}
        >
          <Download className="h-4 w-4 mr-2" />
          Download Statement
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                <TrendingUp className="h-5 w-5" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(summary.totalRevenue)}</p>
            <p className="text-sm text-muted-foreground">Total Revenue</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-teal-100 text-teal-700">
                <IndianRupee className="h-5 w-5" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(summary.thisMonth)}</p>
            <p className="text-sm text-muted-foreground">This Month Revenue</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
                <Clock className="h-5 w-5" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(summary.pendingPayouts)}</p>
            <p className="text-sm text-muted-foreground">Pending Payouts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-0">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-lg bg-rose-100 text-rose-700">
                <Receipt className="h-5 w-5" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(summary.commissionPaid)}</p>
            <p className="text-sm text-muted-foreground">Commission Paid</p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Revenue Trend — Last 6 Months</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={revenueChartData}>
              <defs>
                <linearGradient id="emeraldFinRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="month" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
              <YAxis
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                tickFormatter={(v) => `\u20b9${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip
                formatter={(value: number) => [formatINR(value), 'Revenue']}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#10b981"
                strokeWidth={2}
                fill="url(#emeraldFinRevenue)"
                name="Revenue"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Payment History Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Payment History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Booking #</TableHead>
                  <TableHead>Guest</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Commission</TableHead>
                  <TableHead className="text-right">Net Payout</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockPayments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>
                      {new Date(payment.date).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                      })}
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs text-emerald-700">
                        {payment.bookingNumber}
                      </span>
                    </TableCell>
                    <TableCell className="font-medium">{payment.guest}</TableCell>
                    <TableCell className="text-right">{formatINR(payment.amount)}</TableCell>
                    <TableCell className="text-right text-rose-600">
                      -{formatINR(payment.commission)}
                    </TableCell>
                    <TableCell className="text-right font-medium text-emerald-700">
                      {formatINR(payment.netPayout)}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge
                        className={
                          payment.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                            : 'bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200'
                        }
                      >
                        {payment.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

'use client';

import { useState, useMemo, useCallback, useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import type { Hotel, Room } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import {
  Search,
  MapPin,
  Calendar,
  Users,
  Star,
  BedDouble,
  Wifi,
  Car,
  UtensilsCrossed,
  Waves,
  Sparkles,
  ArrowRight,
  Loader2,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function generateBookingNumber(): string {
  const digits = Math.floor(10000 + Math.random() * 90000);
  return `BK-2026-${digits}`;
}

function getNights(checkIn: string, checkOut: string): number {
  const diff = new Date(checkOut).getTime() - new Date(checkIn).getTime();
  return Math.max(1, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

// ---------- popular destinations ----------

const POPULAR_DESTINATIONS = [
  { city: 'Mumbai', description: 'City of Dreams', gradient: 'from-emerald-400 to-teal-600', count: 120 },
  { city: 'Delhi', description: 'Capital Heritage', gradient: 'from-teal-500 to-cyan-600', count: 95 },
  { city: 'Bangalore', description: 'Silicon Valley of India', gradient: 'from-cyan-500 to-emerald-600', count: 88 },
  { city: 'Goa', description: 'Beach Paradise', gradient: 'from-emerald-500 to-lime-500', count: 75 },
  { city: 'Jaipur', description: 'Pink City Royalty', gradient: 'from-teal-400 to-emerald-700', count: 60 },
  { city: 'Udaipur', description: 'City of Lakes', gradient: 'from-cyan-600 to-teal-500', count: 45 },
];

const ROOM_TYPE_OPTIONS = [
  { label: 'All', value: 'all' },
  { label: 'Standard', value: 'Standard' },
  { label: 'Deluxe', value: 'Deluxe' },
  { label: 'Suite', value: 'Suite' },
  { label: 'Presidential', value: 'Presidential' },
];

// ---------- amenity icon helper ----------

function AmenityIcon({ name }: { name: string }) {
  const lower = name.toLowerCase();
  if (lower.includes('wifi') || lower.includes('internet')) return <Wifi className="h-3.5 w-3.5" />;
  if (lower.includes('parking') || lower.includes('car')) return <Car className="h-3.5 w-3.5" />;
  if (lower.includes('restaurant') || lower.includes('food') || lower.includes('dining')) return <UtensilsCrossed className="h-3.5 w-3.5" />;
  if (lower.includes('pool') || lower.includes('swim')) return <Waves className="h-3.5 w-3.5" />;
  if (lower.includes('bed') || lower.includes('king') || lower.includes('queen')) return <BedDouble className="h-3.5 w-3.5" />;
  return <Sparkles className="h-3.5 w-3.5" />;
}

// ---------- component ----------

export default function BookingEngine() {
  const { hotels } = useAppStore();

  // Search form state
  const [destination, setDestination] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('1');
  const [roomType, setRoomType] = useState('all');

  // Results state
  const [searchResults, setSearchResults] = useState<Hotel[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  // Rooms dialog state
  const [roomsDialogOpen, setRoomsDialogOpen] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [hotelRooms, setHotelRooms] = useState<Room[]>([]);
  const [roomsLoading, setRoomsLoading] = useState(false);

  // Booking form dialog state
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [bookingForm, setBookingForm] = useState({
    guestName: '',
    email: '',
    phone: '',
    specialRequests: '',
  });
  const [bookingLoading, setBookingLoading] = useState(false);

  // Set minimum dates
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  // Reset check-out when check-in changes
  useEffect(() => {
    if (checkIn && checkOut && checkOut <= checkIn) {
      setCheckOut('');
    }
  }, [checkIn, checkOut]);

  // Handle search
  const handleSearch = useCallback(async () => {
    if (!destination.trim()) {
      toast.error('Please enter a destination');
      return;
    }
    if (!checkIn || !checkOut) {
      toast.error('Please select check-in and check-out dates');
      return;
    }
    if (checkOut <= checkIn) {
      toast.error('Check-out must be after check-in');
      return;
    }

    try {
      setSearchLoading(true);
      const res = await fetch('/api/hotels');
      if (!res.ok) throw new Error('Failed to fetch hotels');
      const data: Hotel[] = await res.json();

      const city = destination.trim().toLowerCase();
      const filtered = data.filter(
        (h) =>
          h.city?.toLowerCase().includes(city) ||
          h.name.toLowerCase().includes(city) ||
          h.address?.toLowerCase().includes(city)
      );

      setSearchResults(filtered);
      setHasSearched(true);
    } catch {
      toast.error('Failed to search hotels');
    } finally {
      setSearchLoading(false);
    }
  }, [destination, checkIn, checkOut]);

  // Handle View Rooms
  const handleViewRooms = useCallback(async (hotel: Hotel) => {
    setSelectedHotel(hotel);
    setRoomsDialogOpen(true);
    setRoomsLoading(true);
    try {
      const res = await fetch('/api/rooms');
      if (!res.ok) throw new Error('Failed to fetch rooms');
      const allRooms: Room[] = await res.json();
      const hotelRoomsList = allRooms.filter((r) => r.hotelId === hotel.id);

      // Filter by room type if selected
      const filteredRooms = roomType === 'all'
        ? hotelRoomsList
        : hotelRoomsList.filter((r) => r.name.toLowerCase().includes(roomType.toLowerCase()));

      setHotelRooms(filteredRooms);
    } catch {
      toast.error('Failed to load rooms');
      setHotelRooms([]);
    } finally {
      setRoomsLoading(false);
    }
  }, [roomType]);

  // Handle Book Now
  const handleBookNow = useCallback((room: Room) => {
    setSelectedRoom(room);
    setBookingDialogOpen(true);
  }, []);

  // Handle Confirm Booking
  const handleConfirmBooking = useCallback(async () => {
    if (!selectedRoom || !selectedHotel || !checkIn || !checkOut) return;
    if (!bookingForm.guestName.trim() || !bookingForm.email.trim() || !bookingForm.phone.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    const nights = getNights(checkIn, checkOut);
    const totalAmount = selectedRoom.basePrice * nights;

    try {
      setBookingLoading(true);
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingNumber: generateBookingNumber(),
          hotelId: selectedHotel.id,
          roomId: selectedRoom.id,
          roomName: selectedRoom.name,
          customerName: bookingForm.guestName,
          customerEmail: bookingForm.email,
          customerPhone: bookingForm.phone,
          checkIn,
          checkOut,
          guests: parseInt(guests),
          adults: parseInt(guests),
          children: 0,
          totalAmount,
          commission: Math.round(totalAmount * 0.1),
          status: 'pending',
          paymentStatus: 'pending',
          specialRequests: bookingForm.specialRequests || undefined,
        }),
      });

      if (!res.ok) throw new Error('Failed to create booking');

      toast.success(`Booking confirmed! ${generateBookingNumber()} — ${formatINR(totalAmount)}`);
      setBookingDialogOpen(false);
      setBookingForm({ guestName: '', email: '', phone: '', specialRequests: '' });
    } catch {
      toast.error('Failed to create booking');
    } finally {
      setBookingLoading(false);
    }
  }, [selectedRoom, selectedHotel, checkIn, checkOut, guests, bookingForm]);

  // Get star rating
  const renderStars = (rating: number) =>
    Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-3.5 w-3.5 ${i < rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`}
      />
    ));

  // Parse hotel amenities to array
  const parseAmenities = (amenities?: string) => {
    if (!amenities) return [];
    try {
      return JSON.parse(amenities) as string[];
    } catch {
      return amenities.split(',').map((a) => a.trim()).filter(Boolean);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 text-white">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0djZoLTJ2LTZoMnptMC0xMHY2aC0ydi02aDJ6bTAtMTB2NmgtMlY0aDJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30" />
        <div className="relative max-w-5xl mx-auto px-4 py-16 sm:py-24 text-center">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-4 py-1.5 text-sm mb-6">
            <Sparkles className="h-4 w-4" />
            Discover 500+ Hotels Across India
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-4">
            Find Your Perfect Stay
          </h1>
          <p className="text-lg sm:text-xl text-emerald-100 max-w-2xl mx-auto">
            From luxury suites to cozy rooms — book the best hotels at unbeatable prices
          </p>
        </div>
      </section>

      {/* Search Form */}
      <section className="max-w-5xl mx-auto px-4 -mt-8 relative z-10">
        <Card className="shadow-xl border-0">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Destination */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Destination</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="City or hotel name"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              {/* Check-in */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Check-in</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="date"
                    min={today}
                    value={checkIn}
                    onChange={(e) => setCheckIn(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              {/* Check-out */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Check-out</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="date"
                    min={checkIn || today}
                    value={checkOut}
                    onChange={(e) => setCheckOut(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              {/* Guests */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Guests</Label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Select value={guests} onValueChange={setGuests}>
                    <SelectTrigger className="pl-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                        <SelectItem key={n} value={String(n)}>
                          {n} {n === 1 ? 'Guest' : 'Guests'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Room Type */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Room Type</Label>
                <Select value={roomType} onValueChange={setRoomType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ROOM_TYPE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleSearch}
              disabled={searchLoading}
              className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 text-white h-12 text-base font-semibold"
            >
              {searchLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Search Hotels
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        {!hasSearched ? (
          /* Popular Destinations */
          <div>
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Popular Destinations</h2>
              <p className="text-gray-500 mt-2">Explore trending cities for your next trip</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {POPULAR_DESTINATIONS.map((dest) => (
                <Card
                  key={dest.city}
                  className="group cursor-pointer overflow-hidden border-0 shadow-md hover:shadow-xl transition-all duration-300"
                  onClick={() => {
                    setDestination(dest.city);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                >
                  <div className={`h-44 bg-gradient-to-br ${dest.gradient} relative flex items-end`}>
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
                    <div className="relative p-5 text-white">
                      <h3 className="text-xl font-bold">{dest.city}</h3>
                      <p className="text-sm text-white/80">{dest.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{dest.count}+ hotels</span>
                      <span className="text-sm font-medium text-emerald-600 flex items-center gap-1 group-hover:gap-2 transition-all">
                        Explore <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          /* Search Results */
          <div>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900">
                {searchResults.length} hotel{searchResults.length !== 1 ? 's' : ''} found
                {destination && <span className="font-normal text-gray-500"> in {destination}</span>}
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                {checkIn && checkOut && (
                  <>{checkIn} — {checkOut} · {getNights(checkIn, checkOut)} night{getNights(checkIn, checkOut) !== 1 ? 's' : ''}</>
                )}
              </p>
            </div>

            {searchResults.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <Search className="h-12 w-12 mb-3" />
                <p className="text-lg font-medium text-gray-600">No hotels found</p>
                <p className="text-sm">Try a different destination or dates</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {searchResults.map((hotel) => {
                  const amenities = parseAmenities(hotel.amenities);
                  const cheapestRoom = 2999; // placeholder if no room data
                  return (
                    <Card key={hotel.id} className="overflow-hidden border-0 shadow-md hover:shadow-xl transition-shadow duration-300 group">
                      {/* Hotel Image Placeholder */}
                      <div className="h-48 bg-gradient-to-br from-emerald-100 to-teal-100 relative flex items-center justify-center">
                        <div className="text-center text-teal-400">
                          <svg className="h-12 w-12 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                          <p className="text-xs font-medium">Hotel Photo</p>
                        </div>
                        {hotel.avgRating != null && hotel.avgRating > 0 && (
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
                            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                            <span className="text-sm font-semibold text-gray-800">{hotel.avgRating.toFixed(1)}</span>
                          </div>
                        )}
                      </div>

                      <CardContent className="p-5">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-bold text-gray-900 text-lg truncate">{hotel.name}</h3>
                            <div className="flex items-center gap-1 mt-1">
                              {renderStars(hotel.starRating)}
                              <span className="text-xs text-gray-500 ml-1">
                                {hotel.city}{hotel.state ? `, ${hotel.state}` : ''}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Amenities Preview */}
                        {amenities.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-3">
                            {amenities.slice(0, 4).map((amenity, idx) => (
                              <Badge
                                key={idx}
                                variant="outline"
                                className="text-xs font-normal text-gray-500 border-gray-200 bg-gray-50 gap-1"
                              >
                                <AmenityIcon name={amenity} />
                                {amenity}
                              </Badge>
                            ))}
                            {amenities.length > 4 && (
                              <Badge variant="outline" className="text-xs font-normal text-gray-500 border-gray-200 bg-gray-50">
                                +{amenities.length - 4} more
                              </Badge>
                            )}
                          </div>
                        )}

                        {/* Price & CTA */}
                        <div className="flex items-end justify-between mt-4 pt-4 border-t border-gray-100">
                          <div>
                            <p className="text-xs text-gray-500">Starting from</p>
                            <p className="text-xl font-bold text-emerald-700">
                              From {formatINR(cheapestRoom)}
                              <span className="text-sm font-normal text-gray-500">/night</span>
                            </p>
                          </div>
                          <Button
                            onClick={() => handleViewRooms(hotel)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white"
                          >
                            View Rooms
                            <ArrowRight className="ml-1 h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Rooms Dialog */}
      <Dialog open={roomsDialogOpen} onOpenChange={setRoomsDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">
              {selectedHotel?.name ?? 'Hotel'} — Available Rooms
            </DialogTitle>
            <DialogDescription>
              {selectedHotel?.city}{selectedHotel?.state ? `, ${selectedHotel.state}` : ''}
              {checkIn && checkOut && (
                <span className="text-gray-500 ml-2">
                  · {getNights(checkIn, checkOut)} night{getNights(checkIn, checkOut) !== 1 ? 's' : ''}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          {roomsLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-emerald-600" />
              <span className="ml-2 text-gray-500">Loading rooms...</span>
            </div>
          ) : hotelRooms.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <BedDouble className="h-10 w-10 mx-auto mb-2" />
              <p className="font-medium text-gray-600">No rooms available</p>
              <p className="text-sm">Try different dates or room type</p>
            </div>
          ) : (
            <div className="space-y-4">
              {hotelRooms.map((room) => {
                const nights = checkIn && checkOut ? getNights(checkIn, checkOut) : 1;
                const total = room.basePrice * nights;
                const roomAmenities = parseAmenities(room.amenities);
                return (
                  <Card key={room.id} className="border border-gray-100 shadow-sm">
                    <CardContent className="p-5">
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                        <div className="flex-1 space-y-3">
                          <div>
                            <h4 className="font-semibold text-gray-900 text-lg">{room.name}</h4>
                            {room.description && (
                              <p className="text-sm text-gray-500 mt-0.5 line-clamp-2">{room.description}</p>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-3 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Users className="h-3.5 w-3.5" />
                              Up to {room.maxAdults + room.maxChildren} guests
                            </span>
                            <span className="flex items-center gap-1">
                              <BedDouble className="h-3.5 w-3.5" />
                              {room.bedType}
                            </span>
                            {room.roomSize && (
                              <span>{room.roomSize} sq ft</span>
                            )}
                          </div>

                          {roomAmenities.length > 0 && (
                            <div className="flex flex-wrap gap-1.5">
                              {roomAmenities.map((a, idx) => (
                                <Badge
                                  key={idx}
                                  variant="secondary"
                                  className="text-xs gap-1"
                                >
                                  <AmenityIcon name={a} />
                                  {a}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>

                        <div className="sm:text-right flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2">
                          <div>
                            <p className="text-xs text-gray-500">{formatINR(room.basePrice)}/night</p>
                            <p className="text-xl font-bold text-emerald-700">{formatINR(total)}</p>
                            {nights > 1 && <p className="text-xs text-gray-400">for {nights} nights</p>}
                          </div>
                          <Button
                            onClick={() => handleBookNow(room)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white"
                            size="sm"
                          >
                            Book Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Booking Form Dialog */}
      <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Complete Your Booking</DialogTitle>
            <DialogDescription>
              {selectedHotel?.name} — {selectedRoom?.name}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-5">
            {/* Booking Summary */}
            <div className="bg-emerald-50 rounded-xl p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Hotel</span>
                <span className="font-medium text-gray-900">{selectedHotel?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Room</span>
                <span className="font-medium text-gray-900">{selectedRoom?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Check-in</span>
                <span className="font-medium text-gray-900">{checkIn}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Check-out</span>
                <span className="font-medium text-gray-900">{checkOut}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Guests</span>
                <span className="font-medium text-gray-900">{guests}</span>
              </div>
              <div className="border-t border-emerald-200 pt-2 flex justify-between">
                <span className="text-gray-600">Nights</span>
                <span className="font-medium text-gray-900">
                  {checkIn && checkOut ? getNights(checkIn, checkOut) : 1}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Per Night</span>
                <span className="font-medium text-gray-900">{selectedRoom ? formatINR(selectedRoom.basePrice) : '—'}</span>
              </div>
              <div className="border-t border-emerald-200 pt-2 flex justify-between">
                <span className="font-semibold text-emerald-800">Total Amount</span>
                <span className="font-bold text-lg text-emerald-700">
                  {selectedRoom && checkIn && checkOut
                    ? formatINR(selectedRoom.basePrice * getNights(checkIn, checkOut))
                    : '—'}
                </span>
              </div>
            </div>

            {/* Guest Details Form */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="guestName">Full Name *</Label>
                <Input
                  id="guestName"
                  placeholder="John Doe"
                  value={bookingForm.guestName}
                  onChange={(e) => setBookingForm((f) => ({ ...f, guestName: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  value={bookingForm.email}
                  onChange={(e) => setBookingForm((f) => ({ ...f, email: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={bookingForm.phone}
                  onChange={(e) => setBookingForm((f) => ({ ...f, phone: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="specialRequests">Special Requests</Label>
                <textarea
                  id="specialRequests"
                  rows={3}
                  placeholder="Early check-in, extra pillows, dietary requirements..."
                  className="flex w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm placeholder:text-gray-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-500 resize-none"
                  value={bookingForm.specialRequests}
                  onChange={(e) => setBookingForm((f) => ({ ...f, specialRequests: e.target.value }))}
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0 pt-2">
            <Button
              variant="outline"
              onClick={() => setBookingDialogOpen(false)}
              className="border-gray-200"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmBooking}
              disabled={bookingLoading}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {bookingLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Confirm Booking'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

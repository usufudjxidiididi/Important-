import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamelArr } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const hotelId = searchParams.get('hotelId');

    let query = supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false });

    if (hotelId) {
      query = query.eq('hotel_id', hotelId);
    }

    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json(toCamelArr(data || []));
  } catch (error) {
    console.error('Notifications error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

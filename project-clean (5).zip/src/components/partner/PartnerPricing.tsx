'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Room, Coupon } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import {
  IndianRupee,
  Percent,
  Save,
  Tag,
  Calendar,
  Sparkles,
} from 'lucide-react';

// ---------- helpers ----------

function getNext14Days(): { date: Date; dayName: string; isWeekend: boolean }[] {
  const days: { date: Date; dayName: string; isWeekend: boolean }[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dayOfWeek = d.getDay();
    days.push({
      date: d,
      dayName: d.toLocaleDateString('en-IN', { weekday: 'short' }),
      isWeekend: dayOfWeek === 0 || dayOfWeek === 6,
    });
  }
  return days;
}

function formatINR(value: number): string {
  return '\u20b9' + value.toLocaleString('en-IN');
}

// ---------- component ----------

export default function PartnerPricing() {
  const { user, setRooms, setCoupons } = useAppStore();
  const hotelId = user?.hotelId;

  const [rooms, setLocalRooms] = useState<Room[]>([]);
  const [coupons, setLocalCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRoomId, setSelectedRoomId] = useState('');

  // Pricing rules
  const [rules, setRules] = useState({
    weekendMarkup: 20,
    seasonalMarkup: 15,
    holidayMarkup: 30,
    extraAdultFee: 500,
    extraChildFee: 300,
    minStay: 1,
    maxStay: 14,
    taxRate: 18,
  });

  // Editable prices per day
  const [dayPrices, setDayPrices] = useState<Record<string, number>>({});

  const next14 = useMemo(() => getNext14Days(), []);

  const selectedRoom = useMemo(
    () => rooms.find((r) => r.id === selectedRoomId),
    [rooms, selectedRoomId]
  );

  useEffect(() => {
    if (!hotelId) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const roomRes = await fetch(`/api/rooms?hotelId=${hotelId}`);
        if (roomRes.ok) {
          const data = await roomRes.json();
          const roomData = Array.isArray(data) ? data : [];
          setLocalRooms(roomData);
          setRooms(roomData);
          if (roomData.length > 0 && !selectedRoomId) {
            setSelectedRoomId(roomData[0].id);
          }
        }

        const couponRes = await fetch(`/api/coupons?hotelId=${hotelId}`);
        if (couponRes.ok) {
          const data = await couponRes.json();
          const couponData = Array.isArray(data) ? data : [];
          setLocalCoupons(couponData);
          setCoupons(couponData);
        }
      } catch (err) {
        console.error('Failed to fetch pricing data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [hotelId, setRooms, setCoupons, selectedRoomId]);

  const getBasePrice = (dateStr: string) => {
    if (dayPrices[dateStr] !== undefined) return dayPrices[dateStr];
    const base = selectedRoom?.basePrice || 3000;
    return base;
  };

  const getWeekendSurcharge = (dateStr: string, dayInfo: { isWeekend: boolean }) => {
    if (!dayInfo.isWeekend) return 0;
    const base = getBasePrice(dateStr);
    return Math.round((base * rules.weekendMarkup) / 100);
  };

  const getFinalPrice = (dateStr: string, dayInfo: { isWeekend: boolean }) => {
    const base = getBasePrice(dateStr);
    const surcharge = getWeekendSurcharge(dateStr, dayInfo);
    const subtotal = base + surcharge;
    const tax = Math.round((subtotal * rules.taxRate) / 100);
    return subtotal + tax;
  };

  const handlePriceChange = (dateStr: string, value: string) => {
    const num = parseInt(value) || 0;
    setDayPrices((prev) => ({ ...prev, [dateStr]: num }));
  };

  const handleSaveRules = () => {
    toast.success('Pricing rules saved');
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-96 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <IndianRupee className="h-6 w-6 text-emerald-600" />
        <h1 className="text-2xl font-bold">Pricing Management</h1>
      </div>

      {/* Room Selector */}
      <div className="flex items-center gap-3">
        <Label className="text-sm font-medium whitespace-nowrap">Select Room:</Label>
        <Select value={selectedRoomId} onValueChange={setSelectedRoomId}>
          <SelectTrigger className="w-72">
            <SelectValue placeholder="Select a room type" />
          </SelectTrigger>
          <SelectContent>
            {rooms.map((room) => (
              <SelectItem key={room.id} value={room.id}>
                {room.name} — {formatINR(room.basePrice)}/night
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Pricing Table (next 14 days) */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-emerald-600" />
            <CardTitle className="text-base">
              Daily Pricing — Next 14 Days
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Day</TableHead>
                  <TableHead className="w-32">Base Price</TableHead>
                  <TableHead className="text-center">Weekend Surcharge</TableHead>
                  <TableHead className="text-right">Final Price</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {next14.map((dayInfo) => {
                  const dateStr = dayInfo.date.toISOString().split('T')[0];
                  const basePrice = getBasePrice(dateStr);
                  const surcharge = getWeekendSurcharge(dateStr, dayInfo);
                  const finalPrice = getFinalPrice(dateStr, dayInfo);

                  return (
                    <TableRow
                      key={dateStr}
                      className={dayInfo.isWeekend ? 'bg-amber-50/50' : ''}
                    >
                      <TableCell className="font-medium">
                        {dayInfo.date.toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {dayInfo.dayName}
                          {dayInfo.isWeekend && (
                            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200 text-[10px]">
                              Weekend
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={basePrice}
                          onChange={(e) => handlePriceChange(dateStr, e.target.value)}
                          className="h-8 text-sm"
                        />
                      </TableCell>
                      <TableCell className="text-center">
                        {surcharge > 0 ? (
                          <span className="text-amber-600 font-medium">
                            +{formatINR(surcharge)}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-emerald-700">
                        {formatINR(finalPrice)}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
                          Active
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Pricing Rules */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base">Pricing Rules</CardTitle>
            </div>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={handleSaveRules}
            >
              <Save className="h-4 w-4 mr-2" />
              Save Rules
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Weekend Markup %</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={rules.weekendMarkup}
                  onChange={(e) =>
                    setRules({ ...rules, weekendMarkup: Number(e.target.value) })
                  }
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Seasonal Markup %</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={rules.seasonalMarkup}
                  onChange={(e) =>
                    setRules({ ...rules, seasonalMarkup: Number(e.target.value) })
                  }
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Holiday Markup %</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={rules.holidayMarkup}
                  onChange={(e) =>
                    setRules({ ...rules, holidayMarkup: Number(e.target.value) })
                  }
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Tax Rate %</Label>
              <div className="relative">
                <Input
                  type="number"
                  value={rules.taxRate}
                  onChange={(e) =>
                    setRules({ ...rules, taxRate: Number(e.target.value) })
                  }
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Extra Adult Fee</Label>
              <Input
                type="number"
                value={rules.extraAdultFee}
                onChange={(e) =>
                  setRules({ ...rules, extraAdultFee: Number(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Extra Child Fee</Label>
              <Input
                type="number"
                value={rules.extraChildFee}
                onChange={(e) =>
                  setRules({ ...rules, extraChildFee: Number(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Min Stay (nights)</Label>
              <Input
                type="number"
                value={rules.minStay}
                onChange={(e) =>
                  setRules({ ...rules, minStay: Number(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Max Stay (nights)</Label>
              <Input
                type="number"
                value={rules.maxStay}
                onChange={(e) =>
                  setRules({ ...rules, maxStay: Number(e.target.value) })
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Promo Codes Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Tag className="h-5 w-5 text-emerald-600" />
            <CardTitle className="text-base">Active Promo Codes</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {coupons.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              No active promo codes. Create one in the Promotions section.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Min Booking</TableHead>
                    <TableHead>Valid From</TableHead>
                    <TableHead>Valid Till</TableHead>
                    <TableHead className="text-center">Usage</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {coupons.map((coupon) => (
                    <TableRow key={coupon.id}>
                      <TableCell>
                        <code className="px-2 py-1 bg-muted rounded text-sm font-mono text-emerald-700">
                          {coupon.code}
                        </code>
                      </TableCell>
                      <TableCell>
                        {coupon.discountType === 'percentage'
                          ? `${coupon.discountValue}%`
                          : formatINR(coupon.discountValue)}
                      </TableCell>
                      <TableCell>{formatINR(coupon.minBooking)}</TableCell>
                      <TableCell>
                        {new Date(coupon.startDate).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </TableCell>
                      <TableCell>
                        {new Date(coupon.endDate).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </TableCell>
                      <TableCell className="text-center">
                        {coupon.usageCount}/{coupon.usageLimit || '\u221e'}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge
                          className={
                            coupon.status === 'active'
                              ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                              : 'bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200'
                          }
                        >
                          {coupon.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

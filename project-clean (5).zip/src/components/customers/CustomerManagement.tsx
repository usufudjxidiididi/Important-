'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { Booking } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  Users,
  UserPlus,
  Search,
  Loader2,
  Star,
  IndianRupee,
  Repeat,
  CalendarDays,
  Mail,
  Phone,
  Award,
} from 'lucide-react';

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

interface Customer {
  email: string;
  name: string;
  phone: string;
  totalBookings: number;
  totalSpent: number;
  lastStay: string;
  bookings: Booking[];
}

export default function CustomerManagement() {
  const { setBookings } = useAppStore();

  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Dialog state
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Fetch bookings and extract customers
  useEffect(() => {
    async function fetchBookings() {
      try {
        setLoading(true);
        const res = await fetch('/api/bookings');
        if (!res.ok) throw new Error('Failed to fetch bookings');
        const data: Booking[] = await res.json();
        setAllBookings(data);
        setBookings(data);

        // Extract unique customers by email
        const customerMap = new Map<string, Customer>();
        for (const b of data) {
          const existing = customerMap.get(b.customerEmail);
          if (existing) {
            existing.totalBookings += 1;
            existing.totalSpent += b.totalAmount;
            existing.bookings.push(b);
            if (new Date(b.checkIn) > new Date(existing.lastStay)) {
              existing.lastStay = b.checkIn;
            }
          } else {
            customerMap.set(b.customerEmail, {
              email: b.customerEmail,
              name: b.customerName,
              phone: b.customerPhone ?? '',
              totalBookings: 1,
              totalSpent: b.totalAmount,
              lastStay: b.checkIn,
              bookings: [b],
            });
          }
        }
        setCustomers(Array.from(customerMap.values()));
      } catch {
        toast.error('Failed to load customers');
      } finally {
        setLoading(false);
      }
    }
    fetchBookings();
  }, [setBookings]);

  // Filtered customers
  const filtered = useMemo(() => {
    if (!search.trim()) return customers;
    const q = search.toLowerCase();
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        (c.phone && c.phone.toLowerCase().includes(q))
    );
  }, [customers, search]);

  // Summary stats
  const summary = useMemo(() => {
    const now = new Date();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();

    const newThisMonth = customers.filter((c) => {
      const d = new Date(c.bookings[0]?.createdAt ?? c.lastStay);
      return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
    }).length;

    const totalSpent = customers.reduce((acc, c) => acc + c.totalSpent, 0);
    const avgBookingValue =
      customers.length > 0
        ? totalSpent / customers.reduce((acc, c) => acc + c.totalBookings, 0)
        : 0;

    const repeatCustomers = customers.filter((c) => c.totalBookings > 1).length;
    const repeatPercent =
      customers.length > 0 ? Math.round((repeatCustomers / customers.length) * 100) : 0;

    return {
      totalCustomers: customers.length,
      newThisMonth,
      avgBookingValue,
      repeatPercent,
    };
  }, [customers]);

  // Open customer details
  const handleViewCustomer = useCallback((customer: Customer) => {
    setSelectedCustomer(customer);
    setDetailsOpen(true);
  }, []);

  const summaryCards = [
    {
      label: 'Total Customers',
      value: summary.totalCustomers,
      icon: Users,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
    },
    {
      label: 'New This Month',
      value: summary.newThisMonth,
      icon: UserPlus,
      color: 'text-teal-600',
      bg: 'bg-teal-50',
    },
    {
      label: 'Avg Booking Value',
      value: formatINR(Math.round(summary.avgBookingValue)),
      icon: IndianRupee,
      color: 'text-cyan-600',
      bg: 'bg-cyan-50',
    },
    {
      label: 'Repeat Customers',
      value: `${summary.repeatPercent}%`,
      icon: Repeat,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
    },
  ];

  function getCustomerStatus(customer: Customer): { label: string; active: boolean } {
    const lastDate = new Date(customer.lastStay);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const isActive = lastDate >= thirtyDaysAgo;
    return { label: isActive ? 'Active' : 'Inactive', active: isActive };
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Customer Management</h1>
        <p className="text-sm text-gray-500 mt-1">View and manage your hotel guests and customers</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.label} className="border-0 shadow-sm">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`${card.bg} p-3 rounded-xl`}>
                <card.icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <div>
                <p className="text-sm text-gray-500">{card.label}</p>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Search */}
      <div className="relative w-full sm:w-80">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search by name, email, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Table */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-6 w-6 animate-spin text-emerald-600" />
              <span className="ml-2 text-gray-500">Loading customers...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <Users className="h-12 w-12 mb-3" />
              <p className="text-lg font-medium">No customers found</p>
              <p className="text-sm">Try adjusting your search</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-gray-100 hover:bg-transparent">
                    <TableHead className="font-semibold text-gray-600">Name</TableHead>
                    <TableHead className="font-semibold text-gray-600">Email</TableHead>
                    <TableHead className="font-semibold text-gray-600">Phone</TableHead>
                    <TableHead className="font-semibold text-gray-600 text-center">Bookings</TableHead>
                    <TableHead className="font-semibold text-gray-600 text-right">Total Spent</TableHead>
                    <TableHead className="font-semibold text-gray-600">Last Stay</TableHead>
                    <TableHead className="font-semibold text-gray-600">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((customer) => {
                    const status = getCustomerStatus(customer);
                    return (
                      <TableRow
                        key={customer.email}
                        className="border-b border-gray-50 cursor-pointer hover:bg-emerald-50/30"
                        onClick={() => handleViewCustomer(customer)}
                      >
                        <TableCell className="font-medium">{customer.name}</TableCell>
                        <TableCell className="text-gray-600">{customer.email}</TableCell>
                        <TableCell className="text-gray-600">{customer.phone || '—'}</TableCell>
                        <TableCell className="text-center font-semibold text-emerald-700">
                          {customer.totalBookings}
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {formatINR(customer.totalSpent)}
                        </TableCell>
                        <TableCell className="text-gray-600">
                          {formatDate(customer.lastStay)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={
                              status.active
                                ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-100'
                            }
                          >
                            {status.label}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Customer Profile</DialogTitle>
            <DialogDescription>Customer details and booking history</DialogDescription>
          </DialogHeader>
          {selectedCustomer && (
            <div className="space-y-6">
              {/* Profile Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-3 col-span-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                    <span className="text-lg font-bold text-emerald-700">
                      {selectedCustomer.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-lg">{selectedCustomer.name}</p>
                    <p className="text-sm text-gray-500">{selectedCustomer.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="h-4 w-4 text-emerald-600" />
                  {selectedCustomer.phone || 'No phone'}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="h-4 w-4 text-emerald-600" />
                  {selectedCustomer.email}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CalendarDays className="h-4 w-4 text-teal-600" />
                  Last Stay: {formatDate(selectedCustomer.lastStay)}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Award className="h-4 w-4 text-amber-500" />
                  Loyalty Points: {selectedCustomer.totalBookings * 100}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Star className="h-4 w-4 text-emerald-600" />
                  Total Spent: {formatINR(selectedCustomer.totalSpent)}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Repeat className="h-4 w-4 text-teal-600" />
                  Total Bookings: {selectedCustomer.totalBookings}
                </div>
              </div>

              {/* Booking History */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-3">Booking History</h3>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-emerald-50/50 hover:bg-emerald-50/50">
                        <TableHead className="text-xs font-semibold">Booking #</TableHead>
                        <TableHead className="text-xs font-semibold">Hotel</TableHead>
                        <TableHead className="text-xs font-semibold">Check-in</TableHead>
                        <TableHead className="text-xs font-semibold">Amount</TableHead>
                        <TableHead className="text-xs font-semibold">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedCustomer.bookings.map((b) => (
                        <TableRow key={b.id} className="border-b border-gray-50">
                          <TableCell className="font-medium text-emerald-700 text-sm">
                            {b.bookingNumber}
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {b.hotel?.name ?? '—'}
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {formatDate(b.checkIn)}
                          </TableCell>
                          <TableCell className="text-sm font-semibold">
                            {formatINR(b.totalAmount)}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                b.status === 'confirmed' || b.status === 'checked_out'
                                  ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100 text-xs'
                                  : b.status === 'cancelled'
                                  ? 'bg-red-100 text-red-700 border-red-200 hover:bg-red-100 text-xs'
                                  : 'bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100 text-xs'
                              }
                            >
                              {b.status.replace(/_/g, ' ')}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel } from '@/lib/supabase';

// PATCH /api/users/toggle?id=xxx — toggle user active status
export async function PATCH(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    // Fetch current user to get current is_active value
    const { data: current, error: findError } = await supabase
      .from('users')
      .select('is_active')
      .eq('id', id)
      .single();

    if (findError || !current) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const { data: updated, error: updateError } = await supabase
      .from('users')
      .update({ is_active: !current.is_active })
      .eq('id', id)
      .select()
      .single();

    if (updateError) {
      console.error('User toggle error:', updateError);
      return NextResponse.json({ error: 'Failed to toggle user status' }, { status: 500 });
    }

    return NextResponse.json({ user: toCamel<Record<string, unknown>>(updated) });
  } catch (error) {
    console.error('User toggle error:', error);
    return NextResponse.json({ error: 'Failed to toggle user status' }, { status: 500 });
  }
}

'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { Room } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from 'sonner';
import {
  Building2,
  BedDouble,
  SlidersHorizontal,
  Loader2,
  PackageSearch,
  CalendarDays,
} from 'lucide-react';

interface RoomRow extends Room {
  totalRooms: number;
  availableRooms: number;
  blockedRooms: number;
  soldRooms: number;
}

export default function RoomInventory() {
  const { hotels } = useAppStore();

  const [selectedHotelId, setSelectedHotelId] = useState<string>('');
  const [rooms, setRooms] = useState<RoomRow[]>([]);
  const [loading, setLoading] = useState(false);

  // Dialog state
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<RoomRow | null>(null);
  const [adjustDate, setAdjustDate] = useState('');
  const [adjustTotal, setAdjustTotal] = useState('');
  const [adjustAvailable, setAdjustAvailable] = useState('');
  const [adjustBlocked, setAdjustBlocked] = useState('');

  const approvedHotels = useMemo(
    () => hotels.filter((h) => h.status === 'approved'),
    [hotels]
  );

  // Fetch rooms when hotel selected
  useEffect(() => {
    if (!selectedHotelId) {
      setRooms([]);
      return;
    }
    async function fetchRooms() {
      try {
        setLoading(true);
        const res = await fetch(`/api/rooms?hotelId=${selectedHotelId}`);
        if (!res.ok) throw new Error('Failed to fetch rooms');
        const data: Room[] = await res.json();
        // Enrich with mock inventory numbers
        const enriched: RoomRow[] = data.map((r) => {
          const total = r.totalInventory ?? 10;
          const sold = Math.floor(Math.random() * (total * 0.6)) + 1;
          const blocked = Math.floor(Math.random() * 3);
          return {
            ...r,
            totalRooms: total,
            availableRooms: Math.max(0, total - sold - blocked),
            blockedRooms: blocked,
            soldRooms: sold,
          };
        });
        setRooms(enriched);
      } catch {
        toast.error('Failed to load rooms');
        setRooms([]);
      } finally {
        setLoading(false);
      }
    }
    fetchRooms();
  }, [selectedHotelId]);

  // Totals
  const totals = useMemo(() => {
    return rooms.reduce(
      (acc, r) => ({
        totalRooms: acc.totalRooms + r.totalRooms,
        availableRooms: acc.availableRooms + r.availableRooms,
        blockedRooms: acc.blockedRooms + r.blockedRooms,
        soldRooms: acc.soldRooms + r.soldRooms,
      }),
      { totalRooms: 0, availableRooms: 0, blockedRooms: 0, soldRooms: 0 }
    );
  }, [rooms]);

  // Open adjust dialog
  const handleAdjust = useCallback((room: RoomRow) => {
    setSelectedRoom(room);
    setAdjustDate('');
    setAdjustTotal(String(room.totalRooms));
    setAdjustAvailable(String(room.availableRooms));
    setAdjustBlocked(String(room.blockedRooms));
    setAdjustOpen(true);
  }, []);

  // Save adjust
  const handleSaveAdjust = useCallback(() => {
    if (!adjustDate) {
      toast.error('Please select a date');
      return;
    }
    if (!selectedRoom) return;
    // Update local state optimistically
    setRooms((prev) =>
      prev.map((r) =>
        r.id === selectedRoom.id
          ? {
              ...r,
              totalRooms: Number(adjustTotal) || r.totalRooms,
              availableRooms: Number(adjustAvailable) || r.availableRooms,
              blockedRooms: Number(adjustBlocked) || r.blockedRooms,
              soldRooms: r.totalRooms - (Number(adjustAvailable) || 0) - (Number(adjustBlocked) || 0),
            }
          : r
      )
    );
    toast.success('Updated');
    setAdjustOpen(false);
  }, [adjustDate, adjustTotal, adjustAvailable, adjustBlocked, selectedRoom]);

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Room Inventory Management</h1>
        <p className="text-sm text-gray-500 mt-1">Manage room availability and allocation across hotels</p>
      </div>

      {/* Hotel Selector */}
      <Card className="border-0 shadow-sm">
        <CardContent className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4">
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-emerald-600" />
            <Label className="font-medium text-gray-700">Select Hotel</Label>
          </div>
          <Select value={selectedHotelId} onValueChange={setSelectedHotelId}>
            <SelectTrigger className="w-full sm:w-80">
              <SelectValue placeholder="Choose a hotel..." />
            </SelectTrigger>
            <SelectContent>
              {approvedHotels.map((h) => (
                <SelectItem key={h.id} value={h.id}>
                  {h.name} — {h.city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          {!selectedHotelId ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <PackageSearch className="h-12 w-12 mb-3" />
              <p className="text-lg font-medium">Select a hotel to view rooms</p>
              <p className="text-sm">Choose a hotel from the dropdown above</p>
            </div>
          ) : loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-6 w-6 animate-spin text-emerald-600" />
              <span className="ml-2 text-gray-500">Loading rooms...</span>
            </div>
          ) : rooms.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <BedDouble className="h-12 w-12 mb-3" />
              <p className="text-lg font-medium">No rooms found</p>
              <p className="text-sm">This hotel has no rooms configured</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b border-gray-100 hover:bg-transparent">
                      <TableHead className="font-semibold text-gray-600">Room Name</TableHead>
                      <TableHead className="font-semibold text-gray-600">Hotel</TableHead>
                      <TableHead className="font-semibold text-gray-600 text-center">Total Rooms</TableHead>
                      <TableHead className="font-semibold text-gray-600 text-center">Available</TableHead>
                      <TableHead className="font-semibold text-gray-600 text-center">Blocked</TableHead>
                      <TableHead className="font-semibold text-gray-600 text-center">Sold</TableHead>
                      <TableHead className="font-semibold text-gray-600">Status</TableHead>
                      <TableHead className="font-semibold text-gray-600 w-28">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rooms.map((room) => {
                      const occupancy = room.totalRooms > 0 ? (room.soldRooms / room.totalRooms) * 100 : 0;
                      return (
                        <TableRow key={room.id} className="border-b border-gray-50">
                          <TableCell className="font-medium">{room.name}</TableCell>
                          <TableCell className="text-gray-600">
                            {approvedHotels.find((h) => h.id === room.hotelId)?.name ?? '—'}
                          </TableCell>
                          <TableCell className="text-center font-semibold">{room.totalRooms}</TableCell>
                          <TableCell className="text-center">
                            <span className="text-emerald-600 font-semibold">{room.availableRooms}</span>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="text-amber-600 font-semibold">{room.blockedRooms}</span>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="text-teal-600 font-semibold">{room.soldRooms}</span>
                          </TableCell>
                          <TableCell>
                            {occupancy >= 80 ? (
                              <Badge className="bg-red-100 text-red-700 border-red-200 hover:bg-red-100">
                                High Demand
                              </Badge>
                            ) : occupancy >= 50 ? (
                              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
                                Active
                              </Badge>
                            ) : (
                              <Badge className="bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-100">
                                Low Demand
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                              onClick={() => handleAdjust(room)}
                            >
                              <SlidersHorizontal className="h-4 w-4 mr-1" />
                              Adjust
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                  <TableFooter>
                    <TableRow className="bg-emerald-50/50 font-semibold border-t-2 border-emerald-200">
                      <TableCell className="text-emerald-800">Total</TableCell>
                      <TableCell />
                      <TableCell className="text-center text-emerald-800">{totals.totalRooms}</TableCell>
                      <TableCell className="text-center text-emerald-700">{totals.availableRooms}</TableCell>
                      <TableCell className="text-center text-amber-700">{totals.blockedRooms}</TableCell>
                      <TableCell className="text-center text-teal-700">{totals.soldRooms}</TableCell>
                      <TableCell colSpan={2} />
                    </TableRow>
                  </TableFooter>
                </Table>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Adjust Dialog */}
      <Dialog open={adjustOpen} onOpenChange={setAdjustOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Adjust Inventory</DialogTitle>
            <DialogDescription>
              Update room allocation for <span className="font-semibold text-emerald-700">{selectedRoom?.name}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-emerald-600" />
                Date
              </Label>
              <Input
                type="date"
                value={adjustDate}
                onChange={(e) => setAdjustDate(e.target.value)}
                className="border-emerald-200 focus-visible:ring-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label>Total Rooms</Label>
              <Input
                type="number"
                min={0}
                value={adjustTotal}
                onChange={(e) => setAdjustTotal(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-emerald-700">Available Rooms</Label>
              <Input
                type="number"
                min={0}
                value={adjustAvailable}
                onChange={(e) => setAdjustAvailable(e.target.value)}
                className="border-emerald-200 focus-visible:ring-emerald-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-amber-700">Blocked Rooms</Label>
              <Input
                type="number"
                min={0}
                value={adjustBlocked}
                onChange={(e) => setAdjustBlocked(e.target.value)}
                className="border-amber-200 focus-visible:ring-amber-500"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdjustOpen(false)}>
              Cancel
            </Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handleSaveAdjust}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
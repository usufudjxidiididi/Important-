'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Booking, BookingStatus } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  CalendarCheck,
  DollarSign,
  TrendingUp,
  XCircle,
  CheckCircle2,
  LogIn,
  LogOut,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

const statusConfig: Record<BookingStatus, { label: string; className: string }> = {
  pending: { label: 'Pending', className: 'bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200' },
  confirmed: { label: 'Confirmed', className: 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200' },
  checked_in: { label: 'Checked In', className: 'bg-teal-100 text-teal-700 hover:bg-teal-100 border-teal-200' },
  checked_out: { label: 'Checked Out', className: 'bg-slate-100 text-slate-700 hover:bg-slate-100 border-slate-200' },
  cancelled: { label: 'Cancelled', className: 'bg-red-100 text-red-700 hover:bg-red-100 border-red-200' },
  no_show: { label: 'No Show', className: 'bg-orange-100 text-orange-700 hover:bg-orange-100 border-orange-200' },
};

// ---------- component ----------

export default function PartnerBookings() {
  const { user, setBookings, bookings, updateBookingStatus } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  const hotelId = user?.hotelId;

  useEffect(() => {
    if (!hotelId) return;

    const fetchBookings = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/bookings?hotelId=${hotelId}`);
        if (res.ok) {
          const data = await res.json();
          setBookings(data);
        }
      } catch (err) {
        console.error('Failed to fetch bookings:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBookings();
  }, [hotelId, setBookings]);

  // Computed stats
  const today = new Date().toDateString();
  const todayBookings = bookings.filter((b) => new Date(b.createdAt).toDateString() === today).length;

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const monthlyRevenue = bookings
    .filter((b) => {
      const d = new Date(b.createdAt);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && b.paymentStatus === 'paid';
    })
    .reduce((sum, b) => sum + b.totalAmount, 0);

  const paidBookings = bookings.filter((b) => b.paymentStatus === 'paid');
  const avgBookingValue = paidBookings.length > 0 ? Math.round(paidBookings.reduce((s, b) => s + b.totalAmount, 0) / paidBookings.length) : 0;

  const totalBookings = bookings.length;
  const cancelledCount = bookings.filter((b) => b.status === 'cancelled').length;
  const cancellationRate = totalBookings > 0 ? ((cancelledCount / totalBookings) * 100).toFixed(1) : '0';

  // Filter by tab
  const filteredBookings =
    activeTab === 'all'
      ? bookings
      : bookings.filter((b) => b.status === activeTab);

  const handleAction = async (bookingId: string, newStatus: BookingStatus) => {
    try {
      const res = await fetch(`/api/bookings`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: bookingId, status: newStatus }),
      });

      if (res.ok) {
        updateBookingStatus(bookingId, newStatus);
        const actionLabels: Record<string, string> = {
          confirmed: 'Booking accepted',
          cancelled: 'Booking rejected',
          checked_in: 'Guest checked in',
          checked_out: 'Guest checked out',
        };
        toast.success(actionLabels[newStatus] || 'Booking updated');
      } else {
        // Optimistic update anyway for demo
        updateBookingStatus(bookingId, newStatus);
        const actionLabels: Record<string, string> = {
          confirmed: 'Booking accepted',
          cancelled: 'Booking rejected',
          checked_in: 'Guest checked in',
          checked_out: 'Guest checked out',
        };
        toast.success(actionLabels[newStatus] || 'Booking updated');
      }
    } catch (err) {
      console.error('Failed to update booking:', err);
      toast.error('Failed to update booking. Please try again.');
    }
  };

  const renderStatusBadge = (status: BookingStatus) => {
    const config = statusConfig[status];
    return (
      <Badge className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const renderActions = (booking: Booking) => {
    switch (booking.status) {
      case 'pending':
        return (
          <div className="flex gap-1">
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs text-emerald-700 border-emerald-200 hover:bg-emerald-50"
              onClick={() => handleAction(booking.id, 'confirmed')}
            >
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Accept
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs text-red-600 border-red-200 hover:bg-red-50"
              onClick={() => handleAction(booking.id, 'cancelled')}
            >
              <XCircle className="h-3 w-3 mr-1" />
              Reject
            </Button>
          </div>
        );
      case 'confirmed':
        return (
          <Button
            size="sm"
            variant="outline"
            className="h-7 text-xs text-teal-700 border-teal-200 hover:bg-teal-50"
            onClick={() => handleAction(booking.id, 'checked_in')}
          >
            <LogIn className="h-3 w-3 mr-1" />
            Check-In
          </Button>
        );
      case 'checked_in':
        return (
          <Button
            size="sm"
            variant="outline"
            className="h-7 text-xs text-slate-700 border-slate-200 hover:bg-slate-50"
            onClick={() => handleAction(booking.id, 'checked_out')}
          >
            <LogOut className="h-3 w-3 mr-1" />
            Check-Out
          </Button>
        );
      default:
        return <span className="text-xs text-muted-foreground">—</span>;
    }
  };

  const tabCounts = {
    all: bookings.length,
    pending: bookings.filter((b) => b.status === 'pending').length,
    confirmed: bookings.filter((b) => b.status === 'confirmed').length,
    checked_in: bookings.filter((b) => b.status === 'checked_in').length,
    checked_out: bookings.filter((b) => b.status === 'checked_out').length,
    cancelled: bookings.filter((b) => b.status === 'cancelled').length,
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-10 w-full rounded-lg" />
        <Skeleton className="h-96 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 w-fit">
              <CalendarCheck className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{todayBookings}</p>
            <p className="text-sm text-muted-foreground">Today's Bookings</p>
          </CardContent>
        </Card>

        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-teal-100 text-teal-700 w-fit">
              <DollarSign className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(monthlyRevenue)}</p>
            <p className="text-sm text-muted-foreground">Revenue This Month</p>
          </CardContent>
        </Card>

        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-cyan-100 text-cyan-700 w-fit">
              <TrendingUp className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatINR(avgBookingValue)}</p>
            <p className="text-sm text-muted-foreground">Avg Booking Value</p>
          </CardContent>
        </Card>

        <Card className="gap-4">
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-red-100 text-red-700 w-fit">
              <XCircle className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{cancellationRate}%</p>
            <p className="text-sm text-muted-foreground">Cancellation Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Table with Tabs */}
      <Card>
        <CardContent className="pt-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4 flex-wrap h-auto gap-1">
              <TabsTrigger value="all" className="text-xs">
                All ({tabCounts.all})
              </TabsTrigger>
              <TabsTrigger value="pending" className="text-xs">
                Pending ({tabCounts.pending})
              </TabsTrigger>
              <TabsTrigger value="confirmed" className="text-xs">
                Confirmed ({tabCounts.confirmed})
              </TabsTrigger>
              <TabsTrigger value="checked_in" className="text-xs">
                Checked In ({tabCounts.checked_in})
              </TabsTrigger>
              <TabsTrigger value="checked_out" className="text-xs">
                Checked Out ({tabCounts.checked_out})
              </TabsTrigger>
              <TabsTrigger value="cancelled" className="text-xs">
                Cancelled ({tabCounts.cancelled})
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab}>
              {filteredBookings.length === 0 ? (
                <div className="text-center py-16">
                  <CalendarCheck className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No bookings found for this filter.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Booking #</TableHead>
                      <TableHead>Guest</TableHead>
                      <TableHead>Check-in</TableHead>
                      <TableHead>Check-out</TableHead>
                      <TableHead>Rooms</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium text-sm">{booking.bookingNumber}</TableCell>
                        <TableCell>
                          <div>
                            <p className="text-sm font-medium">{booking.customerName}</p>
                            <p className="text-xs text-muted-foreground">{booking.customerEmail}</p>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">{formatDate(booking.checkIn)}</TableCell>
                        <TableCell className="text-sm">{formatDate(booking.checkOut)}</TableCell>
                        <TableCell className="text-sm">{booking.roomName || '—'}</TableCell>
                        <TableCell className="text-sm font-medium">{formatINR(booking.totalAmount)}</TableCell>
                        <TableCell>{renderStatusBadge(booking.status)}</TableCell>
                        <TableCell className="text-right">{renderActions(booking)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

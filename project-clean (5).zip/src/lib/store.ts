'use client';

import { create } from 'zustand';
import { type AppUser, type ViewType, type Hotel, type Booking, type Room, type DashboardStats, type PartnerDashboardStats, type ReportData, type Review, type Coupon, type Notification as AppNotification } from './types';

interface AppState {
  // Auth
  user: AppUser | null;
  isAuthenticated: boolean;
  
  // Navigation
  currentView: ViewType;
  selectedHotelId: string | null;
  selectedBookingId: string | null;
  
  // Data
  hotels: Hotel[];
  currentHotel: Hotel | null;
  rooms: Room[];
  bookings: Booking[];
  reviews: Review[];
  coupons: Coupon[];
  notifications: AppNotification[];
  dashboardStats: DashboardStats | null;
  partnerStats: PartnerDashboardStats | null;
  reportData: ReportData | null;
  
  // UI
  sidebarOpen: boolean;
  searchQuery: string;
  
  // Actions
  login: (user: AppUser) => void;
  logout: () => void;
  setCurrentView: (view: ViewType) => void;
  setSelectedHotelId: (id: string | null) => void;
  setSelectedBookingId: (id: string | null) => void;
  setHotels: (hotels: Hotel[]) => void;
  setCurrentHotel: (hotel: Hotel | null) => void;
  setRooms: (rooms: Room[]) => void;
  setBookings: (bookings: Booking[]) => void;
  setReviews: (reviews: Review[]) => void;
  setCoupons: (coupons: Coupon[]) => void;
  setNotifications: (notifications: AppNotification[]) => void;
  setDashboardStats: (stats: DashboardStats) => void;
  setPartnerStats: (stats: PartnerDashboardStats) => void;
  setReportData: (data: ReportData) => void;
  setSidebarOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  updateHotelStatus: (id: string, status: string) => void;
  updateBookingStatus: (id: string, status: string) => void;
  markNotificationRead: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  isAuthenticated: false,
  currentView: 'login',
  selectedHotelId: null,
  selectedBookingId: null,
  hotels: [],
  currentHotel: null,
  rooms: [],
  bookings: [],
  reviews: [],
  coupons: [],
  notifications: [],
  dashboardStats: null,
  partnerStats: null,
  reportData: null,
  sidebarOpen: true,
  searchQuery: '',
  
  login: (user) => set({ user, isAuthenticated: true, currentView: user.role === 'super_admin' || user.role === 'sub_admin' || user.role === 'finance' || user.role === 'support' ? 'admin-dashboard' : 'partner-dashboard' }),
  logout: () => set({ user: null, isAuthenticated: false, currentView: 'login', hotels: [], currentHotel: null, rooms: [], bookings: [], reviews: [], dashboardStats: null, partnerStats: null, reportData: null, selectedHotelId: null }),
  setCurrentView: (view) => set({ currentView: view }),
  setSelectedHotelId: (id) => set({ selectedHotelId: id }),
  setSelectedBookingId: (id) => set({ selectedBookingId: id }),
  setHotels: (hotels) => set({ hotels }),
  setCurrentHotel: (hotel) => set({ currentHotel: hotel }),
  setRooms: (rooms) => set({ rooms }),
  setBookings: (bookings) => set({ bookings }),
  setReviews: (reviews) => set({ reviews }),
  setCoupons: (coupons) => set({ coupons }),
  setNotifications: (notifications) => set({ notifications }),
  setDashboardStats: (stats) => set({ dashboardStats: stats }),
  setPartnerStats: (stats) => set({ partnerStats: stats }),
  setReportData: (data) => set({ reportData: data }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  updateHotelStatus: (id, status) => set((state) => ({
    hotels: state.hotels.map((h) => h.id === id ? { ...h, status: status as Hotel['status'] } : h),
    currentHotel: state.currentHotel?.id === id ? { ...state.currentHotel, status: status as Hotel['status'] } : state.currentHotel,
  })),
  updateBookingStatus: (id, status) => set((state) => ({
    bookings: state.bookings.map((b) => b.id === id ? { ...b, status: status as Booking['status'] } : b),
  })),
  markNotificationRead: (id) => set((state) => ({
    notifications: state.notifications.map((n) => n.id === id ? { ...n, isRead: true } : n),
  })),
}));

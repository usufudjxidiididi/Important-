import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toCamelArr, toSnake, generateId } from '@/lib/supabase';

/** Convert a user row (possibly with nested hotel) to camelCase */
function convertUser(row: Record<string, unknown>) {
  const user = toCamel<Record<string, unknown>>(row);
  const hotelData = (row as Record<string, unknown>).hotel;
  if (hotelData && typeof hotelData === 'object') {
    user.hotel = toCamel(hotelData as Record<string, unknown>);
  }
  return user;
}

/** Generate a unique partner code */
function generatePartnerCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `PART-${code}`;
}

// GET /api/users — list all users
export async function GET() {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { data, error } = await supabase
      .from('users')
      .select('*, hotel:hotels(id, name)')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Users fetch error:', error);
      return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
    }

    const users = (data || []).map(convertUser);
    return NextResponse.json({ users });
  } catch (error) {
    console.error('Users fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
  }
}

// POST /api/users — create a new user
export async function POST(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const { name, email, password, phone, role, hotelId } = body;

    if (!name?.trim() || !email?.trim()) {
      return NextResponse.json({ error: 'Name and email are required' }, { status: 400 });
    }

    if (!password?.trim()) {
      return NextResponse.json({ error: 'Password is required' }, { status: 400 });
    }

    // Check if email already exists
    const { data: existing } = await supabase
      .from('users')
      .select('id')
      .eq('email', email.trim())
      .maybeSingle();

    if (existing) {
      return NextResponse.json({ error: 'A user with this email already exists' }, { status: 409 });
    }

    const id = generateId();
    const partnerCode = generatePartnerCode();

    const { data: user, error } = await supabase
      .from('users')
      .insert({
        id,
        ...toSnake({
          name: name.trim(),
          email: email.trim(),
          password: password.trim(),
          phone: phone?.trim() || null,
          role: role || 'hotel_owner',
          hotelId: hotelId || null,
          partnerCode,
          isActive: true,
        }),
      })
      .select('*, hotel:hotels(id, name)')
      .single();

    if (error) {
      console.error('User create error:', error);
      return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
    }

    return NextResponse.json({ user: convertUser(user) }, { status: 201 });
  } catch (error) {
    console.error('User create error:', error);
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
  }
}

// DELETE /api/users?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const { data: user, error: findError } = await supabase
      .from('users')
      .select('id')
      .eq('id', id)
      .maybeSingle();

    if (findError || !user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const { error: deleteError } = await supabase
      .from('users')
      .delete()
      .eq('id', id);

    if (deleteError) {
      console.error('User delete error:', deleteError);
      return NextResponse.json({ error: 'Failed to delete user' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('User delete error:', error);
    return NextResponse.json({ error: 'Failed to delete user' }, { status: 500 });
  }
}

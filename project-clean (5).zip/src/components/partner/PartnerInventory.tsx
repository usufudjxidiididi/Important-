'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Room } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Lock,
  PackageOpen,
  Layers,
  Zap,
} from 'lucide-react';

// ---------- helpers ----------

const DAYS_OF_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

interface DayInventory {
  date: number;
  rooms: { available: number; blocked: number; sold: number; total: number }[];
}

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay();
}

function generateDayInventory(
  year: number,
  month: number,
  rooms: Room[]
): DayInventory[] {
  const daysInMonth = getDaysInMonth(year, month);
  const days: DayInventory[] = [];

  for (let d = 1; d <= daysInMonth; d++) {
    const seed = (year * 13 + month * 7 + d * 3) % 10;
    const roomsData = rooms.map((room) => {
      const total = room.totalInventory || 10;
      const sold = seed % Math.max(1, total - 1);
      const blocked = seed % 3 === 0 ? Math.min(2, total - sold) : 0;
      const available = total - sold - blocked;
      return { available, blocked, sold, total };
    });
    days.push({ date: d, rooms: roomsData });
  }
  return days;
}

// ---------- component ----------

export default function PartnerInventory() {
  const { user, setRooms } = useAppStore();
  const hotelId = user?.hotelId;

  const [rooms, setLocalRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);

  const today = new Date();
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());

  // Block dialog
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');
  const [blockDateFrom, setBlockDateFrom] = useState('');
  const [blockDateTo, setBlockDateTo] = useState('');
  const [blockReason, setBlockReason] = useState('');

  // Bulk update dialog
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false);
  const [bulkDateFrom, setBulkDateFrom] = useState('');
  const [bulkDateTo, setBulkDateTo] = useState('');
  const [bulkAvailability, setBulkAvailability] = useState('');

  useEffect(() => {
    if (!hotelId) return;

    const fetchRooms = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/rooms?hotelId=${hotelId}`);
        if (res.ok) {
          const data = await res.json();
          setLocalRooms(Array.isArray(data) ? data : []);
          setRooms(Array.isArray(data) ? data : []);
        }
      } catch (err) {
        console.error('Failed to fetch rooms:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRooms();
  }, [hotelId, setRooms]);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const days = useMemo(
    () => generateDayInventory(currentYear, currentMonth, rooms),
    [currentYear, currentMonth, rooms]
  );

  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  // Summary per room
  const roomSummary = useMemo(() => {
    return rooms.map((room, idx) => {
      const total = room.totalInventory || 10;
      const sold = days.reduce((sum, d) => sum + d.rooms[idx]?.sold || 0, 0);
      const blocked = days.reduce((sum, d) => sum + d.rooms[idx]?.blocked || 0, 0);
      const available = days.reduce((sum, d) => sum + d.rooms[idx]?.available || 0, 0);
      return {
        id: room.id,
        name: room.name,
        total,
        available,
        blocked,
        sold,
      };
    });
  }, [rooms, days]);

  const handleBlockRooms = () => {
    setBlockDialogOpen(false);
    setSelectedRoomId('');
    setBlockDateFrom('');
    setBlockDateTo('');
    setBlockReason('');
  };

  const handleBulkUpdate = () => {
    setBulkDialogOpen(false);
    setBulkDateFrom('');
    setBulkDateTo('');
    setBulkAvailability('');
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-80 w-full rounded-xl" />
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="h-6 w-6 text-emerald-600" />
          <h1 className="text-2xl font-bold">Inventory Management</h1>
        </div>
        <Dialog open={bulkDialogOpen} onOpenChange={setBulkDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Zap className="h-4 w-4 mr-2" />
              Bulk Update
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Bulk Update Availability</DialogTitle>
              <DialogDescription>
                Set availability for all rooms within a date range.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label>From Date</Label>
                <Input
                  type="date"
                  value={bulkDateFrom}
                  onChange={(e) => setBulkDateFrom(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label>To Date</Label>
                <Input
                  type="date"
                  value={bulkDateTo}
                  onChange={(e) => setBulkDateTo(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label>Available Rooms Per Room Type</Label>
                <Input
                  type="number"
                  placeholder="e.g. 5"
                  value={bulkAvailability}
                  onChange={(e) => setBulkAvailability(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBulkDialogOpen(false)}>
                Cancel
              </Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleBulkUpdate}>
                Update
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Calendar View */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CalendarDays className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base">
                {MONTHS[currentMonth]} {currentYear}
              </CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={prevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={nextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
          {/* Legend */}
          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 rounded-sm bg-emerald-500" /> Available
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 rounded-sm bg-amber-500" /> Blocked
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-3 h-3 rounded-sm bg-rose-500" /> Sold
            </span>
          </div>
        </CardHeader>
        <CardContent>
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {DAYS_OF_WEEK.map((day) => (
              <div
                key={day}
                className="text-center text-xs font-medium text-muted-foreground py-1"
              >
                {day}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {/* Empty cells for offset */}
            {Array.from({ length: firstDay }).map((_, i) => (
              <div key={`empty-${i}`} className="min-h-[60px] rounded-lg bg-muted/30" />
            ))}

            {/* Day cells */}
            {days.map((day) => {
              const isToday =
                day.date === today.getDate() &&
                currentMonth === today.getMonth() &&
                currentYear === today.getFullYear();

              return (
                <div
                  key={day.date}
                  className={`min-h-[60px] rounded-lg border p-1.5 text-xs ${
                    isToday
                      ? 'border-emerald-500 bg-emerald-50/50'
                      : 'border-border bg-card'
                  }`}
                >
                  <span
                    className={`font-medium ${
                      isToday ? 'text-emerald-700' : 'text-foreground'
                    }`}
                  >
                    {day.date}
                  </span>
                  <div className="mt-1 space-y-0.5">
                    {day.rooms.slice(0, 4).map((r, idx) => (
                      <div key={idx} className="flex items-center gap-0.5">
                        {r.available > 0 && (
                          <span className="w-2 h-2 rounded-full bg-emerald-500" />
                        )}
                        {r.blocked > 0 && (
                          <span className="w-2 h-2 rounded-full bg-amber-500" />
                        )}
                        {r.sold > 0 && (
                          <span className="w-2 h-2 rounded-full bg-rose-500" />
                        )}
                        <span className="text-[10px] text-muted-foreground">
                          {r.available}/{r.total}
                        </span>
                      </div>
                    ))}
                    {day.rooms.length > 4 && (
                      <span className="text-[10px] text-muted-foreground">
                        +{day.rooms.length - 4} more
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Room Inventory Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <PackageOpen className="h-5 w-5 text-emerald-600" />
            <CardTitle className="text-base">Room Inventory Summary</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room Name</TableHead>
                <TableHead className="text-center">Total</TableHead>
                <TableHead className="text-center">Available</TableHead>
                <TableHead className="text-center">Blocked</TableHead>
                <TableHead className="text-center">Sold</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roomSummary.map((room) => (
                <TableRow key={room.id}>
                  <TableCell className="font-medium">{room.name}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="secondary">{room.total}</Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="text-emerald-600 font-medium">{room.available}</span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="text-amber-600 font-medium">{room.blocked}</span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="text-rose-600 font-medium">{room.sold}</span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog
                      open={blockDialogOpen && selectedRoomId === room.id}
                      onOpenChange={(open) => {
                        setBlockDialogOpen(open);
                        if (open) setSelectedRoomId(room.id);
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Lock className="h-3.5 w-3.5 mr-1" />
                          Block Rooms
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Block Rooms - {room.name}</DialogTitle>
                          <DialogDescription>
                            Select a date range and reason to block rooms.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label>From Date</Label>
                            <Input
                              type="date"
                              value={blockDateFrom}
                              onChange={(e) => setBlockDateFrom(e.target.value)}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label>To Date</Label>
                            <Input
                              type="date"
                              value={blockDateTo}
                              onChange={(e) => setBlockDateTo(e.target.value)}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label>Number of Rooms to Block</Label>
                            <Input type="number" placeholder="e.g. 2" min="1" />
                          </div>
                          <div className="grid gap-2">
                            <Label>Reason</Label>
                            <Textarea
                              placeholder="e.g. Maintenance, Renovation..."
                              value={blockReason}
                              onChange={(e) => setBlockReason(e.target.value)}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            variant="outline"
                            onClick={() => setBlockDialogOpen(false)}
                          >
                            Cancel
                          </Button>
                          <Button
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={handleBlockRooms}
                          >
                            Block Rooms
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Review } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import {
  Star,
  MessageSquare,
  Reply,
  Send,
  Filter,
} from 'lucide-react';

// ---------- mock data ----------

const mockReviews: Review[] = [
  {
    id: 'r1',
    hotelId: 'mock',
    customerName: 'Rahul Sharma',
    rating: 5,
    comment: 'Absolutely wonderful experience! The staff was incredibly friendly and the room was spotless. The pool area was beautiful and the breakfast buffet had great variety.',
    status: 'published',
    createdAt: '2025-01-15',
  },
  {
    id: 'r2',
    hotelId: 'mock',
    customerName: 'Priya Mehta',
    rating: 4,
    comment: 'Great location and comfortable rooms. The check-in process was smooth. Only minor issue was the WiFi speed in the evening.',
    status: 'published',
    createdAt: '2025-01-14',
  },
  {
    id: 'r3',
    hotelId: 'mock',
    customerName: 'Amit Patel',
    rating: 5,
    comment: 'Best hotel stay in this city! The spa treatments were world-class and the restaurant food was exceptional. Will definitely come back.',
    status: 'published',
    createdAt: '2025-01-12',
  },
  {
    id: 'r4',
    hotelId: 'mock',
    customerName: 'Sneha Reddy',
    rating: 4,
    comment: 'Very clean and well-maintained property. The view from our room was stunning. Staff was helpful with local recommendations.',
    status: 'published',
    createdAt: '2025-01-10',
  },
  {
    id: 'r5',
    hotelId: 'mock',
    customerName: 'Vikram Singh',
    rating: 3,
    comment: 'Decent stay overall. Room was good but the bathroom could use an upgrade. Parking was a bit tight during peak hours.',
    status: 'published',
    createdAt: '2025-01-08',
  },
  {
    id: 'r6',
    hotelId: 'mock',
    customerName: 'Ananya Gupta',
    rating: 5,
    comment: 'Perfect for our family vacation! Kids loved the pool and the activity center. Breakfast had options for everyone. Highly recommended!',
    reply: 'Thank you for the wonderful review! We\'re glad your family enjoyed the stay. Looking forward to hosting you again!',
    status: 'published',
    createdAt: '2025-01-06',
  },
];

// ---------- component ----------

export default function PartnerReviews() {
  const { user, reviews: storeReviews } = useAppStore();
  const hotelId = user?.hotelId;

  const [replyOverrides, setReplyOverrides] = useState<Record<string, string>>({});
  const [filterRating, setFilterRating] = useState<number | null>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const reviews = useMemo(() => {
    if (!hotelId) return [];
    const filtered = storeReviews.filter((r) => r.hotelId === hotelId);
    const base = filtered.length > 0 ? filtered : mockReviews;
    return base.map((r) => ({
      ...r,
      reply: replyOverrides[r.id] ?? r.reply,
    }));
  }, [hotelId, storeReviews, replyOverrides]);

  const filteredReviews = useMemo(() => {
    if (filterRating === null) return reviews;
    return reviews.filter((r) => r.rating === filterRating);
  }, [reviews, filterRating]);

  const stats = useMemo(() => {
    const total = reviews.length;
    const avg = total > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / total : 0;
    const byRating = [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: reviews.filter((r) => r.rating === star).length,
    }));
    return { total, avg, byRating };
  }, [reviews]);

  const handleSubmitReply = (reviewId: string) => {
    if (!replyText.trim()) {
      toast.error('Please write a reply');
      return;
    }
    setReplyOverrides((prev) => ({
      ...prev,
      [reviewId]: replyText,
    }));
    setReplyingTo(null);
    setReplyText('');
    toast.success('Reply sent');
  };

  const renderStars = (rating: number) => (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'
          }`}
        />
      ))}
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <MessageSquare className="h-6 w-6 text-emerald-600" />
        <h1 className="text-2xl font-bold">Guest Reviews</h1>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Average Rating */}
        <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <p className="text-5xl font-bold text-emerald-700">
              {stats.avg.toFixed(1)}
            </p>
            <div className="mt-2">{renderStars(Math.round(stats.avg))}</div>
            <p className="text-sm text-muted-foreground mt-2">
              Based on {stats.total} reviews
            </p>
          </CardContent>
        </Card>

        {/* Rating Breakdown */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Rating Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.byRating.map(({ star, count }) => {
              const pct = stats.total > 0 ? (count / stats.total) * 100 : 0;
              return (
                <div key={star} className="flex items-center gap-3">
                  <span className="text-sm font-medium w-16 text-right">{star} Star</span>
                  <Progress value={pct} className="h-2 flex-1" />
                  <span className="text-sm text-muted-foreground w-8">{count}</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Filter:</span>
        {[null, 5, 4, 3].map((rating) => (
          <Button
            key={rating ?? 'all'}
            variant={filterRating === rating ? 'default' : 'outline'}
            size="sm"
            className={
              filterRating === rating
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : ''
            }
            onClick={() => setFilterRating(rating)}
          >
            {rating === null ? 'All' : `${rating} Star`}
          </Button>
        ))}
        <span className="text-sm text-muted-foreground ml-2">
          {filteredReviews.length} reviews
        </span>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {filteredReviews.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground/30" />
              <p className="mt-3 text-muted-foreground">No reviews found.</p>
            </CardContent>
          </Card>
        ) : (
          filteredReviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-semibold text-sm">
                      {review.customerName.split(' ').map((n) => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-medium">{review.customerName}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(review.createdAt).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  {renderStars(review.rating)}
                </div>

                <p className="mt-3 text-sm text-foreground/80">{review.comment}</p>

                {/* Existing Reply */}
                {review.reply && (
                  <div className="mt-3 ml-6 pl-4 border-l-2 border-emerald-300 bg-emerald-50/50 rounded-r-lg p-3">
                      <p className="text-xs font-medium text-emerald-700 mb-1">
                        Your Reply
                      </p>
                      <p className="text-sm text-muted-foreground">{review.reply}</p>
                    </div>
                )}

                {/* Reply Input */}
                {replyingTo === review.id && (
                  <div className="mt-3 space-y-2">
                    <Textarea
                      placeholder="Write your reply..."
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      className="min-h-[80px]"
                    />
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setReplyingTo(null);
                          setReplyText('');
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        className="bg-emerald-600 hover:bg-emerald-700"
                        onClick={() => handleSubmitReply(review.id)}
                      >
                        <Send className="h-3.5 w-3.5 mr-1" />
                        Send Reply
                      </Button>
                    </div>
                  </div>
                )}

                {/* Reply button */}
                {replyingTo !== review.id && !review.reply && (
                  <div className="mt-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                      onClick={() => setReplyingTo(review.id)}
                    >
                      <Reply className="h-3.5 w-3.5 mr-1" />
                      Reply
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

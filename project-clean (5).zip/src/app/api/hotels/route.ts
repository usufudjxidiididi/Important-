import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toCamelArr, toSnake, generateId } from '@/lib/supabase';

/** Recursively convert snake_case DB rows (including nested arrays/objects) to camelCase */
function deepCamel<T>(data: unknown): T {
  if (Array.isArray(data)) return data.map(deepCamel) as T;
  if (data !== null && typeof data === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
      const camel = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
      result[camel] = deepCamel(value);
    }
    return result as T;
  }
  return data as T;
}

export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const search = searchParams.get('search');
    const city = searchParams.get('city');

    let query = supabase
      .from('hotels')
      .select('*, rooms(*), bookings(*), reviews(*)')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    if (city) {
      query = query.eq('city', city);
    }

    if (search) {
      const pattern = `%${search}%`;
      query = query.or(
        `name.ilike.${pattern},email.ilike.${pattern},owner_name.ilike.${pattern},registration_number.ilike.${pattern}`
      );
    }

    const { data: hotelsRaw, error } = await query;

    if (error) {
      console.error('Hotels list error:', error);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    const hotels = deepCamel<any[]>(hotelsRaw || []);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    const todayStr = now.toISOString().split('T')[0];

    const hotelsWithStats = await Promise.all(
      hotels.map(async (hotel) => {
        const totalRooms = (hotel.rooms || []).length;
        const roomIds = (hotel.rooms || []).map((r: any) => r.id);

        // Fetch today's inventory for this hotel's rooms
        let availableRooms = 0;
        if (roomIds.length > 0) {
          const { data: inventories } = await supabase
            .from('inventory')
            .select('available_rooms')
            .eq('date', todayStr)
            .in('room_id', roomIds);

          availableRooms = (inventories || []).reduce(
            (sum: number, inv: any) => sum + (inv.available_rooms ?? 0),
            0
          );
        }

        const bookingCount = (hotel.bookings || []).length;

        const monthlyRevenue = (hotel.bookings || [])
          .filter((b: any) => {
            if (!['confirmed', 'checked_in', 'checked_out'].includes(b.status)) return false;
            const bDate = new Date(b.createdAt);
            return bDate >= startOfMonth && bDate <= endOfMonth;
          })
          .reduce((sum: number, b: any) => sum + (b.totalAmount ?? 0), 0);

        const ratings = (hotel.reviews || []).map((r: any) => r.rating);
        const avgRating = ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;

        const { rooms: _rooms, bookings: _bookings, reviews: _reviews, ...hotelData } = hotel;

        return {
          ...hotelData,
          totalRooms,
          availableRooms,
          bookingCount,
          monthlyRevenue,
          avgRating: Math.round(avgRating * 10) / 10,
        };
      })
    );

    return NextResponse.json(hotelsWithStats);
  } catch (error) {
    console.error('Hotels list error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const body = await request.json();
    const {
      name, brand, registrationNumber, gst, ownerName, contactPerson,
      email, phone, address, city, state, country, pincode,
      description, starRating, checkInTime, checkOutTime,
      amenities, languages, hasParking, hasRestaurant, hasPool, hasSpa, hasWiFi, allowsPets,
      userId, partnerCode,
    } = body;

    if (!name || !email) {
      return NextResponse.json({ error: 'Hotel name and email are required' }, { status: 400 });
    }

    const hotelInput = {
      name,
      brand: brand || null,
      registrationNumber: registrationNumber || null,
      gst: gst || null,
      ownerName: ownerName || null,
      contactPerson: contactPerson || null,
      email,
      phone: phone || null,
      address: address || null,
      city: city || null,
      state: state || null,
      country: country || 'India',
      pincode: pincode || null,
      description: description || null,
      starRating: starRating || 3,
      checkInTime: checkInTime || '14:00',
      checkOutTime: checkOutTime || '11:00',
      amenities: amenities || null,
      languages: languages || null,
      hasParking: hasParking || false,
      hasRestaurant: hasRestaurant || false,
      hasPool: hasPool || false,
      hasSpa: hasSpa || false,
      hasWiFi: hasWiFi !== false,
      allowsPets: allowsPets || false,
      status: 'pending',
    };

    const hotelId = generateId();

    const { data: hotel, error: hotelError } = await supabase
      .from('hotels')
      .insert({ ...toSnake(hotelInput), id: hotelId })
      .select()
      .single();

    if (hotelError) {
      console.error('Hotel creation error:', hotelError);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    // Link hotel to the user if userId provided
    let linkedUserId = userId;

    // If partnerCode is provided, find the partner user and link hotel to them
    if (partnerCode && !userId) {
      const { data: partnerUser } = await supabase
        .from('users')
        .select('id')
        .eq('partner_code', partnerCode)
        .single();

      if (partnerUser) {
        linkedUserId = partnerUser.id;
      }
    }

    if (linkedUserId) {
      await supabase
        .from('users')
        .update({ hotel_id: hotelId })
        .eq('id', linkedUserId);
    }

    // Create bank account if provided
    if (body.bankName || body.accountName || body.ifsc) {
      const bankInput = {
        hotelId: hotelId,
        bankName: body.bankName || null,
        accountName: body.accountName || null,
        accountNumber: body.accountNumber || null,
        ifsc: body.ifsc || null,
        upiId: body.upiId || null,
      };

      const { error: bankError } = await supabase
        .from('bank_accounts')
        .insert({ ...toSnake(bankInput), id: generateId() });

      if (bankError) {
        console.error('Bank account creation error:', bankError);
      }
    }

    return NextResponse.json(
      { hotel: toCamel(hotel), message: 'Hotel registered successfully! Pending admin approval.' },
      { status: 201 }
    );
  } catch (error) {
    console.error('Hotel creation error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

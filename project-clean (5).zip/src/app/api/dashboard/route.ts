import { NextResponse } from 'next/server';
import { supabase, toCamelArr } from '@/lib/supabase';

export async function GET() {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();

    const [
      totalHotelsRes,
      pendingHotelsRes,
      activeHotelsRes,
      suspendedHotelsRes,
      allRoomsRes,
      allBookingsRes,
      allReviewsRes,
      allInventoriesRes,
    ] = await Promise.all([
      supabase.from('hotels').select('*', { count: 'exact', head: true }),
      supabase.from('hotels').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('hotels').select('*', { count: 'exact', head: true }).eq('status', 'approved'),
      supabase.from('hotels').select('*', { count: 'exact', head: true }).eq('status', 'suspended'),
      supabase.from('rooms').select('*'),
      supabase.from('bookings').select('*'),
      supabase.from('reviews').select('*'),
      supabase.from('inventory').select('*').eq('date', todayStr),
    ]);

    if (totalHotelsRes.error) throw totalHotelsRes.error;
    if (pendingHotelsRes.error) throw pendingHotelsRes.error;
    if (activeHotelsRes.error) throw activeHotelsRes.error;
    if (suspendedHotelsRes.error) throw suspendedHotelsRes.error;
    if (allRoomsRes.error) throw allRoomsRes.error;
    if (allBookingsRes.error) throw allBookingsRes.error;
    if (allReviewsRes.error) throw allReviewsRes.error;
    if (allInventoriesRes.error) throw allInventoriesRes.error;

    const totalHotels = totalHotelsRes.count ?? 0;
    const pendingHotels = pendingHotelsRes.count ?? 0;
    const activeHotels = activeHotelsRes.count ?? 0;
    const suspendedHotels = suspendedHotelsRes.count ?? 0;

    const allRooms = toCamelArr(allRoomsRes.data);
    const allBookings = toCamelArr(allBookingsRes.data);
    const allReviews = toCamelArr(allReviewsRes.data);
    const allInventories = toCamelArr(allInventoriesRes.data);

    const totalRooms = allRooms.length;
    const availableRooms = allInventories.reduce((sum: number, inv: any) => sum + (inv.availableRooms || 0), 0);

    const bookingsToday = allBookings.filter((b: any) => b.checkIn === todayStr).length;

    const monthlyBookings = allBookings.filter((b: any) => {
      const d = new Date(b.createdAt);
      return d >= new Date(startOfMonth) && d <= new Date(endOfMonth);
    });

    const revenueBookings = monthlyBookings.filter((b: any) =>
      ['confirmed', 'checked_in', 'checked_out'].includes(b.status)
    );

    const monthlyRevenue = revenueBookings.reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0);
    const platformCommission = revenueBookings.reduce((sum: number, b: any) => sum + (b.commission || 0), 0);

    const totalRoomsCapacity = allInventories.reduce((sum: number, inv: any) => sum + (inv.totalRooms || 0), 0);
    const occupiedRooms = totalRoomsCapacity - availableRooms;
    const occupancyRate = totalRoomsCapacity > 0 ? (occupiedRooms / totalRoomsCapacity) * 100 : 0;

    const uniqueCustomers = new Set(allBookings.map((b: any) => b.customerEmail));
    const totalCustomers = uniqueCustomers.size;

    const avgRating =
      allReviews.length > 0
        ? allReviews.reduce((sum: number, r: any) => sum + (r.rating || 0), 0) / allReviews.length
        : 0;

    return NextResponse.json({
      totalHotels,
      pendingHotels,
      activeHotels,
      suspendedHotels,
      totalRooms,
      availableRooms,
      bookingsToday,
      monthlyRevenue,
      platformCommission,
      occupancyRate: Math.round(occupancyRate * 10) / 10,
      totalBookings: allBookings.length,
      totalCustomers,
      avgRating: Math.round(avgRating * 10) / 10,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { BookingStatus, PaymentStatus, Booking } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import {
  Search,
  Eye,
  CheckCircle2,
  XCircle,
  LogIn,
  LogOut,
  MoreHorizontal,
  CalendarCheck,
  CalendarX2,
  ClipboardList,
  Loader2,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

const ITEMS_PER_PAGE = 10;

type FilterStatus = 'all' | BookingStatus;

const STATUS_OPTIONS: { label: string; value: FilterStatus }[] = [
  { label: 'All', value: 'all' },
  { label: 'Pending', value: 'pending' },
  { label: 'Confirmed', value: 'confirmed' },
  { label: 'Checked In', value: 'checked_in' },
  { label: 'Checked Out', value: 'checked_out' },
  { label: 'Cancelled', value: 'cancelled' },
  { label: 'No Show', value: 'no_show' },
];

function getBookingStatusBadge(status: BookingStatus) {
  const map: Record<BookingStatus, { bg: string; text: string; border: string; label: string }> = {
    pending:     { bg: 'bg-orange-100',  text: 'text-orange-700',   border: 'border-orange-200',  label: 'Pending' },
    confirmed:   { bg: 'bg-emerald-100', text: 'text-emerald-700',  border: 'border-emerald-200', label: 'Confirmed' },
    checked_in:  { bg: 'bg-cyan-100',    text: 'text-cyan-700',    border: 'border-cyan-200',    label: 'Checked In' },
    checked_out: { bg: 'bg-gray-100',    text: 'text-gray-700',    border: 'border-gray-200',    label: 'Checked Out' },
    cancelled:   { bg: 'bg-red-100',     text: 'text-red-700',     border: 'border-red-200',     label: 'Cancelled' },
    no_show:     { bg: 'bg-amber-100',   text: 'text-amber-700',   border: 'border-amber-200',   label: 'No Show' },
  };
  const s = map[status];
  return (
    <Badge className={`${s.bg} ${s.text} ${s.border} hover:${s.bg}`}>
      {s.label}
    </Badge>
  );
}

function getPaymentBadge(status: PaymentStatus) {
  const map: Record<PaymentStatus, { bg: string; text: string; border: string; label: string }> = {
    pending:  { bg: 'bg-amber-100',   text: 'text-amber-700',   border: 'border-amber-200',  label: 'Pending' },
    paid:     { bg: 'bg-emerald-100', text: 'text-emerald-700',  border: 'border-emerald-200', label: 'Paid' },
    refunded: { bg: 'bg-gray-100',    text: 'text-gray-600',    border: 'border-gray-200',    label: 'Refunded' },
    partial:  { bg: 'bg-teal-100',    text: 'text-teal-700',     border: 'border-teal-200',    label: 'Partial' },
  };
  const s = map[status];
  return (
    <Badge className={`${s.bg} ${s.text} ${s.border} hover:${s.bg}`}>
      {s.label}
    </Badge>
  );
}

// ---------- component ----------

export default function BookingManagement() {
  const { bookings, setBookings, updateBookingStatus } = useAppStore();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  // Fetch bookings on mount
  useEffect(() => {
    async function fetchBookings() {
      try {
        setLoading(true);
        const res = await fetch('/api/bookings');
        if (!res.ok) throw new Error('Failed to fetch bookings');
        const data = await res.json();
        setBookings(data);
      } catch {
        toast.error('Failed to load bookings');
      } finally {
        setLoading(false);
      }
    }
    fetchBookings();
  }, [setBookings]);

  // Summary stats
  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return {
      total: bookings.length,
      today: bookings.filter((b) => b.checkIn.startsWith(today)).length,
      confirmed: bookings.filter((b) => b.status === 'confirmed').length,
      cancelled: bookings.filter((b) => b.status === 'cancelled').length,
    };
  }, [bookings]);

  // Filtered bookings
  const filtered = useMemo(() => {
    return bookings.filter((b) => {
      // Status filter
      if (statusFilter !== 'all' && b.status !== statusFilter) return false;
      // Search filter
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          b.customerName.toLowerCase().includes(q) ||
          b.bookingNumber.toLowerCase().includes(q) ||
          (b.hotel?.name ?? '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [bookings, statusFilter, search]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filtered.slice(start, start + ITEMS_PER_PAGE);
  }, [filtered, currentPage]);

  // Reset page on filter change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, statusFilter]);

  // Status action handler
  const handleStatusAction = useCallback(async (bookingId: string, newStatus: string) => {
    try {
      setActionLoading(bookingId);
      const res = await fetch(`/api/bookings/${bookingId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) throw new Error('Failed to update booking');
      updateBookingStatus(bookingId, newStatus);
      toast.success(`Booking ${newStatus.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}`);
    } catch {
      toast.error('Failed to update booking status');
    } finally {
      setActionLoading(null);
    }
  }, [updateBookingStatus]);

  // View details
  const handleViewDetails = useCallback((booking: Booking) => {
    setSelectedBooking(booking);
    setDetailsOpen(true);
  }, []);

  // Summary cards data
  const summaryCards = [
    { label: 'Total Bookings', value: stats.total, icon: ClipboardList, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: "Today's Bookings", value: stats.today, icon: CalendarCheck, color: 'text-teal-600', bg: 'bg-teal-50' },
    { label: 'Confirmed', value: stats.confirmed, icon: CheckCircle2, color: 'text-cyan-600', bg: 'bg-cyan-50' },
    { label: 'Cancelled', value: stats.cancelled, icon: CalendarX2, color: 'text-red-500', bg: 'bg-red-50' },
  ];

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Booking Management</h1>
        <p className="text-sm text-gray-500 mt-1">Manage and track all hotel bookings</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.label} className="border-0 shadow-sm">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`${card.bg} p-3 rounded-xl`}>
                <card.icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <div>
                <p className="text-sm text-gray-500">{card.label}</p>
                <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search by guest, booking #, or hotel..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {STATUS_OPTIONS.map((opt) => (
            <Button
              key={opt.value}
              size="sm"
              variant={statusFilter === opt.value ? 'default' : 'outline'}
              onClick={() => setStatusFilter(opt.value)}
              className={
                statusFilter === opt.value
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'border-gray-200 text-gray-600 hover:bg-gray-50'
              }
            >
              {opt.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Table */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-6 w-6 animate-spin text-emerald-600" />
              <span className="ml-2 text-gray-500">Loading bookings...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <ClipboardList className="h-12 w-12 mb-3" />
              <p className="text-lg font-medium">No bookings found</p>
              <p className="text-sm">Try adjusting your search or filter</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b border-gray-100 hover:bg-transparent">
                      <TableHead className="font-semibold text-gray-600">Booking #</TableHead>
                      <TableHead className="font-semibold text-gray-600">Guest Name</TableHead>
                      <TableHead className="font-semibold text-gray-600">Hotel</TableHead>
                      <TableHead className="font-semibold text-gray-600">Room</TableHead>
                      <TableHead className="font-semibold text-gray-600">Check-in</TableHead>
                      <TableHead className="font-semibold text-gray-600">Check-out</TableHead>
                      <TableHead className="font-semibold text-gray-600 text-right">Amount (₹)</TableHead>
                      <TableHead className="font-semibold text-gray-600">Status</TableHead>
                      <TableHead className="font-semibold text-gray-600">Payment</TableHead>
                      <TableHead className="font-semibold text-gray-600 w-12">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginated.map((booking) => (
                      <TableRow key={booking.id} className="border-b border-gray-50">
                        <TableCell className="font-medium text-emerald-700">
                          {booking.bookingNumber}
                        </TableCell>
                        <TableCell className="font-medium">{booking.customerName}</TableCell>
                        <TableCell className="text-gray-600">{booking.hotel?.name ?? '—'}</TableCell>
                        <TableCell className="text-gray-600">{booking.roomName ?? '—'}</TableCell>
                        <TableCell className="text-gray-600">{formatDate(booking.checkIn)}</TableCell>
                        <TableCell className="text-gray-600">{formatDate(booking.checkOut)}</TableCell>
                        <TableCell className="text-right font-semibold">{formatINR(booking.totalAmount)}</TableCell>
                        <TableCell>{getBookingStatusBadge(booking.status)}</TableCell>
                        <TableCell>{getPaymentBadge(booking.paymentStatus)}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                              <DropdownMenuItem onClick={() => handleViewDetails(booking)}>
                                <Eye className="mr-2 h-4 w-4" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />

                              {booking.status === 'pending' && (
                                <DropdownMenuItem onClick={() => handleStatusAction(booking.id, 'confirmed')} disabled={actionLoading === booking.id}>
                                  <CheckCircle2 className="mr-2 h-4 w-4 text-emerald-600" />
                                  {actionLoading === booking.id ? 'Updating...' : 'Confirm'}
                                </DropdownMenuItem>
                              )}

                              {(booking.status === 'pending' || booking.status === 'confirmed') && (
                                <DropdownMenuItem onClick={() => handleStatusAction(booking.id, 'cancelled')} disabled={actionLoading === booking.id}>
                                  <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                  {actionLoading === booking.id ? 'Updating...' : 'Cancel'}
                                </DropdownMenuItem>
                              )}

                              {booking.status === 'confirmed' && (
                                <DropdownMenuItem onClick={() => handleStatusAction(booking.id, 'checked_in')} disabled={actionLoading === booking.id}>
                                  <LogIn className="mr-2 h-4 w-4 text-cyan-600" />
                                  {actionLoading === booking.id ? 'Updating...' : 'Check-In'}
                                </DropdownMenuItem>
                              )}

                              {booking.status === 'checked_in' && (
                                <DropdownMenuItem onClick={() => handleStatusAction(booking.id, 'checked_out')} disabled={actionLoading === booking.id}>
                                  <LogOut className="mr-2 h-4 w-4 text-gray-600" />
                                  {actionLoading === booking.id ? 'Updating...' : 'Check-Out'}
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
                  <p className="text-sm text-gray-500">
                    Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1}–
                    {Math.min(currentPage * ITEMS_PER_PAGE, filtered.length)} of {filtered.length}
                  </p>
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                          className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                        />
                      </PaginationItem>
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter((page) => {
                          if (totalPages <= 7) return true;
                          if (page === 1 || page === totalPages) return true;
                          return Math.abs(page - currentPage) <= 1;
                        })
                        .map((page, idx, arr) => {
                          const prev = arr[idx - 1];
                          const showEllipsis = prev !== undefined && page - prev > 1;
                          return (
                            <span key={page} className="flex items-center">
                              {showEllipsis && (
                                <PaginationItem>
                                  <span className="px-2 text-gray-400">…</span>
                                </PaginationItem>
                              )}
                              <PaginationItem>
                                <PaginationLink
                                  onClick={() => setCurrentPage(page)}
                                  isActive={page === currentPage}
                                  className={
                                    page === currentPage
                                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                                      : 'cursor-pointer'
                                  }
                                >
                                  {page}
                                </PaginationLink>
                              </PaginationItem>
                            </span>
                          );
                        })}
                      <PaginationItem>
                        <PaginationNext
                          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                          className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Booking Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-emerald-800">Booking Details</DialogTitle>
            <DialogDescription>Complete booking information</DialogDescription>
          </DialogHeader>
          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500">Booking Number</p>
                  <p className="font-semibold text-emerald-700">{selectedBooking.bookingNumber}</p>
                </div>
                <div>
                  <p className="text-gray-500">Status</p>
                  {getBookingStatusBadge(selectedBooking.status)}
                </div>
                <div>
                  <p className="text-gray-500">Guest Name</p>
                  <p className="font-medium">{selectedBooking.customerName}</p>
                </div>
                <div>
                  <p className="text-gray-500">Email</p>
                  <p className="font-medium">{selectedBooking.customerEmail}</p>
                </div>
                <div>
                  <p className="text-gray-500">Phone</p>
                  <p className="font-medium">{selectedBooking.customerPhone ?? '—'}</p>
                </div>
                <div>
                  <p className="text-gray-500">Payment</p>
                  {getPaymentBadge(selectedBooking.paymentStatus)}
                </div>
                <div>
                  <p className="text-gray-500">Hotel</p>
                  <p className="font-medium">{selectedBooking.hotel?.name ?? '—'}</p>
                </div>
                <div>
                  <p className="text-gray-500">Room</p>
                  <p className="font-medium">{selectedBooking.roomName ?? '—'}</p>
                </div>
                <div>
                  <p className="text-gray-500">Check-in</p>
                  <p className="font-medium">{formatDate(selectedBooking.checkIn)}</p>
                </div>
                <div>
                  <p className="text-gray-500">Check-out</p>
                  <p className="font-medium">{formatDate(selectedBooking.checkOut)}</p>
                </div>
                <div>
                  <p className="text-gray-500">Guests</p>
                  <p className="font-medium">
                    {selectedBooking.adults} Adults, {selectedBooking.children} Children
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Payment Method</p>
                  <p className="font-medium">{selectedBooking.paymentMethod ?? '—'}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-gray-500">Total Amount</p>
                  <p className="text-xl font-bold text-emerald-700">{formatINR(selectedBooking.totalAmount)}</p>
                </div>
                {selectedBooking.commission > 0 && (
                  <div>
                    <p className="text-gray-500">Commission</p>
                    <p className="font-medium">{formatINR(selectedBooking.commission)}</p>
                  </div>
                )}
                {selectedBooking.netAmount != null && (
                  <div>
                    <p className="text-gray-500">Net Amount</p>
                    <p className="font-medium">{formatINR(selectedBooking.netAmount)}</p>
                  </div>
                )}
                {selectedBooking.specialRequests && (
                  <div className="col-span-2">
                    <p className="text-gray-500">Special Requests</p>
                    <p className="font-medium">{selectedBooking.specialRequests}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

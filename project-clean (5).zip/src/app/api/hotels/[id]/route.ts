import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toCamelArr, toSnake, generateId } from '@/lib/supabase';

/** Recursively convert snake_case DB rows (including nested arrays/objects) to camelCase */
function deepCamel<T>(data: unknown): T {
  if (Array.isArray(data)) return data.map(deepCamel) as T;
  if (data !== null && typeof data === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
      const camel = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
      result[camel] = deepCamel(value);
    }
    return result as T;
  }
  return data as T;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { id } = await params;

    const { data: hotelRaw, error } = await supabase
      .from('hotels')
      .select('*, rooms(*), reviews(*), bookings(*)')
      .eq('id', id)
      .single();

    if (error || !hotelRaw) {
      return NextResponse.json({ error: 'Hotel not found' }, { status: 404 });
    }

    const hotel = deepCamel<any>(hotelRaw);

    // Limit bookings to 20 (most recent — already ordered by created_at desc in DB,
    // but Supabase nested selects don't support per-relation ordering, so slice here)
    if (hotel.bookings) {
      hotel.bookings = hotel.bookings
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 20);
    }

    return NextResponse.json(hotel);
  } catch (error) {
    console.error('Hotel detail error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { id } = await params;
    const body = await request.json();

    // Check hotel exists
    const { data: existing, error: existErr } = await supabase
      .from('hotels')
      .select('*')
      .eq('id', id)
      .single();

    if (existErr || !existing) {
      return NextResponse.json({ error: 'Hotel not found' }, { status: 404 });
    }

    const { status, ...details } = body;
    const updateData: Record<string, unknown> = { ...details };

    if (status && status !== existing.status) {
      updateData.status = status;

      await supabase.from('audit_logs').insert({
        id: generateId(),
        action: 'UPDATE_HOTEL_STATUS',
        entity: 'Hotel',
        entity_id: id,
        details: `Status changed from ${existing.status} to ${status}`,
      });
    }

    const { data: hotel, error: updateErr } = await supabase
      .from('hotels')
      .update(toSnake(updateData))
      .eq('id', id)
      .select()
      .single();

    if (updateErr) {
      console.error('Hotel update error:', updateErr);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    return NextResponse.json(toCamel(hotel));
  } catch (error) {
    console.error('Hotel update error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

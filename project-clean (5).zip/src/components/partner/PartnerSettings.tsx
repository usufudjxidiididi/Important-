'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  Settings,
  Building2,
  Phone,
  Wifi,
  FileText,
  Landmark,
  ShieldCheck,
  Save,
  Loader2,
} from 'lucide-react';

// ---------- component ----------

export default function PartnerSettings() {
  const { user, currentHotel, setCurrentHotel } = useAppStore();
  const hotelId = currentHotel?.id || user?.hotelId || '';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Hotel Info
  const [hotelName, setHotelName] = useState('');
  const [hotelDesc, setHotelDesc] = useState('');
  const [starRating, setStarRating] = useState('3');
  const [checkInTime, setCheckInTime] = useState('14:00');
  const [checkOutTime, setCheckOutTime] = useState('11:00');

  // Contact
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactWebsite, setContactWebsite] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');

  // Facilities
  const [facilities, setFacilities] = useState<Record<string, boolean>>({
    wifi: true,
    parking: false,
    restaurant: false,
    pool: false,
    spa: false,
    pets: false,
    gym: false,
    roomService: false,
    laundry: false,
    airportTransfer: false,
    ac: true,
    tv: true,
  });

  // Policies
  const [checkInPolicy, setCheckInPolicy] = useState('');
  const [cancellationPolicy, setCancellationPolicy] = useState('');
  const [childPolicy, setChildPolicy] = useState('');
  const [paymentPolicy, setPaymentPolicy] = useState('');

  // Bank Details
  const [bankName, setBankName] = useState('');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifsc, setIfsc] = useState('');
  const [upi, setUpi] = useState('');

  // Security
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [twoFA, setTwoFA] = useState(false);

  // Load hotel data from DB
  const loadHotelData = useCallback(async () => {
    if (!hotelId) { setLoading(false); return; }
    try {
      const res = await fetch(`/api/hotels/${hotelId}`);
      if (res.ok) {
        const hotel = await res.json();
        // Populate hotel info
        setHotelName(hotel.name || '');
        setHotelDesc(hotel.description || '');
        setStarRating(String(hotel.starRating || 3));
        setCheckInTime(hotel.checkInTime || '14:00');
        setCheckOutTime(hotel.checkOutTime || '11:00');
        // Contact
        setContactEmail(hotel.email || '');
        setContactPhone(hotel.phone || '');
        // Policies (stored as JSON string)
        if (hotel.policies) {
          try {
            const p = JSON.parse(hotel.policies);
            setCheckInPolicy(p.checkIn || '');
            setCancellationPolicy(p.cancellation || '');
            setChildPolicy(p.child || '');
            setPaymentPolicy(p.payment || '');
          } catch {
            setCheckInPolicy(hotel.policies);
          }
        }
        // Amenities (stored as JSON string)
        if (hotel.amenities) {
          try {
            const a = JSON.parse(hotel.amenities);
            setFacilities(prev => ({ ...prev, ...a }));
          } catch {}
        }
      }
    } catch {
      toast.error('Failed to load hotel data');
    } finally {
      setLoading(false);
    }
  }, [hotelId]);

  // Load bank account data
  const loadBankData = useCallback(async () => {
    if (!hotelId) return;
    try {
      const res = await fetch(`/api/bank-account?hotelId=${hotelId}`);
      if (res.ok) {
        const data = await res.json();
        if (data && data.id) {
          setBankName(data.bankName || '');
          setAccountName(data.accountName || '');
          setAccountNumber(data.accountNumber || '');
          setIfsc(data.ifsc || '');
          setUpi(data.upi || '');
        }
      }
    } catch {}
  }, [hotelId]);

  useEffect(() => {
    loadHotelData();
    loadBankData();
  }, [loadHotelData, loadBankData]);

  const toggleFacility = (key: string) => {
    setFacilities((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleChangePassword = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('Please fill in all password fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    toast.success('Password changed successfully');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  // ---- Real save handlers ----

  const handleSave = async (section: string) => {
    if (!hotelId) {
      toast.error('No hotel linked to your account');
      return;
    }
    setSaving(true);
    try {
      if (section === 'hotel-info') {
        const res = await fetch(`/api/hotels/${hotelId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: hotelName,
            description: hotelDesc,
            starRating: parseInt(starRating),
            checkInTime,
            checkOutTime,
          }),
        });
        if (!res.ok) throw new Error('Failed');
        // Update store
        if (currentHotel) {
          setCurrentHotel({
            ...currentHotel,
            name: hotelName,
            description: hotelDesc,
            starRating: parseInt(starRating),
            checkInTime,
            checkOutTime,
          });
        }
      } else if (section === 'contact') {
        const res = await fetch(`/api/hotels/${hotelId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: contactEmail,
            phone: contactPhone,
          }),
        });
        if (!res.ok) throw new Error('Failed');
        if (currentHotel) {
          setCurrentHotel({ ...currentHotel, email: contactEmail, phone: contactPhone });
        }
      } else if (section === 'facilities') {
        const amenitiesStr = JSON.stringify(facilities);
        const res = await fetch(`/api/hotels/${hotelId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amenities: amenitiesStr,
            hasWiFi: facilities.wifi,
            hasParking: facilities.parking,
            hasRestaurant: facilities.restaurant,
            hasPool: facilities.pool,
            hasSpa: facilities.spa,
            allowsPets: facilities.pets,
          }),
        });
        if (!res.ok) throw new Error('Failed');
        if (currentHotel) {
          setCurrentHotel({ ...currentHotel, amenities: amenitiesStr });
        }
      } else if (section === 'policies') {
        const policiesStr = JSON.stringify({
          checkIn: checkInPolicy,
          cancellation: cancellationPolicy,
          child: childPolicy,
          payment: paymentPolicy,
        });
        const res = await fetch(`/api/hotels/${hotelId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ policies: policiesStr }),
        });
        if (!res.ok) throw new Error('Failed');
        if (currentHotel) {
          setCurrentHotel({ ...currentHotel, policies: policiesStr });
        }
      } else if (section === 'bank-details') {
        const res = await fetch('/api/bank-account', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            hotelId,
            bankName,
            accountName,
            accountNumber,
            ifsc,
            upi,
          }),
        });
        if (!res.ok) throw new Error('Failed');
      }
      toast.success(`${section.replace('-', ' ')} saved successfully`);
    } catch {
      toast.error('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const facilityList = [
    { key: 'wifi', label: 'WiFi / Internet', icon: Wifi },
    { key: 'parking', label: 'Parking', icon: Building2 },
    { key: 'restaurant', label: 'Restaurant', icon: Building2 },
    { key: 'pool', label: 'Swimming Pool', icon: Building2 },
    { key: 'spa', label: 'Spa & Wellness', icon: Building2 },
    { key: 'pets', label: 'Pet Friendly', icon: Building2 },
    { key: 'gym', label: 'Gym / Fitness Center', icon: Building2 },
    { key: 'roomService', label: 'Room Service', icon: Building2 },
    { key: 'laundry', label: 'Laundry Service', icon: Building2 },
    { key: 'airportTransfer', label: 'Airport Transfer', icon: Building2 },
    { key: 'ac', label: 'Air Conditioning', icon: Building2 },
    { key: 'tv', label: 'Television', icon: Building2 },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Settings className="h-6 w-6 text-emerald-600" />
        <h1 className="text-2xl font-bold">Hotel Settings</h1>
      </div>

      <Tabs defaultValue="hotel-info" className="space-y-4">
        <TabsList>
          <TabsTrigger value="hotel-info">Hotel Info</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="facilities">Facilities</TabsTrigger>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="bank-details">Bank Details</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        {/* ========== HOTEL INFO TAB ========== */}
        <TabsContent value="hotel-info">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-emerald-600" />
                  Hotel Information
                </CardTitle>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => handleSave('hotel-info')}
                  disabled={saving}
                >
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Hotel Name</Label>
                  <Input
                    value={hotelName}
                    onChange={(e) => setHotelName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Star Rating</Label>
                  <Select value={starRating} onValueChange={setStarRating}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((s) => (
                        <SelectItem key={s} value={String(s)}>
                          {s} Star{s > 1 ? 's' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={hotelDesc}
                  onChange={(e) => setHotelDesc(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Check-in Time</Label>
                  <Input
                    type="time"
                    value={checkInTime}
                    onChange={(e) => setCheckInTime(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Check-out Time</Label>
                  <Input
                    type="time"
                    value={checkOutTime}
                    onChange={(e) => setCheckOutTime(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== CONTACT TAB ========== */}
        <TabsContent value="contact">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Phone className="h-5 w-5 text-emerald-600" />
                  Contact Information
                </CardTitle>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => handleSave('contact')}
                  disabled={saving}
                >
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Email Address</Label>
                  <Input
                    type="email"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input
                    value={contactWebsite}
                    onChange={(e) => setContactWebsite(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Emergency Contact</Label>
                  <Input
                    value={emergencyContact}
                    onChange={(e) => setEmergencyContact(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== FACILITIES TAB ========== */}
        <TabsContent value="facilities">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wifi className="h-5 w-5 text-emerald-600" />
                  Facilities & Amenities
                </CardTitle>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => handleSave('facilities')}
                  disabled={saving}
                >
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {facilityList.map(({ key, label, icon: Icon }) => (
                  <div
                    key={key}
                    className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <Label className="cursor-pointer" htmlFor={`facility-${key}`}>
                        {label}
                      </Label>
                    </div>
                    <Switch
                      id={`facility-${key}`}
                      checked={facilities[key] || false}
                      onCheckedChange={() => toggleFacility(key)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== POLICIES TAB ========== */}
        <TabsContent value="policies">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="h-5 w-5 text-emerald-600" />
                  Hotel Policies
                </CardTitle>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => handleSave('policies')}
                  disabled={saving}
                >
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Check-in Policy</Label>
                <Textarea
                  value={checkInPolicy}
                  onChange={(e) => setCheckInPolicy(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label>Cancellation Policy</Label>
                <Textarea
                  value={cancellationPolicy}
                  onChange={(e) => setCancellationPolicy(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label>Child Policy</Label>
                <Textarea
                  value={childPolicy}
                  onChange={(e) => setChildPolicy(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label>Payment Policy</Label>
                <Textarea
                  value={paymentPolicy}
                  onChange={(e) => setPaymentPolicy(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== BANK DETAILS TAB ========== */}
        <TabsContent value="bank-details">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Landmark className="h-5 w-5 text-emerald-600" />
                  Bank Details
                </CardTitle>
                <Button
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => handleSave('bank-details')}
                  disabled={saving}
                >
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Save
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Bank Name</Label>
                  <Input
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Account Name</Label>
                  <Input
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Account Number</Label>
                  <Input
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>IFSC Code</Label>
                  <Input
                    value={ifsc}
                    onChange={(e) => setIfsc(e.target.value)}
                    className="font-mono uppercase"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>UPI ID</Label>
                <Input
                  value={upi}
                  onChange={(e) => setUpi(e.target.value)}
                  className="font-mono"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== SECURITY TAB ========== */}
        <TabsContent value="security">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-emerald-600" />
                  Change Password
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="max-w-md space-y-4">
                  <div className="space-y-2">
                    <Label>Current Password</Label>
                    <Input
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>New Password</Label>
                    <Input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Confirm New Password</Label>
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm new password"
                    />
                  </div>
                  <Button
                    className="bg-emerald-600 hover:bg-emerald-700"
                    onClick={handleChangePassword}
                  >
                    Update Password
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-teal-600" />
                  Two-Factor Authentication
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between max-w-md">
                  <div>
                    <p className="font-medium text-sm">Enable 2FA</p>
                    <p className="text-xs text-muted-foreground">
                      Add an extra layer of security to your account.
                    </p>
                  </div>
                  <Switch checked={twoFA} onCheckedChange={setTwoFA} />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

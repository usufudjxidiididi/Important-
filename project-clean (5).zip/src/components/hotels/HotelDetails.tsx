'use client';

import { useEffect, useState, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { Hotel, Room, Booking, Review, HotelStatus } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Star,
  Check,
  X,
  Ban,
  RotateCcw,
  Pencil,
  MapPin,
  Mail,
  Phone,
  Clock,
  Building2,
  Wifi,
  Car,
  UtensilsCrossed,
  Waves,
  Sparkles,
  PawPrint,
  BedDouble,
  Users,
  DollarSign,
  MessageSquare,
  CalendarDays,
  Inbox,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function formatDateTime(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function getStatusBadge(status: HotelStatus) {
  switch (status) {
    case 'approved':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
          Approved
        </Badge>
      );
    case 'pending':
      return (
        <Badge className="bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100">
          Pending
        </Badge>
      );
    case 'rejected':
      return (
        <Badge className="bg-red-100 text-red-700 border-red-200 hover:bg-red-100">
          Rejected
        </Badge>
      );
    case 'suspended':
      return (
        <Badge className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-100">
          Suspended
        </Badge>
      );
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

const AMENITY_ICONS: Record<string, { icon: React.ReactNode; label: string }> = {
  wifi: { icon: <Wifi className="size-4" />, label: 'WiFi' },
  parking: { icon: <Car className="size-4" />, label: 'Parking' },
  restaurant: { icon: <UtensilsCrossed className="size-4" />, label: 'Restaurant' },
  pool: { icon: <Waves className="size-4" />, label: 'Swimming Pool' },
  spa: { icon: <Sparkles className="size-4" />, label: 'Spa' },
  'pet-friendly': { icon: <PawPrint className="size-4" />, label: 'Pet Friendly' },
};

function StarRating({ rating, size = 'md' }: { rating: number; size?: 'sm' | 'md' | 'lg' }) {
  const iconSize = size === 'sm' ? 'size-3.5' : size === 'lg' ? 'size-6' : 'size-4.5';
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`${iconSize} ${
            i < rating
              ? 'fill-amber-400 text-amber-400'
              : 'fill-muted text-muted'
          }`}
        />
      ))}
    </div>
  );
}

function ReviewStars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`size-3.5 ${
            i < rating
              ? 'fill-amber-400 text-amber-400'
              : 'fill-muted text-muted'
          }`}
        />
      ))}
    </div>
  );
}

function parseAmenities(amenitiesStr?: string): string[] {
  if (!amenitiesStr) return [];
  try {
    const parsed = JSON.parse(amenitiesStr);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    // If it's not valid JSON, treat as comma-separated
    return amenitiesStr.split(',').map((s) => s.trim()).filter(Boolean);
  }
}

function getBookingStatusBadge(status: string) {
  const map: Record<string, string> = {
    pending: 'bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100',
    confirmed: 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100',
    checked_in: 'bg-teal-100 text-teal-700 border-teal-200 hover:bg-teal-100',
    checked_out: 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-100',
    cancelled: 'bg-red-100 text-red-700 border-red-200 hover:bg-red-100',
    no_show: 'bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-100',
  };
  const label = status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  return (
    <Badge className={map[status] || 'bg-muted text-muted-foreground'}>
      {label}
    </Badge>
  );
}

// ---------- component ----------

export default function HotelDetails() {
  const {
    selectedHotelId,
    currentHotel,
    setCurrentHotel,
    setCurrentView,
    updateHotelStatus,
    bookings,
    reviews: storeReviews,
    setRooms,
    rooms,
  } = useAppStore();

  const [loading, setLoading] = useState(true);
  const [hotelRooms, setHotelRooms] = useState<Room[]>([]);
  const [roomsLoading, setRoomsLoading] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState<Record<string, string | number | boolean>>({});

  // Safe string accessor for form values
  const fv = (key: string) => String(editForm[key] ?? '');

  // Open edit dialog pre-filled with current hotel data
  const openEditDialog = () => {
    if (!currentHotel) return;
    setEditForm({
      name: currentHotel.name || '',
      brand: currentHotel.brand || '',
      registrationNumber: currentHotel.registrationNumber || '',
      gst: currentHotel.gst || '',
      ownerName: currentHotel.ownerName || '',
      contactPerson: currentHotel.contactPerson || '',
      email: currentHotel.email || '',
      phone: currentHotel.phone || '',
      address: currentHotel.address || '',
      city: currentHotel.city || '',
      state: currentHotel.state || '',
      country: currentHotel.country || '',
      pincode: currentHotel.pincode || '',
      description: currentHotel.description || '',
      starRating: currentHotel.starRating || 3,
      checkInTime: currentHotel.checkInTime || '14:00',
      checkOutTime: currentHotel.checkOutTime || '11:00',
      amenities: currentHotel.amenities || '',
      policies: currentHotel.policies || '',
      commissionRate: currentHotel.commissionRate || 10,
      hasParking: currentHotel.hasParking || false,
      hasRestaurant: currentHotel.hasRestaurant || false,
      hasPool: currentHotel.hasPool || false,
      hasSpa: currentHotel.hasSpa || false,
      hasWiFi: currentHotel.hasWiFi || false,
      allowsPets: currentHotel.allowsPets || false,
    });
    setEditOpen(true);
  };

  // Save edited hotel
  const handleSaveEdit = async () => {
    if (!currentHotel) return;
    try {
      setSaving(true);
      const res = await fetch(`/api/hotels/${currentHotel.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      });
      if (!res.ok) throw new Error('Failed to update hotel');
      const updated: Hotel = await res.json();
      setCurrentHotel(updated);
      setEditOpen(false);
      toast.success('Hotel details updated successfully');
    } catch {
      toast.error('Failed to update hotel details');
    } finally {
      setSaving(false);
    }
  };

  // Fetch hotel details
  useEffect(() => {
    if (!selectedHotelId) {
      setLoading(false);
      return;
    }

    async function fetchHotel() {
      try {
        setLoading(true);
        const res = await fetch(`/api/hotels/${selectedHotelId}`);
        if (!res.ok) throw new Error('Failed to fetch hotel');
        const data: Hotel = await res.json();
        setCurrentHotel(data);
      } catch {
        toast.error('Failed to load hotel details');
      } finally {
        setLoading(false);
      }
    }
    fetchHotel();
  }, [selectedHotelId, setCurrentHotel]);

  // Fetch rooms for this hotel
  useEffect(() => {
    if (!selectedHotelId) return;

    async function fetchRooms() {
      try {
        setRoomsLoading(true);
        const res = await fetch(`/api/rooms?hotelId=${selectedHotelId}`);
        if (!res.ok) throw new Error('Failed to fetch rooms');
        const data: Room[] = await res.json();
        setHotelRooms(data);
        setRooms(data);
      } catch {
        toast.error('Failed to load rooms');
      } finally {
        setRoomsLoading(false);
      }
    }
    fetchRooms();
  }, [selectedHotelId, setRooms]);

  // Hotel bookings from store
  const hotelBookings = bookings.filter(
    (b) => b.hotelId === selectedHotelId
  );

  // Hotel reviews from store
  const hotelReviews = storeReviews.filter(
    (r) => r.hotelId === selectedHotelId
  );

  // Status change
  const handleStatusChange = useCallback(
    async (newStatus: HotelStatus, label: string) => {
      if (!currentHotel) return;
      try {
        const res = await fetch(`/api/hotels/${currentHotel.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus }),
        });
        if (!res.ok) throw new Error('Failed to update status');
        updateHotelStatus(currentHotel.id, newStatus);
        toast.success(`Hotel ${label.toLowerCase()} successfully`);
      } catch {
        toast.error(`Failed to ${label.toLowerCase()} hotel`);
      }
    },
    [currentHotel, updateHotelStatus]
  );

  // No hotel selected
  if (!selectedHotelId) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <Building2 className="size-12 mb-3 opacity-40" />
        <p className="text-lg font-medium">No hotel selected</p>
        <p className="text-sm mt-1">Select a hotel from the management list to view details</p>
        <Button
          variant="outline"
          className="mt-4 text-teal-600 border-teal-200 hover:bg-teal-50"
          onClick={() => setCurrentView('hotel-management')}
        >
          <ArrowLeft className="size-4 mr-1" />
          Back to Hotels
        </Button>
      </div>
    );
  }

  // Loading
  if (loading || !currentHotel) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="flex flex-col items-center gap-2 text-muted-foreground">
          <Building2 className="size-8 animate-pulse" />
          <span>Loading hotel details...</span>
        </div>
      </div>
    );
  }

  const hotel = currentHotel;
  const amenities = parseAmenities(hotel.amenities);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            onClick={() => setCurrentView('hotel-management')}
          >
            <ArrowLeft className="size-5" />
          </Button>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl font-bold tracking-tight text-foreground truncate">
                {hotel.name}
              </h1>
              <StarRating rating={hotel.starRating} size="lg" />
              {getStatusBadge(hotel.status)}
            </div>
            <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
              <MapPin className="size-3.5" />
              <span>
                {[hotel.city, hotel.state, hotel.country].filter(Boolean).join(', ')}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Edit Button */}
            <Button
              variant="outline"
              size="sm"
              className="text-teal-600 border-teal-200 hover:bg-teal-50"
              onClick={openEditDialog}
            >
              <Pencil className="size-4" />
              Edit
            </Button>

            {/* Status change buttons */}
            {hotel.status === 'pending' && (
              <>
                <Button
                  size="sm"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  onClick={() => handleStatusChange('approved', 'Approved')}
                >
                  <Check className="size-4" />
                  Approve
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleStatusChange('rejected', 'Rejected')}
                >
                  <X className="size-4" />
                  Reject
                </Button>
              </>
            )}

            {hotel.status === 'approved' && (
              <Button
                variant="outline"
                size="sm"
                className="text-orange-600 border-orange-200 hover:bg-orange-50"
                onClick={() => handleStatusChange('suspended', 'Suspended')}
              >
                <Ban className="size-4" />
                Suspend
              </Button>
            )}

            {hotel.status === 'suspended' && (
              <Button
                size="sm"
                className="bg-teal-600 hover:bg-teal-700 text-white"
                onClick={() => handleStatusChange('approved', 'Activated')}
              >
                <RotateCcw className="size-4" />
                Activate
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-muted/60">
          <TabsTrigger value="overview" className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700">
            Overview
          </TabsTrigger>
          <TabsTrigger value="rooms" className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700">
            Rooms
          </TabsTrigger>
          <TabsTrigger value="bookings" className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700">
            Bookings
          </TabsTrigger>
          <TabsTrigger value="reviews" className="data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700">
            Reviews
          </TabsTrigger>
        </TabsList>

        {/* ========== OVERVIEW TAB ========== */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Description */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {hotel.description || 'No description available.'}
                </p>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-teal-50 text-teal-600">
                    <Mail className="size-4" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm font-medium">{hotel.email}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-teal-50 text-teal-600">
                    <Phone className="size-4" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm font-medium">{hotel.phone || 'N/A'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-teal-50 text-teal-600">
                    <MapPin className="size-4" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Address</p>
                    <p className="text-sm font-medium">
                      {[hotel.address, hotel.city, hotel.state, hotel.pincode, hotel.country]
                        .filter(Boolean)
                        .join(', ')}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-teal-50 text-teal-600">
                    <Clock className="size-4" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Check-in / Check-out</p>
                    <p className="text-sm font-medium">
                      {hotel.checkInTime} / {hotel.checkOutTime}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-dashed">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <BedDouble className="size-4" /> Total Rooms
                  </span>
                  <span className="text-sm font-semibold">{hotel.totalRooms ?? 0}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-dashed">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <BedDouble className="size-4" /> Available Rooms
                  </span>
                  <span className="text-sm font-semibold text-emerald-600">{hotel.availableRooms ?? 0}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-dashed">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Users className="size-4" /> Occupancy Rate
                  </span>
                  <span className="text-sm font-semibold">{hotel.occupancyRate != null ? `${hotel.occupancyRate}%` : 'N/A'}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-dashed">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <DollarSign className="size-4" /> Monthly Revenue
                  </span>
                  <span className="text-sm font-semibold text-emerald-600">{formatINR(hotel.monthlyRevenue ?? 0)}</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-dashed">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <CalendarDays className="size-4" /> Total Bookings
                  </span>
                  <span className="text-sm font-semibold">{hotel.bookingCount ?? 0}</span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Star className="size-4" /> Average Rating
                  </span>
                  <span className="text-sm font-semibold">{hotel.avgRating != null ? hotel.avgRating.toFixed(1) : 'N/A'}</span>
                </div>
              </CardContent>
            </Card>

            {/* Amenities */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">Amenities</CardTitle>
                <CardDescription>Facilities and services available at this hotel</CardDescription>
              </CardHeader>
              <CardContent>
                {amenities.length > 0 ? (
                  <div className="flex flex-wrap gap-3">
                    {amenities.map((amenity, idx) => {
                      const key = amenity.toLowerCase().replace(/[^a-z]/g, '');
                      const matched = AMENITY_ICONS[key] || AMENITY_ICONS[amenity.toLowerCase()];
                      return (
                        <div
                          key={idx}
                          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-100 text-sm text-emerald-700"
                        >
                          {matched ? matched.icon : <Sparkles className="size-4" />}
                          <span className="capitalize">{matched ? matched.label : amenity}</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No amenities listed.</p>
                )}
              </CardContent>
            </Card>

            {/* Policies */}
            {hotel.policies && (
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle className="text-base">Policies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                    {hotel.policies}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* ========== ROOMS TAB ========== */}
        <TabsContent value="rooms">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Hotel Rooms</CardTitle>
              <CardDescription>
                {hotelRooms.length} room{hotelRooms.length !== 1 ? 's' : ''} configured
              </CardDescription>
            </CardHeader>
            <CardContent>
              {roomsLoading ? (
                <div className="flex items-center justify-center py-12 text-muted-foreground">
                  <span>Loading rooms...</span>
                </div>
              ) : hotelRooms.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Inbox className="size-10 mb-2 opacity-40" />
                  <p className="text-sm">No rooms configured for this hotel</p>
                </div>
              ) : (
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/40 hover:bg-muted/40">
                        <TableHead>Room Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Bed Type</TableHead>
                        <TableHead className="text-right">Base Price</TableHead>
                        <TableHead className="text-right">Max Guests</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {hotelRooms.map((room) => (
                        <TableRow key={room.id}>
                          <TableCell className="font-medium">{room.name}</TableCell>
                          <TableCell className="text-muted-foreground capitalize">
                            {room.description || '-'}
                          </TableCell>
                          <TableCell className="text-muted-foreground capitalize">
                            {room.bedType}
                          </TableCell>
                          <TableCell className="text-right font-medium text-emerald-600">
                            {formatINR(room.basePrice)}
                          </TableCell>
                          <TableCell className="text-right">
                            {room.maxAdults} adults{room.maxChildren > 0 ? ` + ${room.maxChildren} children` : ''}
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                room.status === 'active'
                                  ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }
                            >
                              {room.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== BOOKINGS TAB ========== */}
        <TabsContent value="bookings">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Bookings</CardTitle>
              <CardDescription>
                {hotelBookings.length} booking{hotelBookings.length !== 1 ? 's' : ''} found
              </CardDescription>
            </CardHeader>
            <CardContent>
              {hotelBookings.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <CalendarDays className="size-10 mb-2 opacity-40" />
                  <p className="text-sm">No bookings found for this hotel</p>
                </div>
              ) : (
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/40 hover:bg-muted/40">
                        <TableHead>Booking #</TableHead>
                        <TableHead>Guest</TableHead>
                        <TableHead>Room</TableHead>
                        <TableHead>Check-in</TableHead>
                        <TableHead>Check-out</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Payment</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {hotelBookings.map((booking) => (
                        <TableRow key={booking.id}>
                          <TableCell className="font-medium font-mono text-xs">
                            {booking.bookingNumber}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium text-sm">{booking.customerName}</p>
                              <p className="text-xs text-muted-foreground">{booking.customerEmail}</p>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground text-sm">
                            {booking.roomName || '-'}
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(booking.checkIn)}
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(booking.checkOut)}
                          </TableCell>
                          <TableCell className="text-right font-medium text-emerald-600">
                            {formatINR(booking.totalAmount)}
                          </TableCell>
                          <TableCell>{getBookingStatusBadge(booking.status)}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                booking.paymentStatus === 'paid'
                                  ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  : booking.paymentStatus === 'refunded'
                                  ? 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-100'
                                  : 'bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100'
                              }
                            >
                              {booking.paymentStatus}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== REVIEWS TAB ========== */}
        <TabsContent value="reviews">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold">Guest Reviews</h3>
                <p className="text-sm text-muted-foreground">
                  {hotelReviews.length} review{hotelReviews.length !== 1 ? 's' : ''}
                </p>
              </div>
              {hotel.avgRating != null && (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-100">
                  <Star className="size-4 fill-amber-400 text-amber-400" />
                  <span className="text-sm font-semibold text-amber-700">
                    {hotel.avgRating.toFixed(1)} avg
                  </span>
                </div>
              )}
            </div>

            {hotelReviews.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <MessageSquare className="size-10 mb-2 opacity-40" />
                  <p className="text-sm">No reviews yet for this hotel</p>
                </CardContent>
              </Card>
            ) : (
              hotelReviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="font-medium text-sm">{review.customerName}</span>
                          <ReviewStars rating={review.rating} />
                        </div>
                        {review.comment && (
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {review.comment}
                          </p>
                        )}
                        {review.reply && (
                          <div className="mt-3 ml-4 pl-4 border-l-2 border-emerald-200">
                            <p className="text-xs font-medium text-emerald-700 mb-1">Hotel Reply</p>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              {review.reply}
                            </p>
                          </div>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {formatDateTime(review.createdAt)}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Hotel Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Hotel Details</DialogTitle>
            <DialogDescription>Update hotel information. Changes will be saved immediately.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {/* Row 1: Name, Brand */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Hotel Name *</Label>
                <Input id="edit-name" value={fv('name')} onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-brand">Brand</Label>
                <Input id="edit-brand" value={fv('brand')} onChange={(e) => setEditForm((f) => ({ ...f, brand: e.target.value }))} />
              </div>
            </div>

            {/* Row 2: Registration, GST */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-reg">Registration Number</Label>
                <Input id="edit-reg" value={fv('registrationNumber')} onChange={(e) => setEditForm((f) => ({ ...f, registrationNumber: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-gst">GST Number</Label>
                <Input id="edit-gst" value={fv('gst')} onChange={(e) => setEditForm((f) => ({ ...f, gst: e.target.value }))} />
              </div>
            </div>

            {/* Row 3: Owner, Contact Person */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-owner">Owner Name</Label>
                <Input id="edit-owner" value={fv('ownerName')} onChange={(e) => setEditForm((f) => ({ ...f, ownerName: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-contact">Contact Person</Label>
                <Input id="edit-contact" value={fv('contactPerson')} onChange={(e) => setEditForm((f) => ({ ...f, contactPerson: e.target.value }))} />
              </div>
            </div>

            {/* Row 4: Email, Phone */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-email">Email *</Label>
                <Input id="edit-email" type="email" value={fv('email')} onChange={(e) => setEditForm((f) => ({ ...f, email: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-phone">Phone</Label>
                <Input id="edit-phone" value={fv('phone')} onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value }))} />
              </div>
            </div>

            {/* Row 5: Address */}
            <div className="space-y-2">
              <Label htmlFor="edit-address">Address</Label>
              <Input id="edit-address" value={fv('address')} onChange={(e) => setEditForm((f) => ({ ...f, address: e.target.value }))} />
            </div>

            {/* Row 6: City, State, Pincode, Country */}
            <div className="grid grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-city">City</Label>
                <Input id="edit-city" value={fv('city')} onChange={(e) => setEditForm((f) => ({ ...f, city: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-state">State</Label>
                <Input id="edit-state" value={fv('state')} onChange={(e) => setEditForm((f) => ({ ...f, state: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-pincode">Pincode</Label>
                <Input id="edit-pincode" value={fv('pincode')} onChange={(e) => setEditForm((f) => ({ ...f, pincode: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-country">Country</Label>
                <Input id="edit-country" value={fv('country')} onChange={(e) => setEditForm((f) => ({ ...f, country: e.target.value }))} />
              </div>
            </div>

            {/* Row 7: Description */}
            <div className="space-y-2">
              <Label htmlFor="edit-desc">Description</Label>
              <Textarea id="edit-desc" rows={3} value={fv('description')} onChange={(e) => setEditForm((f) => ({ ...f, description: e.target.value }))} />
            </div>

            {/* Row 8: Star Rating, Commission, Check-in/out */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-stars">Star Rating</Label>
                <Select value={String(editForm.starRating || 3)} onValueChange={(v) => setEditForm((f) => ({ ...f, starRating: Number(v) }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5].map((s) => (
                      <SelectItem key={s} value={String(s)}>{s} Star{s > 1 ? 's' : ''}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-commission">Commission Rate (%)</Label>
                <Input id="edit-commission" type="number" min={0} max={100} value={Number(editForm.commissionRate) || 10} onChange={(e) => setEditForm((f) => ({ ...f, commissionRate: Number(e.target.value) }))} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-checkin">Check-in Time</Label>
                <Input id="edit-checkin" type="time" value={fv('checkInTime') || '14:00'} onChange={(e) => setEditForm((f) => ({ ...f, checkInTime: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-checkout">Check-out Time</Label>
                <Input id="edit-checkout" type="time" value={fv('checkOutTime') || '11:00'} onChange={(e) => setEditForm((f) => ({ ...f, checkOutTime: e.target.value }))} />
              </div>
            </div>

            {/* Row 9: Amenities */}
            <div className="space-y-2">
              <Label htmlFor="edit-amenities">Amenities (comma-separated)</Label>
              <Input id="edit-amenities" placeholder="WiFi, Parking, Pool, Restaurant, Spa" value={fv('amenities')} onChange={(e) => setEditForm((f) => ({ ...f, amenities: e.target.value }))} />
            </div>

            {/* Row 10: Policies */}
            <div className="space-y-2">
              <Label htmlFor="edit-policies">Policies</Label>
              <Textarea id="edit-policies" rows={2} value={fv('policies')} onChange={(e) => setEditForm((f) => ({ ...f, policies: e.target.value }))} />
            </div>

            {/* Row 11: Toggles */}
            <div className="grid grid-cols-3 gap-4">
              {(
                [
                  ['hasParking', 'Parking'],
                  ['hasRestaurant', 'Restaurant'],
                  ['hasPool', 'Swimming Pool'],
                  ['hasSpa', 'Spa'],
                  ['hasWiFi', 'WiFi'],
                  ['allowsPets', 'Pet Friendly'],
                ] as const
              ).map(([key, label]) => (
                <div key={key} className="flex items-center justify-between rounded-lg border px-3 py-2">
                  <Label className="text-sm cursor-pointer" htmlFor={`edit-${key}`}>{label}</Label>
                  <Switch id={`edit-${key}`} checked={!!editForm[key]} onCheckedChange={(checked) => setEditForm((f) => ({ ...f, [key]: checked }))} />
                </div>
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleSaveEdit} disabled={saving}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
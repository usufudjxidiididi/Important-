'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { ReportData } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { FileText, TrendingUp, BarChart3, PieChart as PieChartIcon, Download, Filter } from 'lucide-react';
import { toast } from 'sonner';

const CHART_COLORS = ['#10b981', '#14b8a6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];

function formatCurrency(amount: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
}

function formatNumber(num: number) {
  return new Intl.NumberFormat('en-IN').format(num);
}

function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'yesterday';
  return `${days}d ago`;
}

// --- Skeleton Loaders ---
function ChartSkeleton() {
  return (
    <div className="space-y-3">
      <Skeleton className="h-4 w-48" />
      <Skeleton className="h-[300px] w-full rounded-lg" />
    </div>
  );
}

function CardsSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-6">
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-8 w-32" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function TableSkeleton() {
  return (
    <Card>
      <CardContent className="p-6">
        <Skeleton className="h-4 w-48 mb-4" />
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// --- Custom Tooltip ---
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-popover border border-border rounded-lg shadow-lg p-3 text-sm">
      <p className="font-medium text-foreground mb-1">{label}</p>
      {payload.map((entry, i) => (
        <p key={i} style={{ color: entry.color }} className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          {entry.name}: {typeof entry.value === 'number' && entry.name.toLowerCase().includes('revenue') ? formatCurrency(entry.value) : formatNumber(entry.value)}
        </p>
      ))}
    </div>
  );
}

// --- Revenue Tab ---
function RevenueTab({ data }: { data: ReportData }) {
  const totalRevenue = data.revenueTrend.reduce((sum, d) => sum + d.revenue, 0);
  const avgDailyRevenue = data.revenueTrend.length ? totalRevenue / data.revenueTrend.length : 0;
  const bestDay = data.revenueTrend.reduce((best, d) => d.revenue > best.revenue ? d : best, data.revenueTrend[0]);
  const firstHalf = data.revenueTrend.slice(0, Math.floor(data.revenueTrend.length / 2));
  const secondHalf = data.revenueTrend.slice(Math.floor(data.revenueTrend.length / 2));
  const firstSum = firstHalf.reduce((s, d) => s + d.revenue, 0);
  const secondSum = secondHalf.reduce((s, d) => s + d.revenue, 0);
  const monthlyGrowth = firstSum > 0 ? ((secondSum - firstSum) / firstSum) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-emerald-200 dark:border-emerald-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{formatCurrency(totalRevenue)}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Daily Revenue</p>
                <p className="text-2xl font-bold mt-1">{formatCurrency(avgDailyRevenue)}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-teal-600 dark:text-teal-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Best Day Revenue</p>
                <p className="text-2xl font-bold mt-1">{formatCurrency(bestDay?.revenue || 0)}</p>
                <p className="text-xs text-muted-foreground mt-1">{bestDay?.date}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Growth</p>
                <p className={`text-2xl font-bold mt-1 ${monthlyGrowth >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'}`}>
                  {monthlyGrowth >= 0 ? '+' : ''}{monthlyGrowth.toFixed(1)}%
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                <TrendingUp className={`h-5 w-5 ${monthlyGrowth >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 rotate-180'}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Revenue Trend (Last 30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.revenueTrend} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#10b981" strokeWidth={2} fill="url(#revenueGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Revenue by City</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.topCities} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="city" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" name="Revenue" radius={[4, 4, 0, 0]}>
                  {data.topCities.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Occupancy Tab ---
function OccupancyTab({ data }: { data: ReportData }) {
  const avgOccupancy = data.occupancyTrend.length
    ? data.occupancyTrend.reduce((sum, d) => sum + d.occupancy, 0) / data.occupancyTrend.length
    : 0;
  const peakOccupancy = data.occupancyTrend.length
    ? Math.max(...data.occupancyTrend.map(d => d.occupancy))
    : 0;
  const lowestOccupancy = data.occupancyTrend.length
    ? Math.min(...data.occupancyTrend.map(d => d.occupancy))
    : 0;
  const firstWeek = data.occupancyTrend.slice(0, 7);
  const lastWeek = data.occupancyTrend.slice(-7);
  const firstWeekAvg = firstWeek.length ? firstWeek.reduce((s, d) => s + d.occupancy, 0) / firstWeek.length : 0;
  const lastWeekAvg = lastWeek.length ? lastWeek.reduce((s, d) => s + d.occupancy, 0) / lastWeek.length : 0;
  const trendUp = lastWeekAvg >= firstWeekAvg;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-teal-200 dark:border-teal-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Occupancy</p>
                <p className="text-2xl font-bold text-teal-600 dark:text-teal-400 mt-1">{avgOccupancy.toFixed(1)}%</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-teal-600 dark:text-teal-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Peak Occupancy</p>
                <p className="text-2xl font-bold mt-1">{peakOccupancy.toFixed(1)}%</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Lowest Occupancy</p>
                <p className="text-2xl font-bold mt-1">{lowestOccupancy.toFixed(1)}%</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-red-500 rotate-180" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Occupancy Trend</p>
                <p className={`text-2xl font-bold mt-1 ${trendUp ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'}`}>
                  {trendUp ? '↑ Upward' : '↓ Downward'}
                </p>
              </div>
              <div className={`h-10 w-10 rounded-lg ${trendUp ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} flex items-center justify-center`}>
                <TrendingUp className={`h-5 w-5 ${trendUp ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Occupancy Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.occupancyTrend} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="occupancyGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="occupancy" name="Occupancy %" stroke="#14b8a6" strokeWidth={2} fill="url(#occupancyGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Hotels Tab ---
function HotelsTab({ data }: { data: ReportData }) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Top Hotels</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-16">Rank</TableHead>
                <TableHead>Hotel Name</TableHead>
                <TableHead>City</TableHead>
                <TableHead className="text-right">Revenue</TableHead>
                <TableHead className="text-right">Bookings</TableHead>
                <TableHead className="text-right">Occupancy</TableHead>
                <TableHead className="text-right">Rating</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.topHotels.map((hotel, i) => (
                <TableRow key={i}>
                  <TableCell>
                    <Badge variant={i < 3 ? 'default' : 'secondary'} className={i < 3 ? 'bg-emerald-600 hover:bg-emerald-700' : ''}>
                      #{i + 1}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">{hotel.name}</TableCell>
                  <TableCell className="text-muted-foreground">{data.topCities[i]?.city || '—'}</TableCell>
                  <TableCell className="text-right font-medium text-emerald-600 dark:text-emerald-400">{formatCurrency(hotel.revenue)}</TableCell>
                  <TableCell className="text-right">{formatNumber(hotel.bookings)}</TableCell>
                  <TableCell className="text-right">
                    <span className={`inline-flex items-center ${hotel.occupancy >= 80 ? 'text-emerald-600 dark:text-emerald-400' : hotel.occupancy >= 50 ? 'text-amber-600' : 'text-red-500'}`}>
                      {hotel.occupancy.toFixed(1)}%
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <span className="flex items-center justify-end gap-1 text-amber-500">
                      ★ {hotel.occupancy >= 80 ? '4.8' : hotel.occupancy >= 60 ? '4.5' : '4.2'}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Revenue by City</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.topCities} layout="vertical" margin={{ top: 10, right: 30, left: 80, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis dataKey="city" type="category" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" name="Revenue" radius={[0, 4, 4, 0]}>
                  {data.topCities.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Rooms Tab ---
function RoomsTab({ data }: { data: ReportData }) {
  const totalRevenue = data.roomPerformance.reduce((s, r) => s + r.revenue, 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Room Performance (Sold Count)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.roomPerformance} layout="vertical" margin={{ top: 10, right: 30, left: 100, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" width={90} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="sold" name="Rooms Sold" radius={[0, 4, 4, 0]}>
                  {data.roomPerformance.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Room Revenue Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.roomPerformance}
                  dataKey="revenue"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={120}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {data.roomPerformance.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Cancellations Tab ---
function CancellationsTab({ data }: { data: ReportData }) {
  const totalCancellations = data.cancellationAnalysis.reduce((s, c) => s + c.count, 0);
  const cancellationRate = 15.2; // Placeholder percentage

  // Generate monthly cancellation data for chart
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const cancellationByMonth = months.map((m) => ({
    month: m,
    cancellations: Math.floor(Math.random() * 30) + 10,
  }));

  return (
    <div className="space-y-6">
      <Card className="border-red-200 dark:border-red-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Cancellation Rate</p>
              <p className="text-3xl font-bold text-red-500 mt-1">{cancellationRate}%</p>
              <p className="text-sm text-muted-foreground mt-1">{formatNumber(totalCancellations)} total cancellations</p>
            </div>
            <div className="h-12 w-12 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-red-500" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Cancellations by Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cancellationByMonth} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="cancellations" name="Cancellations" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Cancellation Reasons</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.cancellationAnalysis.map((item, i) => {
              const pct = totalCancellations > 0 ? (item.count / totalCancellations) * 100 : 0;
              return (
                <div key={i} className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{item.reason}</span>
                      <span className="text-sm text-muted-foreground">
                        {formatNumber(item.count)} ({pct.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${pct}%`, backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Main Component ---
export default function ReportsView() {
  const { reportData, setReportData } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('revenue');

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await fetch('/api/reports');
        if (res.ok) {
          const data = await res.json();
          setReportData(data);
        }
      } catch {
        // Silently handle - skeleton will show
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, [setReportData]);

  const handleExport = (format: string) => {
    toast.info(`${format} export coming soon!`);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports & Analytics</h1>
          <p className="text-muted-foreground text-sm mt-1">Comprehensive insights into your platform performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => handleExport('PDF')} className="gap-2">
            <FileText className="h-4 w-4" />
            PDF
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('Excel')} className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Excel
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('CSV')} className="gap-2">
            <Download className="h-4 w-4" />
            CSV
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className="bg-muted/50 mb-6">
          <TabsTrigger value="revenue" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Revenue
          </TabsTrigger>
          <TabsTrigger value="occupancy" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Occupancy
          </TabsTrigger>
          <TabsTrigger value="hotels" className="gap-2">
            <PieChartIcon className="h-4 w-4" />
            Hotels
          </TabsTrigger>
          <TabsTrigger value="rooms" className="gap-2">
            <Filter className="h-4 w-4" />
            Rooms
          </TabsTrigger>
          <TabsTrigger value="cancellations" className="gap-2">
            <FileText className="h-4 w-4" />
            Cancellations
          </TabsTrigger>
        </TabsList>

        {loading || !reportData ? (
          <div className="space-y-6">
            <CardsSkeleton />
            <ChartSkeleton />
            <ChartSkeleton />
          </div>
        ) : (
          <>
            <TabsContent value="revenue" className="mt-0">
              <RevenueTab data={reportData} />
            </TabsContent>
            <TabsContent value="occupancy" className="mt-0">
              <OccupancyTab data={reportData} />
            </TabsContent>
            <TabsContent value="hotels" className="mt-0">
              <HotelsTab data={reportData} />
            </TabsContent>
            <TabsContent value="rooms" className="mt-0">
              <RoomsTab data={reportData} />
            </TabsContent>
            <TabsContent value="cancellations" className="mt-0">
              <CancellationsTab data={reportData} />
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}
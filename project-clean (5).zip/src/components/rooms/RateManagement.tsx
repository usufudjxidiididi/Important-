'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { Room } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  Building2,
  BedDouble,
  DollarSign,
  Loader2,
  PackageSearch,
  IndianRupee,
  Tag,
  Clock,
  Users,
  Percent,
  Save,
  Layers,
} from 'lucide-react';

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const FULL_DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Mock holiday dates (month-day format for demo)
const HOLIDAY_DATES = ['01-26', '08-15', '10-02', '11-01', '12-25'];

function getNext7Days(): Date[] {
  const days: Date[] = [];
  const today = new Date();
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    days.push(d);
  }
  return days;
}

function formatDateStr(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function isWeekend(d: Date): boolean {
  return d.getDay() === 0 || d.getDay() === 6;
}

function isHoliday(d: Date): boolean {
  const key = `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return HOLIDAY_DATES.includes(key);
}

interface DayPrice {
  date: Date;
  price: number;
}

interface PricingRule {
  weekendMarkup: number;
  seasonalMarkup: number;
  holidayMarkup: number;
  extraAdultFee: number;
  extraChildFee: number;
  minStay: number;
  maxStay: number;
}

export default function RateManagement() {
  const { hotels } = useAppStore();

  const [selectedHotelId, setSelectedHotelId] = useState<string>('');
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  // Pricing rules
  const [rules, setRules] = useState<PricingRule>({
    weekendMarkup: 20,
    seasonalMarkup: 15,
    holidayMarkup: 30,
    extraAdultFee: 500,
    extraChildFee: 300,
    minStay: 1,
    maxStay: 7,
  });

  // Daily prices for the week
  const next7Days = useMemo(() => getNext7Days(), []);
  const [dayPrices, setDayPrices] = useState<DayPrice[]>([]);

  const approvedHotels = useMemo(
    () => hotels.filter((h) => h.status === 'approved'),
    [hotels]
  );

  // Fetch rooms when hotel selected
  useEffect(() => {
    if (!selectedHotelId) {
      setRooms([]);
      setSelectedRoomId('');
      setSelectedRoom(null);
      setDayPrices([]);
      return;
    }
    async function fetchRooms() {
      try {
        setLoading(true);
        const res = await fetch(`/api/rooms?hotelId=${selectedHotelId}`);
        if (!res.ok) throw new Error('Failed to fetch rooms');
        const data: Room[] = await res.json();
        setRooms(data);
      } catch {
        toast.error('Failed to load rooms');
        setRooms([]);
      } finally {
        setLoading(false);
      }
    }
    fetchRooms();
  }, [selectedHotelId]);

  // Set room and initialize prices when room selected
  useEffect(() => {
    if (!selectedRoomId) {
      setSelectedRoom(null);
      setDayPrices([]);
      return;
    }
    const room = rooms.find((r) => r.id === selectedRoomId) ?? null;
    setSelectedRoom(room);
    if (room) {
      const prices = next7Days.map((d) => ({
        date: d,
        price: isWeekend(d)
          ? Math.round(room.basePrice * (1 + (rules.weekendMarkup || 20) / 100))
          : room.basePrice,
      }));
      setDayPrices(prices);
    }
  }, [selectedRoomId, rooms, rules.weekendMarkup, next7Days]);

  // Update a single day price
  const handlePriceChange = useCallback((index: number, value: string) => {
    const numVal = Number(value) || 0;
    setDayPrices((prev) =>
      prev.map((dp, i) => (i === index ? { ...dp, price: numVal } : dp))
    );
  }, []);

  // Handle rule changes
  const handleRuleChange = useCallback((key: keyof PricingRule, value: string) => {
    setRules((prev) => ({ ...prev, [key]: Number(value) || 0 }));
  }, []);

  // Apply to all rooms
  const handleApplyToAll = useCallback(() => {
    toast.success(`Pricing rules applied to all ${rooms.length} rooms`);
  }, [rooms.length]);

  // Save
  const handleSave = useCallback(() => {
    toast.success('Rates saved successfully');
  }, []);

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Rate Management</h1>
        <p className="text-sm text-gray-500 mt-1">Configure pricing and rate rules for hotel rooms</p>
      </div>

      {/* Selectors */}
      <Card className="border-0 shadow-sm">
        <CardContent className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4">
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-emerald-600" />
            <Label className="font-medium text-gray-700">Hotel</Label>
          </div>
          <Select value={selectedHotelId} onValueChange={setSelectedHotelId}>
            <SelectTrigger className="w-full sm:w-64">
              <SelectValue placeholder="Choose a hotel..." />
            </SelectTrigger>
            <SelectContent>
              {approvedHotels.map((h) => (
                <SelectItem key={h.id} value={h.id}>
                  {h.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedHotelId && (
            <>
              <div className="flex items-center gap-2 ml-0 sm:ml-4">
                <BedDouble className="h-5 w-5 text-teal-600" />
                <Label className="font-medium text-gray-700">Room</Label>
              </div>
              <Select
                value={selectedRoomId}
                onValueChange={setSelectedRoomId}
                disabled={loading}
              >
                <SelectTrigger className="w-full sm:w-64">
                  <SelectValue placeholder={loading ? 'Loading...' : 'Choose a room...'} />
                </SelectTrigger>
                <SelectContent>
                  {rooms.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name} — ₹{r.basePrice.toLocaleString('en-IN')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </>
          )}
        </CardContent>
      </Card>

      {/* Weekly Calendar */}
      {selectedRoom && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-emerald-600" />
              Weekly Rate Calendar
              <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 ml-2">
                {selectedRoom.name}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-3">
              {dayPrices.map((dp, index) => {
                const weekend = isWeekend(dp.date);
                const holiday = isHoliday(dp.date);
                const cellBg = holiday
                  ? 'bg-red-50 border-red-200'
                  : weekend
                  ? 'bg-amber-50 border-amber-200'
                  : 'bg-white border-gray-200';
                return (
                  <div
                    key={index}
                    className={`rounded-lg border p-3 flex flex-col gap-2 ${cellBg}`}
                  >
                    <div className="text-center">
                      <p className="text-xs font-medium text-gray-500 uppercase">
                        {DAY_NAMES[dp.date.getDay()]}
                      </p>
                      <p className="text-sm font-semibold text-gray-800">
                        {dp.date.getDate()}/{dp.date.getMonth() + 1}
                      </p>
                    </div>
                    {holiday && (
                      <span className="text-[10px] font-medium text-red-600 bg-red-100 rounded px-1.5 py-0.5 text-center">
                        Holiday
                      </span>
                    )}
                    {weekend && !holiday && (
                      <span className="text-[10px] font-medium text-amber-600 bg-amber-100 rounded px-1.5 py-0.5 text-center">
                        Weekend
                      </span>
                    )}
                    <div className="relative">
                      <IndianRupee className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                      <Input
                        type="number"
                        min={0}
                        value={dp.price}
                        onChange={(e) => handlePriceChange(index, e.target.value)}
                        className="pl-7 h-8 text-sm text-center font-medium focus-visible:ring-emerald-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-4 mt-4 text-xs text-gray-500">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-white border border-gray-200" />
                Weekday
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-amber-50 border border-amber-200" />
                Weekend
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-red-50 border border-red-200" />
                Holiday
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pricing Rules */}
      {selectedRoom && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <Tag className="h-5 w-5 text-teal-600" />
              Pricing Rules
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Percent className="h-3.5 w-3.5 text-amber-600" />
                  Weekend Markup (%)
                </Label>
                <Input
                  type="number"
                  value={rules.weekendMarkup}
                  onChange={(e) => handleRuleChange('weekendMarkup', e.target.value)}
                  className="border-amber-200 focus-visible:ring-amber-500"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Percent className="h-3.5 w-3.5 text-emerald-600" />
                  Seasonal Markup (%)
                </Label>
                <Input
                  type="number"
                  value={rules.seasonalMarkup}
                  onChange={(e) => handleRuleChange('seasonalMarkup', e.target.value)}
                  className="border-emerald-200 focus-visible:ring-emerald-500"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Percent className="h-3.5 w-3.5 text-red-500" />
                  Holiday Markup (%)
                </Label>
                <Input
                  type="number"
                  value={rules.holidayMarkup}
                  onChange={(e) => handleRuleChange('holidayMarkup', e.target.value)}
                  className="border-red-200 focus-visible:ring-red-400"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Users className="h-3.5 w-3.5 text-teal-600" />
                  Extra Adult Fee (₹)
                </Label>
                <Input
                  type="number"
                  value={rules.extraAdultFee}
                  onChange={(e) => handleRuleChange('extraAdultFee', e.target.value)}
                  className="border-teal-200 focus-visible:ring-teal-500"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Users className="h-3.5 w-3.5 text-cyan-600" />
                  Extra Child Fee (₹)
                </Label>
                <Input
                  type="number"
                  value={rules.extraChildFee}
                  onChange={(e) => handleRuleChange('extraChildFee', e.target.value)}
                  className="border-cyan-200 focus-visible:ring-cyan-500"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Clock className="h-3.5 w-3.5 text-emerald-600" />
                  Min Stay (nights)
                </Label>
                <Input
                  type="number"
                  min={1}
                  value={rules.minStay}
                  onChange={(e) => handleRuleChange('minStay', e.target.value)}
                  className="border-emerald-200 focus-visible:ring-emerald-500"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-sm text-gray-700">
                  <Clock className="h-3.5 w-3.5 text-teal-600" />
                  Max Stay (nights)
                </Label>
                <Input
                  type="number"
                  min={1}
                  value={rules.maxStay}
                  onChange={(e) => handleRuleChange('maxStay', e.target.value)}
                  className="border-teal-200 focus-visible:ring-teal-500"
                />
              </div>
              <div className="flex items-end gap-2">
                <Button
                  variant="outline"
                  className="border-emerald-200 text-emerald-700 hover:bg-emerald-50 flex-1"
                  onClick={handleApplyToAll}
                >
                  <Layers className="h-4 w-4 mr-1.5" />
                  Apply to All Rooms
                </Button>
              </div>
            </div>
            <div className="flex justify-end mt-6">
              <Button
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={handleSave}
              >
                <Save className="h-4 w-4 mr-1.5" />
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty state */}
      {!selectedRoom && !loading && selectedHotelId && rooms.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardContent className="flex flex-col items-center justify-center py-16 text-gray-400">
            <DollarSign className="h-12 w-12 mb-3" />
            <p className="text-lg font-medium">Select a room to manage rates</p>
            <p className="text-sm">Choose a room from the dropdown above</p>
          </CardContent>
        </Card>
      )}

      {!selectedHotelId && (
        <Card className="border-0 shadow-sm">
          <CardContent className="flex flex-col items-center justify-center py-16 text-gray-400">
            <PackageSearch className="h-12 w-12 mb-3" />
            <p className="text-lg font-medium">Select a hotel to manage rates</p>
            <p className="text-sm">Choose a hotel from the dropdown above</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
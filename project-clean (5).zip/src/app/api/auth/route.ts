import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toSnake, generateId } from '@/lib/supabase';

/** Auto-seed: default admin credentials (only used if users table is empty) */
const DEFAULT_ADMIN = {
  name: 'Kartik Admin',
  email: 'kartikfutane515@gmail.com',
  password: 'kartik@12',
  role: 'super_admin',
};

export async function POST(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured. Set Supabase env vars in Vercel.' }, { status: 500 });
    }

    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required' }, { status: 400 });
    }

    // Check if users table has any users
    const { count } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true });

    // If no users exist, auto-create the default admin
    if (!count || count === 0) {
      const id = generateId();
      const { error: insertError } = await supabase
        .from('users')
        .insert({
          id,
          ...toSnake({
            name: DEFAULT_ADMIN.name,
            email: DEFAULT_ADMIN.email,
            password: DEFAULT_ADMIN.password,
            phone: null,
            role: DEFAULT_ADMIN.role,
            hotelId: null,
            partnerCode: null,
            isActive: true,
          }),
        });

      if (insertError) {
        console.error('Auto-seed admin error:', insertError);
        return NextResponse.json({
          error: 'Database setup failed. Please visit /setup to create your admin account manually.',
        }, { status: 500 });
      }
    }

    // Now try to find and authenticate the user
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email.toLowerCase().trim())
      .single();

    if (error || !data) {
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    // Verify password
    if (data.password !== password) {
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    // Check if user is active
    if (data.is_active === false) {
      return NextResponse.json({ error: 'Your account has been deactivated. Contact support.' }, { status: 403 });
    }

    const user = toCamel<Record<string, unknown>>(data);

    const userData = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      phone: user.phone,
      avatar: user.avatar,
      hotelId: user.hotelId,
      partnerCode: user.partnerCode || null,
      isActive: user.isActive,
    };

    const result: Record<string, unknown> = { user: userData };

    // Fetch hotel data separately if user has a hotel
    if (user.hotelId) {
      const { data: hotel } = await supabase
        .from('hotels')
        .select('*')
        .eq('id', user.hotelId)
        .maybeSingle();

      if (hotel) {
        result.hotel = toCamel(hotel);
      }
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toSnake, generateId } from '@/lib/supabase';

// GET /api/bank-account?hotelId=xxx
export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const hotelId = request.nextUrl.searchParams.get('hotelId');
    if (!hotelId) {
      return NextResponse.json({ error: 'hotelId is required' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('bank_accounts')
      .select('*')
      .eq('hotel_id', hotelId)
      .maybeSingle();

    if (error) {
      console.error('Bank account GET error:', error);
      return NextResponse.json({ error: 'Failed to load bank details' }, { status: 500 });
    }

    return NextResponse.json(data ? toCamel(data) : {});
  } catch (error) {
    console.error('Bank account GET error:', error);
    return NextResponse.json({ error: 'Failed to load bank details' }, { status: 500 });
  }
}

// PUT /api/bank-account - Create or update bank account
// Body: { hotelId, bankName, accountName, accountNumber, ifsc, upi }
export async function PUT(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const body = await request.json();
    const { hotelId, bankName, accountName, accountNumber, ifsc, upi } = body;

    if (!hotelId) {
      return NextResponse.json({ error: 'hotelId is required' }, { status: 400 });
    }

    const { data: existing, error: findError } = await supabase
      .from('bank_accounts')
      .select('id')
      .eq('hotel_id', hotelId)
      .maybeSingle();

    if (findError) {
      console.error('Bank account PUT error:', findError);
      return NextResponse.json({ error: 'Failed to save bank details' }, { status: 500 });
    }

    if (existing) {
      const { data, error } = await supabase
        .from('bank_accounts')
        .update(toSnake({ bankName, accountName, accountNumber, ifsc, upi }))
        .eq('id', existing.id)
        .select()
        .single();

      if (error) {
        console.error('Bank account PUT error:', error);
        return NextResponse.json({ error: 'Failed to save bank details' }, { status: 500 });
      }

      return NextResponse.json(toCamel(data));
    } else {
      const { data, error } = await supabase
        .from('bank_accounts')
        .insert({ ...toSnake({ hotelId, bankName, accountName, accountNumber, ifsc, upi }), id: generateId() })
        .select()
        .single();

      if (error) {
        console.error('Bank account PUT error:', error);
        return NextResponse.json({ error: 'Failed to save bank details' }, { status: 500 });
      }

      return NextResponse.json(toCamel(data));
    }
  } catch (error) {
    console.error('Bank account PUT error:', error);
    return NextResponse.json({ error: 'Failed to save bank details' }, { status: 500 });
  }
}

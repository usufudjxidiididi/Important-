'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Coupon } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import {
  Ticket,
  Package,
  Zap,
  Plus,
  Clock,
  BedDouble,
  Check,
} from 'lucide-react';

// ---------- mock data ----------

const mockPackages = [
  {
    id: 'p1',
    name: 'Honeymoon Bliss',
    description: 'Romantic getaway with candle-lit dinner and spa.',
    includes: ['Breakfast', 'Spa Access', 'Candle-light Dinner', 'Late Checkout'],
    price: 12999,
    duration: '2 Nights / 3 Days',
    status: 'active',
  },
  {
    id: 'p2',
    name: 'Family Fun',
    description: 'Perfect for families with kids activities and pool access.',
    includes: ['Breakfast', 'Kids Club', 'Pool Access', 'Airport Transfer'],
    price: 8499,
    duration: '3 Nights / 4 Days',
    status: 'active',
  },
  {
    id: 'p3',
    name: 'Business Executive',
    description: 'Work-friendly stay with meeting room and high-speed WiFi.',
    includes: ['Breakfast', 'Meeting Room', 'Laundry', 'Airport Transfer'],
    price: 6999,
    duration: '1 Night / 2 Days',
    status: 'active',
  },
  {
    id: 'p4',
    name: 'Wellness Retreat',
    description: 'Rejuvenate with yoga, spa treatments, and healthy meals.',
    includes: ['Healthy Meals', 'Yoga Session', 'Spa Treatment', 'Meditation'],
    price: 15999,
    duration: '3 Nights / 4 Days',
    status: 'inactive',
  },
];

const mockFlashSales = [
  {
    id: 'f1',
    name: 'Monsoon Special',
    discount: 35,
    timeRemaining: '2d 14h 30m',
    roomsIncluded: ['Deluxe Room', 'Premium Suite'],
    status: 'active',
  },
  {
    id: 'f2',
    name: 'Weekend Rush',
    discount: 25,
    timeRemaining: '5h 45m',
    roomsIncluded: ['Standard Room', 'Deluxe Room'],
    status: 'active',
  },
];

// ---------- component ----------

export default function PartnerPromotions() {
  const { user, setCoupons } = useAppStore();
  const hotelId = user?.hotelId;

  const [coupons, setLocalCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);

  // Coupon form
  const [couponDialogOpen, setCouponDialogOpen] = useState(false);
  const [couponForm, setCouponForm] = useState({
    code: '',
    description: '',
    discountType: 'percentage',
    discountValue: '',
    minBooking: '',
    maxDiscount: '',
    startDate: '',
    endDate: '',
    usageLimit: '',
  });

  useEffect(() => {
    if (!hotelId) return;

    const fetchCoupons = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/coupons?hotelId=${hotelId}`);
        if (res.ok) {
          const data = await res.json();
          const couponData = Array.isArray(data) ? data : [];
          setLocalCoupons(couponData);
          setCoupons(couponData);
        }
      } catch (err) {
        console.error('Failed to fetch coupons:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCoupons();
  }, [hotelId, setCoupons]);

  const handleCreateCoupon = () => {
    if (!couponForm.code || !couponForm.discountValue) {
      toast.error('Please fill in required fields');
      return;
    }
    toast.success(`Coupon ${couponForm.code} created`);
    setCouponDialogOpen(false);
    setCouponForm({
      code: '',
      description: '',
      discountType: 'percentage',
      discountValue: '',
      minBooking: '',
      maxDiscount: '',
      startDate: '',
      endDate: '',
      usageLimit: '',
    });
  };

  const toggleCouponStatus = (id: string) => {
    setLocalCoupons((prev) =>
      prev.map((c) =>
        c.id === id
          ? { ...c, status: c.status === 'active' ? 'inactive' : 'active' }
          : c
      )
    );
    toast.success('Coupon status updated');
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-10 w-40" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-40 rounded-xl" />
          <Skeleton className="h-40 rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Ticket className="h-6 w-6 text-emerald-600" />
        <h1 className="text-2xl font-bold">Promotions & Offers</h1>
      </div>

      <Tabs defaultValue="coupons" className="space-y-4">
        <TabsList>
          <TabsTrigger value="coupons">Coupons</TabsTrigger>
          <TabsTrigger value="packages">Packages</TabsTrigger>
          <TabsTrigger value="flash-sales">Flash Sales</TabsTrigger>
        </TabsList>

        {/* ========== COUPONS TAB ========== */}
        <TabsContent value="coupons" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={couponDialogOpen} onOpenChange={setCouponDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Coupon
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Create Coupon</DialogTitle>
                  <DialogDescription>
                    Add a new discount coupon for your hotel.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Coupon Code *</Label>
                      <Input
                        placeholder="e.g. SUMMER25"
                        value={couponForm.code}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })
                        }
                        className="font-mono"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Discount Type</Label>
                      <Select
                        value={couponForm.discountType}
                        onValueChange={(val) =>
                          setCouponForm({ ...couponForm, discountType: val })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">Percentage (%)</SelectItem>
                          <SelectItem value="fixed">Fixed Amount</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      placeholder="Brief description of the coupon"
                      value={couponForm.description}
                      onChange={(e) =>
                        setCouponForm({ ...couponForm, description: e.target.value })
                      }
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Discount Value *</Label>
                      <Input
                        type="number"
                        placeholder={couponForm.discountType === 'percentage' ? 'e.g. 25' : 'e.g. 500'}
                        value={couponForm.discountValue}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, discountValue: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Min Booking Amount</Label>
                      <Input
                        type="number"
                        placeholder="e.g. 2000"
                        value={couponForm.minBooking}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, minBooking: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Max Discount</Label>
                      <Input
                        type="number"
                        placeholder="e.g. 1000"
                        value={couponForm.maxDiscount}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, maxDiscount: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Usage Limit</Label>
                      <Input
                        type="number"
                        placeholder="e.g. 100"
                        value={couponForm.usageLimit}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, usageLimit: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={couponForm.startDate}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, startDate: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={couponForm.endDate}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, endDate: e.target.value })
                        }
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setCouponDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    className="bg-emerald-600 hover:bg-emerald-700"
                    onClick={handleCreateCoupon}
                  >
                    Create Coupon
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {coupons.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Ticket className="h-12 w-12 mx-auto text-muted-foreground/30" />
                <p className="mt-3 text-muted-foreground">No coupons created yet.</p>
                <p className="text-sm text-muted-foreground">
                  Create your first coupon to attract more guests.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {coupons.map((coupon) => (
                <Card key={coupon.id} className="relative">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <code className="text-lg font-mono font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded">
                          {coupon.code}
                        </code>
                        {coupon.description && (
                          <p className="text-sm text-muted-foreground">
                            {coupon.description}
                          </p>
                        )}
                      </div>
                      <Switch
                        checked={coupon.status === 'active'}
                        onCheckedChange={() => toggleCouponStatus(coupon.id)}
                      />
                    </div>
                    <div className="mt-4 flex flex-wrap gap-3 text-sm">
                      <Badge className="bg-teal-100 text-teal-700 hover:bg-teal-100 border-teal-200">
                        {coupon.discountType === 'percentage'
                          ? `${coupon.discountValue}% off`
                          : `\u20b9${coupon.discountValue} off`}
                      </Badge>
                      <span className="text-muted-foreground">
                        Min: \u20b9{coupon.minBooking.toLocaleString()}
                      </span>
                      <span className="text-muted-foreground">
                        {coupon.usageCount}/{coupon.usageLimit || '\u221e'} used
                      </span>
                    </div>
                    <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      {new Date(coupon.startDate).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                      })}{' '}
                      —{' '}
                      {new Date(coupon.endDate).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                      })}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ========== PACKAGES TAB ========== */}
        <TabsContent value="packages" className="space-y-4">
          <div className="flex justify-end">
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => toast.success('Create package coming soon')}>
              <Plus className="h-4 w-4 mr-2" />
              Create Package
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockPackages.map((pkg) => (
              <Card key={pkg.id}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <Package className="h-5 w-5 text-teal-600" />
                        <h3 className="font-semibold">{pkg.name}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {pkg.description}
                      </p>
                    </div>
                    <Badge
                      className={
                        pkg.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200'
                      }
                    >
                      {pkg.status}
                    </Badge>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {pkg.includes.map((item) => (
                      <span
                        key={item}
                        className="inline-flex items-center gap-1 text-xs bg-muted px-2 py-1 rounded-full"
                      >
                        <Check className="h-3 w-3 text-emerald-500" />
                        {item}
                      </span>
                    ))}
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <div>
                      <span className="text-xl font-bold text-emerald-700">
                        \u20b9{pkg.price.toLocaleString()}
                      </span>
                      <span className="text-xs text-muted-foreground ml-2">
                        {pkg.duration}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                      onClick={() => toast.success('Package edit coming soon')}
                    >
                      Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* ========== FLASH SALES TAB ========== */}
        <TabsContent value="flash-sales" className="space-y-4">
          <div className="flex justify-end">
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => toast.success('Create flash sale coming soon')}>
              <Plus className="h-4 w-4 mr-2" />
              Create Flash Sale
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockFlashSales.map((sale) => (
              <Card key={sale.id} className="border-emerald-200 bg-gradient-to-br from-emerald-50/50 to-teal-50/50">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-amber-500" />
                      <h3 className="font-semibold">{sale.name}</h3>
                    </div>
                    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
                      {sale.discount}% OFF
                    </Badge>
                  </div>

                  <div className="mt-4 space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-rose-500" />
                      <span className="font-medium">Time Remaining:</span>
                      <span className="text-rose-600 font-bold">{sale.timeRemaining}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <BedDouble className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Rooms:</span>
                      <span>{sale.roomsIncluded.join(', ')}</span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <Badge
                      className={
                        sale.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200'
                      }
                    >
                      {sale.status}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                      onClick={() => toast.success('Flash sale edit coming soon')}
                    >
                      Manage
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

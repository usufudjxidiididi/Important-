'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Hotel as HotelType, Booking } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardAction } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  Building2,
  CalendarDays,
  DollarSign,
  TrendingUp,
  BedDouble,
  Clock,
  Wallet,
  Star,
  Eye,
  Hotel,
  Inbox,
  ArrowUpRight,
  MoreHorizontal,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function formatShortDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

// ---------- empty chart data ----------

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const emptyRevenueData = months.map((month) => ({
  name: month,
  revenue: 0,
}));

const emptyBookingData = months.map((month) => ({
  name: month,
  bookings: 0,
}));

// ---------- badge color maps ----------

const hotelStatusColors: Record<string, string> = {
  pending: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  approved: 'bg-primary/10 text-primary border-primary/20',
  rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
  suspended: 'bg-muted text-muted-foreground border-border',
};

const bookingStatusColors: Record<string, string> = {
  pending: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  confirmed: 'bg-primary/10 text-primary border-primary/20',
  checked_in: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  checked_out: 'bg-muted text-muted-foreground border-border',
  cancelled: 'bg-red-500/10 text-red-400 border-red-500/20',
  no_show: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
};

// ---------- custom tooltip ----------

function RevenueTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg border bg-popover px-3 py-2 text-sm shadow-md">
        <p className="font-medium text-foreground">{label}</p>
        <p className="text-[#B8860B]">{formatINR(payload[0].value)}</p>
      </div>
    );
  }
  return null;
}

function BookingTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg border bg-popover px-3 py-2 text-sm shadow-md">
        <p className="font-medium text-foreground">{label}</p>
        <p className="text-[#B8860B]">{payload[0].value} bookings</p>
      </div>
    );
  }
  return null;
}

// ---------- skeleton loaders ----------

function KPISkeleton() {
  return (
    <Card>
      <CardContent className="flex items-center gap-4">
        <Skeleton className="h-12 w-12 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-3 w-36" />
        </div>
      </CardContent>
    </Card>
  );
}

function MiniKPISkeleton() {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 py-3">
        <Skeleton className="h-9 w-9 rounded-lg" />
        <div className="flex-1 space-y-1.5">
          <Skeleton className="h-3 w-20" />
          <Skeleton className="h-5 w-16" />
        </div>
      </CardContent>
    </Card>
  );
}

// ---------- main component ----------

export default function AdminDashboard() {
  const {
    dashboardStats,
    hotels,
    bookings,
    setDashboardStats,
    setHotels,
    setSelectedHotelId,
    setCurrentView,
  } = useAppStore();

  const [loading, setLoading] = useState(true);
  const [pendingHotels, setPendingHotels] = useState<HotelType[]>([]);
  const [pendingBookings, setPendingBookings] = useState<Booking[]>([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const [statsRes, pendingHotelsRes, pendingBookingsRes, allHotelsRes] = await Promise.all([
          fetch('/api/dashboard'),
          fetch('/api/hotels?status=pending'),
          fetch('/api/bookings?status=pending'),
          fetch('/api/hotels'),
        ]);

        if (statsRes.ok) {
          const stats = await statsRes.json();
          setDashboardStats(stats);
        }

        if (pendingHotelsRes.ok) {
          const data = await pendingHotelsRes.json();
          const list = Array.isArray(data) ? data : data.hotels ?? [];
          setPendingHotels(list);
        }

        if (pendingBookingsRes.ok) {
          const data = await pendingBookingsRes.json();
          const list = Array.isArray(data) ? data : data.bookings ?? [];
          setPendingBookings(list);
        }

        if (allHotelsRes.ok) {
          const data = await allHotelsRes.json();
          const list = Array.isArray(data) ? data : data.hotels ?? [];
          setHotels(list);
        }
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [setDashboardStats, setHotels]);

  // Derived data
  const recentHotels = [...hotels]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const recentBookings = [...bookings]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const stats = dashboardStats;
  const hasData = (stats?.totalHotels ?? 0) > 0 || (stats?.totalBookings ?? 0) > 0;
  const revenueData = hasData ? [] : emptyRevenueData;
  const bookingChartData = hasData ? [] : emptyBookingData;

  const handleHotelClick = (hotelId: string) => {
    setSelectedHotelId(hotelId);
    setCurrentView('hotel-details');
  };

  // ---------- render ----------

  return (
    <div className="p-6 space-y-6">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {hasData
              ? "Welcome back! Here's an overview of your platform."
              : 'Your platform is ready. Start by registering hotels to see activity here.'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className={loading ? 'h-9 w-24' : 'hidden'} />
          {!loading && (
            <span className="text-sm text-muted-foreground">
              {new Date().toLocaleDateString('en-IN', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </span>
          )}
        </div>
      </div>

      {/* ========== ROW 1: Main KPI Cards ========== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Hotels */}
        {loading ? (
          <KPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <Building2 className="h-6 w-6 text-[#B8860B]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-muted-foreground truncate">Total Hotels</p>
                <p className="text-2xl font-bold tracking-tight">
                  {stats?.totalHotels ?? 0}
                </p>
                {(stats?.totalHotels ?? 0) > 0 && (
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-muted-foreground">Hotels on platform</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Bookings Today */}
        {loading ? (
          <KPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CalendarDays className="h-6 w-6 text-[#B8860B]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-muted-foreground truncate">Active Bookings Today</p>
                <p className="text-2xl font-bold tracking-tight">
                  {stats?.bookingsToday ?? 0}
                </p>
                {(stats?.bookingsToday ?? 0) > 0 && (
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-muted-foreground">Active today</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Monthly Revenue */}
        {loading ? (
          <KPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[rgba(96,165,250,0.1)]">
                <DollarSign className="h-6 w-6 text-[#60A5FA]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-muted-foreground truncate">Monthly Revenue</p>
                <p className="text-2xl font-bold tracking-tight">
                  {formatINR(stats?.monthlyRevenue ?? 0)}
                </p>
                {(stats?.monthlyRevenue ?? 0) > 0 && (
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-muted-foreground">This month</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Occupancy Rate */}
        {loading ? (
          <KPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[rgba(248,113,113,0.1)]">
                <TrendingUp className="h-6 w-6 text-[#F87171]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-muted-foreground truncate">Occupancy Rate</p>
                <p className="text-2xl font-bold tracking-tight">
                  {stats?.occupancyRate ?? 0}%
                </p>
                {(stats?.occupancyRate ?? 0) > 0 && (
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-muted-foreground">Current rate</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* ========== ROW 2: Secondary KPI Cards ========== */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Pending Approvals */}
        {loading ? (
          <MiniKPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-3 py-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[rgba(251,191,36,0.1)]">
                <Clock className="h-4 w-4 text-[#FBBF24]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-muted-foreground truncate">Pending Approvals</p>
                <p className="text-lg font-bold">{pendingHotels.length}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Total Rooms */}
        {loading ? (
          <MiniKPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-3 py-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[rgba(96,165,250,0.1)]">
                <BedDouble className="h-4 w-4 text-[#60A5FA]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-muted-foreground truncate">Total Rooms</p>
                <p className="text-lg font-bold">{stats?.totalRooms ?? 0}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Platform Commission */}
        {loading ? (
          <MiniKPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-3 py-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <Wallet className="h-4 w-4 text-[#B8860B]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-muted-foreground truncate">Platform Commission</p>
                <p className="text-lg font-bold">{formatINR(stats?.platformCommission ?? 0)}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Avg Rating */}
        {loading ? (
          <MiniKPISkeleton />
        ) : (
          <Card>
            <CardContent className="flex items-center gap-3 py-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[rgba(251,191,36,0.1)]">
                <Star className="h-4 w-4 text-[#FBBF24]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-muted-foreground truncate">Avg Rating</p>
                <p className="text-lg font-bold">
                  {stats?.avgRating?.toFixed(1) ?? '0.0'}/5
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* ========== ROW 3: Charts ========== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Revenue Trend */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Revenue Trend</CardTitle>
            <CardAction>
              <button className="p-1.5 rounded-md hover:bg-accent text-muted-foreground">
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </CardAction>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[300px] w-full rounded-lg" />
            ) : hasData ? (
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#B8860B" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#B8860B" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v: number) => '₹' + (v / 1000).toFixed(0) + 'K'}
                  />
                  <Tooltip content={<RevenueTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="#B8860B"
                    strokeWidth={2}
                    fill="url(#revenueGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
                <DollarSign className="h-12 w-12 mb-3 opacity-20" />
                <p className="text-sm font-medium">No revenue data yet</p>
                <p className="text-xs mt-1">Revenue trends will appear once hotels and bookings are active</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Booking Trends */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Booking Trends</CardTitle>
            <CardAction>
              <button className="p-1.5 rounded-md hover:bg-accent text-muted-foreground">
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </CardAction>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[300px] w-full rounded-lg" />
            ) : hasData ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={bookingChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 12 }}
                    className="text-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip content={<BookingTooltip />} />
                  <Bar
                    dataKey="bookings"
                    fill="#B8860B"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
                <CalendarDays className="h-12 w-12 mb-3 opacity-20" />
                <p className="text-sm font-medium">No booking data yet</p>
                <p className="text-xs mt-1">Booking trends will appear once reservations start coming in</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ========== ROW 4: Bottom Tables ========== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Recent Hotel Registrations */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Recent Hotel Registrations</CardTitle>
            <CardAction>
              <button
                onClick={() => setCurrentView('hotel-management')}
                className="text-sm text-[#B8860B] hover:underline font-medium flex items-center gap-1"
              >
                View all
                <ArrowUpRight className="h-3 w-3" />
              </button>
            </CardAction>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <Skeleton className="h-9 w-9 rounded-lg" />
                      <div className="space-y-1.5 flex-1">
                        <Skeleton className="h-4 w-40" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </div>
                ))}
              </div>
            ) : recentHotels.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                <Hotel className="h-10 w-10 mb-3 opacity-20" />
                <p className="text-sm font-medium">No hotels registered yet</p>
                <p className="text-xs mt-1">Hotels will appear here once partners register</p>
              </div>
            ) : (
              <div className="space-y-1">
                {recentHotels.map((hotel) => (
                  <button
                    key={hotel.id}
                    onClick={() => handleHotelClick(hotel.id)}
                    className="flex items-center justify-between w-full rounded-lg px-3 py-2.5 text-left hover:bg-accent transition-colors group"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                        <Building2 className="h-4 w-4 text-[#B8860B]" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate group-hover:text-[#B8860B] transition-colors">
                          {hotel.name}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {hotel.city ?? 'Unknown'} · {hotel.starRating}★
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 ml-3">
                      <span className="text-xs text-muted-foreground hidden sm:inline">
                        {formatShortDate(hotel.createdAt)}
                      </span>
                      <Badge variant="outline" className={hotelStatusColors[hotel.status] ?? ''}>
                        {hotel.status}
                      </Badge>
                      <Eye className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Bookings */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Recent Bookings</CardTitle>
            <CardAction>
              <button
                onClick={() => setCurrentView('booking-management')}
                className="text-sm text-[#B8860B] hover:underline font-medium flex items-center gap-1"
              >
                View all
                <ArrowUpRight className="h-3 w-3" />
              </button>
            </CardAction>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="space-y-1.5 flex-1">
                      <Skeleton className="h-4 w-28" />
                      <Skeleton className="h-3 w-36" />
                    </div>
                    <Skeleton className="h-6 w-20 rounded-full" />
                  </div>
                ))}
              </div>
            ) : recentBookings.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                <Inbox className="h-10 w-10 mb-3 opacity-20" />
                <p className="text-sm font-medium">No bookings yet</p>
                <p className="text-xs mt-1">Bookings will appear here once guests start reserving</p>
              </div>
            ) : (
              <div className="overflow-x-auto -mx-6 px-6">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left">
                      <th className="pb-2 font-medium text-muted-foreground text-xs">Booking #</th>
                      <th className="pb-2 font-medium text-muted-foreground text-xs">Guest</th>
                      <th className="pb-2 font-medium text-muted-foreground text-xs hidden md:table-cell">Hotel</th>
                      <th className="pb-2 font-medium text-muted-foreground text-xs hidden sm:table-cell">Check-in</th>
                      <th className="pb-2 font-medium text-muted-foreground text-xs text-right">Amount</th>
                      <th className="pb-2 font-medium text-muted-foreground text-xs">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {recentBookings.map((booking) => (
                      <tr key={booking.id} className="hover:bg-accent/50 transition-colors">
                        <td className="py-2.5 pr-3">
                          <span className="font-mono text-xs text-muted-foreground">
                            {booking.bookingNumber}
                          </span>
                        </td>
                        <td className="py-2.5 pr-3">
                          <span className="font-medium truncate max-w-[120px] block">
                            {booking.customerName}
                          </span>
                        </td>
                        <td className="py-2.5 pr-3 hidden md:table-cell">
                          <span className="text-muted-foreground truncate max-w-[120px] block">
                            {booking.hotel?.name ?? booking.roomName ?? '—'}
                          </span>
                        </td>
                        <td className="py-2.5 pr-3 hidden sm:table-cell whitespace-nowrap">
                          {formatShortDate(booking.checkIn)}
                        </td>
                        <td className="py-2.5 pr-3 text-right whitespace-nowrap font-medium">
                          {formatINR(booking.totalAmount)}
                        </td>
                        <td className="py-2.5">
                          <Badge
                            variant="outline"
                            className={bookingStatusColors[booking.status] ?? ''}
                          >
                            {booking.status.replace('_', ' ')}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

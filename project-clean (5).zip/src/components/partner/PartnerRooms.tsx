'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Room } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import {
  Plus,
  Wifi,
  Tv,
  Coffee,
  Wind,
  Wine,
  Lock,
  BedDouble,
  Eye,
  Users,
  Baby,
  Ruler,
  Cigarette,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

const amenityOptions = [
  { id: 'WiFi', label: 'WiFi', icon: Wifi },
  { id: 'TV', label: 'TV', icon: Tv },
  { id: 'AC', label: 'AC', icon: Wind },
  { id: 'Mini Bar', label: 'Mini Bar', icon: Wine },
  { id: 'Safe', label: 'Safe', icon: Lock },
  { id: 'Coffee Maker', label: 'Coffee Maker', icon: Coffee },
];

const bedTypeOptions = ['Double', 'Twin', 'King', 'Queen', 'Single'];

// ---------- component ----------

export default function PartnerRooms() {
  const { user, setRooms, rooms } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Form state
  const [form, setForm] = useState({
    name: '',
    description: '',
    basePrice: '',
    roomSize: '',
    maxAdults: '2',
    maxChildren: '1',
    bedType: 'Double',
    smoking: false,
    view: '',
    amenities: [] as string[],
  });

  const hotelId = user?.hotelId;

  useEffect(() => {
    if (!hotelId) return;

    const fetchRooms = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/rooms?hotelId=${hotelId}`);
        if (res.ok) {
          const data = await res.json();
          setRooms(data);
        }
      } catch (err) {
        console.error('Failed to fetch rooms:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRooms();
  }, [hotelId, setRooms]);

  const handleAmenityToggle = (amenity: string) => {
    setForm((prev) => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter((a) => a !== amenity)
        : [...prev.amenities, amenity],
    }));
  };

  const handleSubmit = async () => {
    if (!form.name || !form.basePrice) {
      toast.error('Please fill in required fields (name and base price)');
      return;
    }

    try {
      const payload = {
        hotelId,
        name: form.name,
        description: form.description,
        basePrice: Number(form.basePrice),
        roomSize: Number(form.roomSize) || 0,
        maxAdults: Number(form.maxAdults),
        maxChildren: Number(form.maxChildren),
        bedType: form.bedType,
        smoking: form.smoking,
        view: form.view,
        amenities: form.amenities.join(', '),
        status: 'active',
      };

      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        toast.success('Room added successfully!');
        setDialogOpen(false);
        setForm({
          name: '',
          description: '',
          basePrice: '',
          roomSize: '',
          maxAdults: '2',
          maxChildren: '1',
          bedType: 'Double',
          smoking: false,
          view: '',
          amenities: [],
        });
        // Refresh rooms
        const listRes = await fetch(`/api/rooms?hotelId=${hotelId}`);
        if (listRes.ok) {
          const data = await listRes.json();
          setRooms(data);
        }
      } else {
        toast.success('Room added successfully!');
        setDialogOpen(false);
      }
    } catch (err) {
      console.error('Failed to create room:', err);
      toast.error('Something went wrong. Please try again.');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">Active</Badge>;
      case 'inactive':
        return <Badge variant="secondary">Inactive</Badge>;
      case 'maintenance':
        return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">Maintenance</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getAmenityIcon = (amenity: string) => {
    const found = amenityOptions.find((a) => a.id === amenity);
    return found ? found.icon : null;
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-40" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-80 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">My Rooms</h2>
          <p className="text-sm text-muted-foreground">Manage your hotel rooms</p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Add Room
            </Button>
          </DialogTrigger>

          <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Room</DialogTitle>
              <DialogDescription>Fill in the details for the new room type.</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-2">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="room-name">Room Name *</Label>
                <Input
                  id="room-name"
                  placeholder="e.g., Deluxe Suite"
                  value={form.name}
                  onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="room-desc">Description</Label>
                <Textarea
                  id="room-desc"
                  placeholder="Room description..."
                  value={form.description}
                  onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                  rows={3}
                />
              </div>

              {/* Price & Size */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="room-price">Base Price (₹) *</Label>
                  <Input
                    id="room-price"
                    type="number"
                    placeholder="3500"
                    value={form.basePrice}
                    onChange={(e) => setForm((p) => ({ ...p, basePrice: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="room-size">Room Size (sq ft)</Label>
                  <Input
                    id="room-size"
                    type="number"
                    placeholder="300"
                    value={form.roomSize}
                    onChange={(e) => setForm((p) => ({ ...p, roomSize: e.target.value }))}
                  />
                </div>
              </div>

              {/* Adults & Children */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="room-adults">Max Adults</Label>
                  <Input
                    id="room-adults"
                    type="number"
                    value={form.maxAdults}
                    onChange={(e) => setForm((p) => ({ ...p, maxAdults: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="room-children">Max Children</Label>
                  <Input
                    id="room-children"
                    type="number"
                    value={form.maxChildren}
                    onChange={(e) => setForm((p) => ({ ...p, maxChildren: e.target.value }))}
                  />
                </div>
              </div>

              {/* Bed Type */}
              <div className="space-y-2">
                <Label>Bed Type</Label>
                <Select value={form.bedType} onValueChange={(v) => setForm((p) => ({ ...p, bedType: v }))}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select bed type" />
                  </SelectTrigger>
                  <SelectContent>
                    {bedTypeOptions.map((bt) => (
                      <SelectItem key={bt} value={bt}>
                        {bt}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Smoking Switch */}
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <Label>Smoking</Label>
                  <p className="text-xs text-muted-foreground">Allow smoking in this room</p>
                </div>
                <Switch checked={form.smoking} onCheckedChange={(v) => setForm((p) => ({ ...p, smoking: v }))} />
              </div>

              {/* View */}
              <div className="space-y-2">
                <Label htmlFor="room-view">View</Label>
                <Input
                  id="room-view"
                  placeholder="e.g., Ocean View, City View"
                  value={form.view}
                  onChange={(e) => setForm((p) => ({ ...p, view: e.target.value }))}
                />
              </div>

              {/* Amenities */}
              <div className="space-y-3">
                <Label>Amenities</Label>
                <div className="grid grid-cols-2 gap-3">
                  {amenityOptions.map((amenity) => {
                    const Icon = amenity.icon;
                    return (
                      <label
                        key={amenity.id}
                        className="flex items-center gap-2 rounded-lg border p-2.5 cursor-pointer hover:bg-muted/50 transition-colors"
                      >
                        <Checkbox
                          checked={form.amenities.includes(amenity.id)}
                          onCheckedChange={() => handleAmenityToggle(amenity.id)}
                        />
                        <Icon className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{amenity.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleSubmit}>
                Add Room
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Room Grid */}
      {rooms.length === 0 ? (
        <div className="text-center py-16">
          <BedDouble className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No rooms found. Add your first room to get started.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => {
            const amenitiesList = room.amenities ? room.amenities.split(', ').filter(Boolean) : [];
            return (
              <Card key={room.id} className="gap-4 hover:shadow-md transition-shadow">
                <CardHeader className="pb-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{room.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{room.description || 'No description'}</p>
                    </div>
                    {getStatusBadge(room.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Price */}
                  <div>
                    <span className="text-xl font-bold text-emerald-700">{formatINR(room.basePrice)}</span>
                    <span className="text-sm text-muted-foreground">/night</span>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Ruler className="h-3.5 w-3.5" />
                      <span>{room.roomSize || '—'} sq ft</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Users className="h-3.5 w-3.5" />
                      <span>{room.maxAdults} Adults</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Baby className="h-3.5 w-3.5" />
                      <span>{room.maxChildren} Children</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <BedDouble className="h-3.5 w-3.5" />
                      <span>{room.bedType}</span>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="flex flex-wrap gap-2">
                    {room.smoking && (
                      <Badge variant="outline" className="gap-1">
                        <Cigarette className="h-3 w-3" />
                        Smoking
                      </Badge>
                    )}
                    {room.view && (
                      <Badge variant="outline" className="gap-1">
                        <Eye className="h-3 w-3" />
                        {room.view}
                      </Badge>
                    )}
                  </div>

                  {/* Amenities */}
                  {amenitiesList.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-2 border-t">
                      {amenitiesList.map((a) => {
                        const Icon = getAmenityIcon(a);
                        return (
                          <div
                            key={a}
                            className="flex items-center gap-1 text-xs text-muted-foreground bg-muted rounded-md px-2 py-1"
                          >
                            {Icon ? <Icon className="h-3 w-3" /> : null}
                            <span>{a}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useAppStore } from '@/lib/store';
import type { HotelStatus } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { toast } from 'sonner';
import {
  Search,
  Star,
  Eye,
  Check,
  X,
  Ban,
  RotateCcw,
  Building2,
  Inbox,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '₹' + value.toLocaleString('en-IN');
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

const ITEMS_PER_PAGE = 10;

type FilterStatus = 'all' | HotelStatus;

const STATUS_OPTIONS: { label: string; value: FilterStatus }[] = [
  { label: 'All', value: 'all' },
  { label: 'Pending', value: 'pending' },
  { label: 'Approved', value: 'approved' },
  { label: 'Rejected', value: 'rejected' },
  { label: 'Suspended', value: 'suspended' },
];

function getStatusBadge(status: HotelStatus) {
  switch (status) {
    case 'approved':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
          Approved
        </Badge>
      );
    case 'pending':
      return (
        <Badge className="bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100">
          Pending
        </Badge>
      );
    case 'rejected':
      return (
        <Badge className="bg-red-100 text-red-700 border-red-200 hover:bg-red-100">
          Rejected
        </Badge>
      );
    case 'suspended':
      return (
        <Badge className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-100">
          Suspended
        </Badge>
      );
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`size-3.5 ${
            i < rating
              ? 'fill-amber-400 text-amber-400'
              : 'fill-muted text-muted'
          }`}
        />
      ))}
    </div>
  );
}

// ---------- component ----------

export default function HotelManagement() {
  const {
    hotels,
    setHotels,
    updateHotelStatus,
    setSelectedHotelId,
    setCurrentView,
  } = useAppStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);

  // Fetch hotels on mount
  useEffect(() => {
    async function fetchHotels() {
      try {
        setLoading(true);
        const res = await fetch('/api/hotels');
        if (!res.ok) throw new Error('Failed to fetch hotels');
        const data = await res.json();
        setHotels(data);
      } catch (err) {
        toast.error('Failed to load hotels');
      } finally {
        setLoading(false);
      }
    }
    fetchHotels();
  }, [setHotels]);

  // Filter hotels
  const filteredHotels = useMemo(() => {
    let result = hotels;
    if (statusFilter !== 'all') {
      result = result.filter((h) => h.status === statusFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (h) =>
          h.name.toLowerCase().includes(q) ||
          (h.city && h.city.toLowerCase().includes(q)) ||
          h.email.toLowerCase().includes(q)
      );
    }
    return result;
  }, [hotels, searchQuery, statusFilter]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filteredHotels.length / ITEMS_PER_PAGE));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const paginatedHotels = filteredHotels.slice(
    (safeCurrentPage - 1) * ITEMS_PER_PAGE,
    safeCurrentPage * ITEMS_PER_PAGE
  );

  // Reset page on filter/search change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter]);

  // Status change handler
  const handleStatusChange = useCallback(
    async (id: string, newStatus: HotelStatus, label: string) => {
      try {
        const res = await fetch(`/api/hotels/${id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus }),
        });
        if (!res.ok) throw new Error('Failed to update status');
        updateHotelStatus(id, newStatus);
        toast.success(`Hotel ${label.toLowerCase()} successfully`);
      } catch {
        toast.error(`Failed to ${label.toLowerCase()} hotel`);
      }
    },
    [updateHotelStatus]
  );

  // View hotel details
  const handleViewDetails = useCallback(
    (id: string) => {
      setSelectedHotelId(id);
      setCurrentView('hotel-details');
    },
    [setSelectedHotelId, setCurrentView]
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Hotel Management
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage and monitor all registered hotels
          </p>
        </div>
        <Badge
          variant="outline"
          className="bg-teal-50 text-teal-700 border-teal-200 text-sm px-3 py-1 h-7"
        >
          {filteredHotels.length} hotel{filteredHotels.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, city, or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="flex items-center gap-1 flex-wrap">
          {STATUS_OPTIONS.map((opt) => (
            <Button
              key={opt.value}
              variant={statusFilter === opt.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setStatusFilter(opt.value)}
              className={
                statusFilter === opt.value
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : ''
              }
            >
              {opt.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <Building2 className="size-8 animate-pulse" />
            <span>Loading hotels...</span>
          </div>
        </div>
      ) : filteredHotels.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <Inbox className="size-12 mb-3 opacity-40" />
          <p className="text-lg font-medium">No hotels found</p>
          <p className="text-sm mt-1">
            {searchQuery || statusFilter !== 'all'
              ? 'Try adjusting your search or filter criteria'
              : 'No hotels have been registered yet'}
          </p>
        </div>
      ) : (
        <>
          <div className="rounded-xl border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40">
                  <TableHead className="min-w-[200px]">Hotel Name</TableHead>
                  <TableHead className="min-w-[120px]">City / State</TableHead>
                  <TableHead className="min-w-[130px]">Owner</TableHead>
                  <TableHead className="min-w-[170px]">Contact</TableHead>
                  <TableHead className="text-right min-w-[70px]">Rooms</TableHead>
                  <TableHead className="text-right min-w-[120px]">Revenue</TableHead>
                  <TableHead className="min-w-[100px]">Status</TableHead>
                  <TableHead className="min-w-[100px]">Created</TableHead>
                  <TableHead className="text-right min-w-[150px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedHotels.map((hotel) => (
                  <TableRow key={hotel.id}>
                    {/* Hotel Name with Stars */}
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <span className="font-medium text-foreground">
                          {hotel.name}
                        </span>
                        <StarRating rating={hotel.starRating} />
                      </div>
                    </TableCell>

                    {/* City/State */}
                    <TableCell className="text-muted-foreground">
                      {hotel.city || '-'}
                      {hotel.state ? `, ${hotel.state}` : ''}
                    </TableCell>

                    {/* Owner */}
                    <TableCell className="text-muted-foreground">
                      {hotel.ownerName || hotel.contactPerson || '-'}
                    </TableCell>

                    {/* Contact */}
                    <TableCell>
                      <div className="flex flex-col gap-0.5 text-muted-foreground text-xs">
                        <span>{hotel.email}</span>
                        {hotel.phone && <span>{hotel.phone}</span>}
                      </div>
                    </TableCell>

                    {/* Rooms */}
                    <TableCell className="text-right font-medium tabular-nums">
                      {hotel.totalRooms ?? 0}
                    </TableCell>

                    {/* Revenue */}
                    <TableCell className="text-right font-medium tabular-nums text-emerald-600">
                      {formatINR(hotel.monthlyRevenue ?? 0)}
                    </TableCell>

                    {/* Status */}
                    <TableCell>{getStatusBadge(hotel.status)}</TableCell>

                    {/* Created */}
                    <TableCell className="text-muted-foreground text-xs">
                      {formatDate(hotel.createdAt)}
                    </TableCell>

                    {/* Actions */}
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        {/* View */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8 text-teal-600 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => handleViewDetails(hotel.id)}
                          title="View details"
                        >
                          <Eye className="size-4" />
                        </Button>

                        {/* Approve – only if pending */}
                        {hotel.status === 'pending' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                            onClick={() =>
                              handleStatusChange(hotel.id, 'approved', 'Approved')
                            }
                            title="Approve"
                          >
                            <Check className="size-4" />
                          </Button>
                        )}

                        {/* Reject – only if pending */}
                        {hotel.status === 'pending' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                            onClick={() =>
                              handleStatusChange(hotel.id, 'rejected', 'Rejected')
                            }
                            title="Reject"
                          >
                            <X className="size-4" />
                          </Button>
                        )}

                        {/* Suspend – only if approved */}
                        {hotel.status === 'approved' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-orange-500 hover:text-orange-600 hover:bg-orange-50"
                            onClick={() =>
                              handleStatusChange(hotel.id, 'suspended', 'Suspended')
                            }
                            title="Suspend"
                          >
                            <Ban className="size-4" />
                          </Button>
                        )}

                        {/* Activate – only if suspended */}
                        {hotel.status === 'suspended' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8 text-teal-600 hover:text-teal-700 hover:bg-teal-50"
                            onClick={() =>
                              handleStatusChange(hotel.id, 'approved', 'Activated')
                            }
                            title="Activate"
                          >
                            <RotateCcw className="size-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() =>
                      setCurrentPage((p) => Math.max(1, p - 1))
                    }
                    className={
                      safeCurrentPage === 1
                        ? 'pointer-events-none opacity-50'
                        : 'cursor-pointer'
                    }
                  />
                </PaginationItem>

                {Array.from({ length: totalPages }).map((_, idx) => {
                  const page = idx + 1;
                  // Show first, last, and pages around current
                  if (
                    totalPages <= 7 ||
                    page === 1 ||
                    page === totalPages ||
                    Math.abs(page - safeCurrentPage) <= 1
                  ) {
                    return (
                      <PaginationItem key={page}>
                        <PaginationLink
                          isActive={page === safeCurrentPage}
                          onClick={() => setCurrentPage(page)}
                          className="cursor-pointer"
                        />
                      </PaginationItem>
                    );
                  }
                  // Show ellipsis
                  if (
                    page === safeCurrentPage - 2 ||
                    page === safeCurrentPage + 2
                  ) {
                    return (
                      <PaginationItem key={`ellipsis-${page}`}>
                        <span className="flex size-9 items-center justify-center text-muted-foreground">
                          ...
                        </span>
                      </PaginationItem>
                    );
                  }
                  return null;
                })}

                <PaginationItem>
                  <PaginationNext
                    onClick={() =>
                      setCurrentPage((p) => Math.min(totalPages, p + 1))
                    }
                    className={
                      safeCurrentPage === totalPages
                        ? 'pointer-events-none opacity-50'
                        : 'cursor-pointer'
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
}
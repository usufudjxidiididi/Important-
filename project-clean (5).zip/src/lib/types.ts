export type Role = 'super_admin' | 'sub_admin' | 'finance' | 'support' | 'hotel_owner' | 'hotel_manager' | 'reception' | 'housekeeping' | 'accountant';

export type HotelStatus = 'pending' | 'approved' | 'rejected' | 'suspended';
export type BookingStatus = 'pending' | 'confirmed' | 'checked_in' | 'checked_out' | 'cancelled' | 'no_show';
export type PaymentStatus = 'pending' | 'paid' | 'refunded' | 'partial';

export interface AppUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  phone?: string;
  avatar?: string;
  hotelId?: string;
  isActive: boolean;
}

export interface Hotel {
  id: string;
  name: string;
  brand?: string;
  registrationNumber?: string;
  gst?: string;
  ownerName?: string;
  contactPerson?: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  country: string;
  pincode?: string;
  latitude?: number;
  longitude?: number;
  description?: string;
  starRating: number;
  checkInTime: string;
  checkOutTime: string;
  amenities?: string;
  policies?: string;
  languages?: string;
  hasParking: boolean;
  hasRestaurant: boolean;
  hasPool: boolean;
  hasSpa: boolean;
  hasWiFi: boolean;
  allowsPets: boolean;
  logo?: string;
  status: HotelStatus;
  commissionRate: number;
  totalRooms?: number;
  availableRooms?: number;
  occupancyRate?: number;
  monthlyRevenue?: number;
  bookingCount?: number;
  avgRating?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Room {
  id: string;
  hotelId: string;
  hotel?: Hotel;
  name: string;
  description?: string;
  roomSize?: number;
  maxAdults: number;
  maxChildren: number;
  bedType: string;
  smoking: boolean;
  view?: string;
  amenities?: string;
  images?: string;
  basePrice: number;
  status: string;
  totalInventory?: number;
  availableInventory?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Inventory {
  id: string;
  roomId: string;
  date: string;
  totalRooms: number;
  availableRooms: number;
  blockedRooms: number;
  soldRooms: number;
  status: string;
}

export interface Pricing {
  id: string;
  roomId: string;
  date?: string;
  priceType: string;
  price: number;
  minStay?: number;
  maxStay?: number;
  extraAdultFee: number;
  extraChildFee: number;
}

export interface Booking {
  id: string;
  bookingNumber: string;
  hotelId: string;
  hotel?: Hotel;
  roomId?: string;
  roomName?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  adults: number;
  children: number;
  totalAmount: number;
  commission: number;
  netAmount?: number;
  status: BookingStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  specialRequests?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  hotelId: string;
  customerName: string;
  rating: number;
  comment?: string;
  reply?: string;
  status: string;
  createdAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  description?: string;
  discountType: string;
  discountValue: number;
  minBooking: number;
  maxDiscount?: number;
  startDate: string;
  endDate: string;
  usageLimit?: number;
  usageCount: number;
  status: string;
}

export interface DashboardStats {
  totalHotels: number;
  pendingHotels: number;
  activeHotels: number;
  suspendedHotels: number;
  totalRooms: number;
  availableRooms: number;
  bookingsToday: number;
  monthlyRevenue: number;
  platformCommission: number;
  occupancyRate: number;
  totalBookings: number;
  totalCustomers: number;
  avgRating: number;
}

export interface PartnerDashboardStats {
  todayBookings: number;
  monthlyBookings: number;
  revenue: number;
  availableRooms: number;
  occupancy: number;
  upcomingCheckIns: number;
  upcomingCheckOuts: number;
  avgRating: number;
  totalReviews: number;
}

export interface ReportData {
 revenueTrend: { date: string; revenue: number; bookings: number }[];
  occupancyTrend: { date: string; occupancy: number }[];
  topHotels: { name: string; revenue: number; bookings: number; occupancy: number }[];
  topCities: { city: string; hotels: number; revenue: number }[];
  roomPerformance: { name: string; sold: number; revenue: number }[];
  cancellationAnalysis: { reason: string; count: number }[];
}

export interface Notification {
  id: string;
  type: 'booking' | 'payment' | 'review' | 'alert' | 'system' | 'report';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export type ViewType = 
  | 'login'
  | 'admin-dashboard'
  | 'hotel-management'
  | 'hotel-details'
  | 'room-inventory'
  | 'rate-management'
  | 'booking-management'
  | 'customer-management'
  | 'reports'
  | 'cms'
  | 'notifications'
  | 'settings'
  | 'partner-dashboard'
  | 'partner-rooms'
  | 'partner-inventory'
  | 'partner-pricing'
  | 'partner-bookings'
  | 'partner-guests'
  | 'partner-gallery'
  | 'partner-promotions'
  | 'partner-reviews'
  | 'partner-financials'
  | 'partner-notifications'
  | 'partner-settings'
  | 'admin-register-hotel'
  | 'booking-engine';

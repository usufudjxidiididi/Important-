import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamelArr } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const hotelId = searchParams.get('hotelId');

    if (!hotelId) {
      return NextResponse.json({ error: 'hotelId is required' }, { status: 400 });
    }

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();

    const threeDaysLater = new Date(now);
    threeDaysLater.setDate(threeDaysLater.getDate() + 3);
    const threeDaysLaterStr = threeDaysLater.toISOString().split('T')[0];

    // Fetch rooms first to get room IDs
    const roomsRes = await supabase
      .from('rooms')
      .select('id')
      .eq('hotel_id', hotelId);

    if (roomsRes.error) throw roomsRes.error;

    const roomIds = (roomsRes.data || []).map((r) => r.id);

    const [bookingsRes, reviewsRes, inventoriesRes] = await Promise.all([
      supabase.from('bookings').select('*').eq('hotel_id', hotelId),
      supabase.from('reviews').select('*').eq('hotel_id', hotelId),
      roomIds.length > 0
        ? supabase.from('inventory').select('*').in('room_id', roomIds).eq('date', todayStr)
        : Promise.resolve({ data: [], error: null, count: null, status: 200, statusText: '' }),
    ]);

    if (bookingsRes.error) throw bookingsRes.error;
    if (reviewsRes.error) throw reviewsRes.error;
    if (inventoriesRes.error) throw inventoriesRes.error;

    const bookings = toCamelArr(bookingsRes.data || []);
    const reviews = toCamelArr(reviewsRes.data || []);
    const inventories = toCamelArr(inventoriesRes.data || []);

    const todayBookings = bookings.filter((b: any) => b.checkIn === todayStr).length;

    const monthlyBookings = bookings.filter((b: any) => {
      const d = new Date(b.createdAt);
      return d >= new Date(startOfMonth) && d <= new Date(endOfMonth);
    });

    const revenue = monthlyBookings
      .filter((b: any) => ['confirmed', 'checked_in', 'checked_out'].includes(b.status))
      .reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0);

    const availableRooms = inventories.reduce((sum: number, inv: any) => sum + (inv.availableRooms || 0), 0);
    const totalCapacity = inventories.reduce((sum: number, inv: any) => sum + (inv.totalRooms || 0), 0);
    const occupancy = totalCapacity > 0 ? Math.round(((totalCapacity - availableRooms) / totalCapacity) * 1000) / 10 : 0;

    const upcomingCheckIns = bookings.filter(
      (b: any) => b.checkIn > todayStr && b.checkIn <= threeDaysLaterStr && b.status !== 'cancelled'
    );

    const upcomingCheckOuts = bookings.filter(
      (b: any) => b.checkOut > todayStr && b.checkOut <= threeDaysLaterStr && b.status !== 'cancelled'
    );

    const avgRating =
      reviews.length > 0
        ? Math.round((reviews.reduce((sum: number, r: any) => sum + (r.rating || 0), 0) / reviews.length) * 10) / 10
        : 0;

    return NextResponse.json({
      todayBookings,
      monthlyBookings: monthlyBookings.length,
      revenue,
      availableRooms,
      occupancy,
      upcomingCheckIns,
      upcomingCheckOuts,
      avgRating,
      totalReviews: reviews.length,
    });
  } catch (error) {
    console.error('Partner dashboard error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

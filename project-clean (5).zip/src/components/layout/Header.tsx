'use client';

import { useAppStore } from '@/lib/store';
import type { ViewType } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import {
  Bell,
  Search,
  Menu,
  Moon,
  Sun,
  User,
  LogOut,
  Settings,
} from 'lucide-react';
import { useState } from 'react';

const viewTitles: Record<ViewType, string> = {
  login: 'Login',
  'admin-dashboard': 'Dashboard',
  'hotel-management': 'Hotel Management',
  'hotel-details': 'Hotel Details',
  'room-inventory': 'Room Inventory',
  'rate-management': 'Rate Management',
  'booking-management': 'Bookings',
  'customer-management': 'Customers',
  reports: 'Reports & Analytics',
  cms: 'Content Management',
  notifications: 'Notifications',
  settings: 'Settings',
  'partner-dashboard': 'Dashboard',
  'partner-rooms': 'My Rooms',
  'partner-inventory': 'Inventory',
  'partner-pricing': 'Pricing',
  'partner-bookings': 'Bookings',
  'partner-guests': 'Guests',
  'partner-gallery': 'Gallery',
  'partner-promotions': 'Promotions',
  'partner-reviews': 'Reviews',
  'partner-financials': 'Financials',
  'partner-notifications': 'Notifications',
  'partner-settings': 'Settings',
  'admin-register-hotel': 'Register Hotel',
  'booking-engine': 'Booking Engine',
};

export default function Header() {
  const {
    sidebarOpen,
    setSidebarOpen,
    currentView,
    user,
    logout,
    notifications,
    setCurrentView,
    setSearchQuery,
  } = useAppStore();

  const [themeIcon, setThemeIcon] = useState<'dark' | 'light'>('light');

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const pageTitle = viewTitles[currentView] || 'Dashboard';

  const toggleTheme = () => {
    setThemeIcon((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const initials = user?.name
    ?.split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'U';

  return (
    <header className="flex items-center justify-between h-16 px-4 border-b border-border bg-background shrink-0">
      {/* Left Section */}
      <div className="flex items-center gap-3">
        {/* Mobile menu toggle */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden h-9 w-9"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <Menu className="w-5 h-5" />
        </Button>

        <h1 className="text-lg font-semibold text-foreground">{pageTitle}</h1>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-2">
        {/* Search */}
        <div className="hidden md:flex items-center relative">
          <Search className="absolute left-3 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            placeholder="Search..."
            className="pl-9 w-64 h-9 bg-background border border-input text-foreground placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-primary focus-visible:border-primary"
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Mobile search icon */}
        <Button variant="ghost" size="icon" className="md:hidden h-9 w-9">
          <Search className="w-4 h-4" />
        </Button>

        {/* Theme toggle */}
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 text-muted-foreground hover:text-foreground"
          onClick={toggleTheme}
        >
          {themeIcon === 'light' ? (
            <Moon className="w-4 h-4" />
          ) : (
            <Sun className="w-4 h-4" />
          )}
        </Button>

        {/* Notifications */}
        <Button
          variant="ghost"
          size="icon"
          className="relative h-9 w-9 text-muted-foreground hover:text-foreground"
          onClick={() => {
            const isAdmin = user?.role === 'super_admin' || user?.role === 'sub_admin' || user?.role === 'finance' || user?.role === 'support';
            setCurrentView(isAdmin ? 'notifications' : 'partner-notifications');
          }}
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[9px] font-medium leading-none">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Button>

        {/* User Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="flex items-center gap-2 h-9 px-2"
            >
              <Avatar className="h-7 w-7">
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline text-sm font-medium text-foreground max-w-[120px] truncate">
                {user?.name || 'User'}
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 bg-popover border border-border text-popover-foreground">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col gap-0.5">
                <p className="text-sm font-medium">{user?.name || 'User'}</p>
                <p className="text-xs text-muted-foreground">{user?.email || 'user@example.com'}</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="cursor-pointer gap-2"
              onClick={() => {
                const isAdmin = user?.role === 'super_admin' || user?.role === 'sub_admin' || user?.role === 'finance' || user?.role === 'support';
                setCurrentView(isAdmin ? 'settings' : 'partner-settings');
              }}
            >
              <User className="w-4 h-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem
              className="cursor-pointer gap-2"
              onClick={() => {
                const isAdmin = user?.role === 'super_admin' || user?.role === 'sub_admin' || user?.role === 'finance' || user?.role === 'support';
                setCurrentView(isAdmin ? 'settings' : 'partner-settings');
              }}
            >
              <Settings className="w-4 h-4" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="cursor-pointer gap-2 text-red-500 focus:text-red-500 focus:bg-red-50"
              onClick={logout}
            >
              <LogOut className="w-4 h-4" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

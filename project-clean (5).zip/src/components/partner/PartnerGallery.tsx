'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  Camera,
  Upload,
  Trash2,
  Star,
  GripVertical,
  Image as ImageIcon,
} from 'lucide-react';

// ---------- types ----------

interface GalleryItem {
  id: string;
  type: string;
  label: string;
  gradient: string;
  uploadDate: string;
  isCover: boolean;
}

// ---------- mock data ----------

const mockGallery: GalleryItem[] = [
  {
    id: 'g1',
    type: 'Exterior',
    label: 'Main Entrance',
    gradient: 'from-emerald-400 to-teal-600',
    uploadDate: '2025-01-10',
    isCover: true,
  },
  {
    id: 'g2',
    type: 'Exterior',
    label: 'Building Facade',
    gradient: 'from-teal-400 to-cyan-600',
    uploadDate: '2025-01-10',
    isCover: false,
  },
  {
    id: 'g3',
    type: 'Interior',
    label: 'Lobby',
    gradient: 'from-amber-400 to-orange-500',
    uploadDate: '2025-01-08',
    isCover: false,
  },
  {
    id: 'g4',
    type: 'Rooms',
    label: 'Deluxe Room',
    gradient: 'from-emerald-500 to-green-700',
    uploadDate: '2025-01-06',
    isCover: false,
  },
  {
    id: 'g5',
    type: 'Rooms',
    label: 'Premium Suite',
    gradient: 'from-teal-500 to-emerald-700',
    uploadDate: '2025-01-06',
    isCover: false,
  },
  {
    id: 'g6',
    type: 'Dining',
    label: 'Restaurant',
    gradient: 'from-orange-400 to-rose-500',
    uploadDate: '2025-01-04',
    isCover: false,
  },
  {
    id: 'g7',
    type: 'Amenities',
    label: 'Swimming Pool',
    gradient: 'from-cyan-400 to-blue-500',
    uploadDate: '2025-01-03',
    isCover: false,
  },
  {
    id: 'g8',
    type: 'Amenities',
    label: 'Spa & Wellness',
    gradient: 'from-purple-400 to-fuchsia-500',
    uploadDate: '2025-01-03',
    isCover: false,
  },
  {
    id: 'g9',
    type: 'Interior',
    label: 'Conference Room',
    gradient: 'from-slate-400 to-slate-600',
    uploadDate: '2025-01-02',
    isCover: false,
  },
  {
    id: 'g10',
    type: 'Events',
    label: 'Banquet Hall',
    gradient: 'from-rose-400 to-pink-600',
    uploadDate: '2025-01-01',
    isCover: false,
  },
];

const categories = ['All', 'Exterior', 'Interior', 'Rooms', 'Dining', 'Amenities', 'Events'];

// ---------- component ----------

export default function PartnerGallery() {
  const { user } = useAppStore();

  const [activeCategory, setActiveCategory] = useState('All');
  const [gallery, setGallery] = useState<GalleryItem[]>(mockGallery);

  const filtered =
    activeCategory === 'All'
      ? gallery
      : gallery.filter((item) => item.type === activeCategory);

  const handleSetCover = (id: string) => {
    setGallery((prev) =>
      prev.map((item) => ({ ...item, isCover: item.id === id }))
    );
    toast.success('Cover image updated');
  };

  const handleDelete = (id: string) => {
    setGallery((prev) => prev.filter((item) => item.id !== id));
    toast.success('Image deleted');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ImageIcon className="h-6 w-6 text-emerald-600" />
          <h1 className="text-2xl font-bold">Photo Gallery</h1>
        </div>
        <Button
          className="bg-emerald-600 hover:bg-emerald-700"
          onClick={() => toast.info('Upload feature coming soon')}
        >
          <Upload className="h-4 w-4 mr-2" />
          Upload Photos
        </Button>
      </div>

      {/* Reorder instruction */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-lg p-3">
        <GripVertical className="h-4 w-4" />
        <span>Drag and drop to reorder photos. The first photo will be used as the cover image across the platform.</span>
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={activeCategory === cat ? 'default' : 'outline'}
            size="sm"
            className={
              activeCategory === cat
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : ''
            }
            onClick={() => setActiveCategory(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <Card key={item.id} className="overflow-hidden group">
            {/* Image placeholder */}
            <div
              className={`relative h-48 bg-gradient-to-br ${item.gradient} flex items-center justify-center`}
            >
              <Camera className="h-10 w-10 text-white/60" />
              {item.isCover && (
                <div className="absolute top-2 left-2">
                  <Badge className="bg-white/90 text-emerald-700 hover:bg-white/90 border-0">
                    <Star className="h-3 w-3 mr-1 fill-emerald-500 text-emerald-500" />
                    Cover
                  </Badge>
                </div>
              )}
              <div className="absolute top-2 right-2">
                <Badge className="bg-white/90 text-foreground hover:bg-white/90 border-0">
                  {item.type}
                </Badge>
              </div>
            </div>

            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">{item.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Uploaded: {new Date(item.uploadDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {!item.isCover && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                      onClick={() => handleSetCover(item.id)}
                    >
                      <Star className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                    onClick={() => handleDelete(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <ImageIcon className="h-12 w-12 mx-auto text-muted-foreground/30" />
            <p className="mt-3 text-muted-foreground">No photos in this category.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

import { NextResponse } from 'next/server';
import { supabase, toCamelArr } from '@/lib/supabase';

export async function GET() {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();
    const thirtyDaysAgoStr = new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Pre-fetch hotels with rooms for reuse
    const allHotelsRes = await supabase.from('hotels').select('id, name, city');
    if (allHotelsRes.error) throw allHotelsRes.error;

    const allHotels = toCamelArr(allHotelsRes.data || []);
    const hotelIds = allHotels.map((h: any) => h.id);
    const hotelMap = new Map(allHotels.map((h: any) => [h.id, h]));

    // Fetch rooms
    const roomsRes = hotelIds.length > 0
      ? await supabase.from('rooms').select('id, hotel_id').in('hotel_id', hotelIds)
      : { data: [], error: null };
    if (roomsRes.error) throw roomsRes.error;

    const rooms = toCamelArr(roomsRes.data || []);
    const roomIds = rooms.map((r: any) => r.id);
    const roomHotelMap = new Map(rooms.map((r: any) => [r.id, r.hotelId]));
    const hotelRoomsMap = new Map<string, string[]>();
    for (const r of rooms as any[]) {
      const existing = hotelRoomsMap.get(r.hotelId) || [];
      existing.push(r.id);
      hotelRoomsMap.set(r.hotelId, existing);
    }

    // --- Revenue trend: last 30 days ---
    const revenueTrend: { date: string; revenue: number; bookings: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      revenueTrend.push({ date: dateStr, revenue: 0, bookings: 0 });
    }

    const last30DayBookingsRes = await supabase
      .from('bookings')
      .select('*')
      .gte('created_at', new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .or('status.eq.confirmed,status.eq.checked_in,status.eq.checked_out');
    if (last30DayBookingsRes.error) throw last30DayBookingsRes.error;

    const last30DayBookings = toCamelArr(last30DayBookingsRes.data || []);

    const revenueMap = new Map<string, number>();
    const bookingCountMap = new Map<string, number>();
    for (const b of last30DayBookings as any[]) {
      const bDate = new Date(b.createdAt).toISOString().split('T')[0];
      revenueMap.set(bDate, (revenueMap.get(bDate) || 0) + (b.totalAmount || 0));
      bookingCountMap.set(bDate, (bookingCountMap.get(bDate) || 0) + 1);
    }
    for (const entry of revenueTrend) {
      entry.revenue = revenueMap.get(entry.date) || 0;
      entry.bookings = bookingCountMap.get(entry.date) || 0;
    }

    // --- Occupancy trend: last 30 days ---
    const occupancyTrend: { date: string; occupancy: number }[] = [];

    const allInventoriesRes = roomIds.length > 0
      ? await supabase
          .from('inventory')
          .select('*')
          .in('room_id', roomIds)
          .gte('date', thirtyDaysAgoStr)
      : { data: [], error: null };
    if (allInventoriesRes.error) throw allInventoriesRes.error;

    const allInventories = toCamelArr(allInventoriesRes.data || []);

    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];

      const dayInvs = (allInventories as any[]).filter((inv: any) => inv.date === dateStr);
      const total = dayInvs.reduce((s: number, inv: any) => s + (inv.totalRooms || 0), 0);
      const available = dayInvs.reduce((s: number, inv: any) => s + (inv.availableRooms || 0), 0);
      const occupied = total - available;
      const rate = total > 0 ? (occupied / total) * 100 : 0;

      occupancyTrend.push({ date: dateStr, occupancy: Math.round(rate * 10) / 10 });
    }

    // --- Top hotels by revenue (this month) ---
    const monthlyBookingsRes = await supabase
      .from('bookings')
      .select('*')
      .gte('created_at', startOfMonth)
      .lte('created_at', endOfMonth)
      .or('status.eq.confirmed,status.eq.checked_in,status.eq.checked_out');
    if (monthlyBookingsRes.error) throw monthlyBookingsRes.error;

    const monthlyBookings = toCamelArr(monthlyBookingsRes.data || []);

    const hotelRevenueMap = new Map<string, { name: string; revenue: number; bookings: number; hotelId: string }>();
    for (const b of monthlyBookings as any[]) {
      const existing = hotelRevenueMap.get(b.hotelId);
      const hotel = hotelMap.get(b.hotelId);
      const name = (hotel as any)?.name || 'Unknown';
      if (existing) {
        existing.revenue += b.totalAmount || 0;
        existing.bookings += 1;
      } else {
        hotelRevenueMap.set(b.hotelId, { name, revenue: b.totalAmount || 0, bookings: 1, hotelId: b.hotelId });
      }
    }

    const topHotelsSorted = Array.from(hotelRevenueMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    // Today's inventory for occupancy
    const todayInventoriesRes = roomIds.length > 0
      ? await supabase
          .from('inventory')
          .select('*')
          .in('room_id', roomIds)
          .eq('date', todayStr)
      : { data: [], error: null };
    if (todayInventoriesRes.error) throw todayInventoriesRes.error;

    const todayInventories = toCamelArr(todayInventoriesRes.data || []);

    const topHotels = topHotelsSorted.map((h) => {
      const hotelRoomIds = hotelRoomsMap.get(h.hotelId) || [];
      const hotelInv = (todayInventories as any[]).filter((inv: any) => hotelRoomIds.includes(inv.id));
      const total = hotelInv.reduce((s: number, inv: any) => s + (inv.totalRooms || 0), 0);
      const available = hotelInv.reduce((s: number, inv: any) => s + (inv.availableRooms || 0), 0);
      const occupancy = total > 0 ? Math.round(((total - available) / total) * 1000) / 10 : 0;
      return { name: h.name, revenue: h.revenue, bookings: h.bookings, occupancy };
    });

    // --- Top cities ---
    const cityMap = new Map<string, { hotelCount: number; revenue: number }>();
    for (const h of allHotels as any[]) {
      if (!h.city) continue;
      const existing = cityMap.get(h.city);
      if (existing) {
        existing.hotelCount += 1;
      } else {
        cityMap.set(h.city, { hotelCount: 1, revenue: 0 });
      }
    }

    for (const b of monthlyBookings as any[]) {
      const hotel = hotelMap.get(b.hotelId);
      if (!hotel?.city) continue;
      const city = cityMap.get((hotel as any).city);
      if (city) {
        city.revenue += b.totalAmount || 0;
      }
    }

    const topCities = Array.from(cityMap.entries()).map(([city, data]) => ({
      city,
      ...data,
    }));

    // --- Room performance ---
    const roomPerformanceMap = new Map<string, { roomType: string; soldCount: number; revenue: number }>();
    for (const b of last30DayBookings as any[]) {
      if (!b.roomName) continue;
      const existing = roomPerformanceMap.get(b.roomName);
      if (existing) {
        existing.soldCount += 1;
        existing.revenue += b.totalAmount || 0;
      } else {
        roomPerformanceMap.set(b.roomName, { roomType: b.roomName, soldCount: 1, revenue: b.totalAmount || 0 });
      }
    }
    const roomPerformance = Array.from(roomPerformanceMap.values());

    // --- Cancellation analysis ---
    const cancelledCountRes = await supabase
      .from('bookings')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'cancelled');
    if (cancelledCountRes.error) throw cancelledCountRes.error;

    const cancelledCount = cancelledCountRes.count ?? 0;

    return NextResponse.json({
      revenueTrend,
      occupancyTrend,
      topHotels,
      topCities,
      roomPerformance,
      cancellationAnalysis: [
        { reason: 'Guest cancellation', count: cancelledCount },
        { reason: 'No-show', count: 0 },
        { reason: 'Payment failed', count: 0 },
        { reason: 'Duplicate booking', count: 0 },
      ],
    });
  } catch (error) {
    console.error('Reports error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

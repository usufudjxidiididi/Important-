import { NextRequest, NextResponse } from 'next/server'
import { supabase, toSnake, generateId } from '@/lib/supabase'

// GET /api/setup — check database status
export async function GET() {
  if (!supabase) {
    return NextResponse.json({ error: 'Database not configured' }, { status: 500 })
  }

  const results: { column: string; status: string; detail?: string }[] = []

  // Check if partner_code column exists on users table
  try {
    const { error } = await supabase
      .from('users')
      .select('partner_code')
      .limit(1)

    if (error && error.message?.includes('does not exist')) {
      results.push({
        column: 'partner_code',
        status: 'missing',
        detail: 'Run this SQL in Supabase SQL Editor: ALTER TABLE users ADD COLUMN partner_code TEXT UNIQUE;',
      })
    } else {
      results.push({ column: 'partner_code', status: 'ok' })
    }
  } catch {
    results.push({ column: 'partner_code', status: 'ok' })
  }

  // Check if any users exist
  const { count } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })

  const needsManual = results.some(r => r.status === 'missing')

  return NextResponse.json({
    success: true,
    results,
    needs_manual_sql: needsManual,
    user_count: count || 0,
    sql_to_run: needsManual
      ? 'ALTER TABLE users ADD COLUMN partner_code TEXT UNIQUE;'
      : null,
  })
}

// POST /api/setup — create the first admin user
export async function POST(request: NextRequest) {
  if (!supabase) {
    return NextResponse.json({ error: 'Database not configured' }, { status: 500 })
  }

  try {
    const body = await request.json()
    const { email, password, name } = body

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Email, password, and name are required' },
        { status: 400 }
      )
    }

    // Check if any users already exist
    const { count } = await supabase
      .from('users')
      .select('*', { count: 'exact', head: true })

    if ((count || 0) > 0) {
      return NextResponse.json(
        { error: 'Setup already done. Use the admin panel to manage users.' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const { data: existing } = await supabase
      .from('users')
      .select('id')
      .eq('email', email.trim())
      .maybeSingle()

    if (existing) {
      return NextResponse.json(
        { error: 'This email is already registered' },
        { status: 409 }
      )
    }

    const id = generateId()

    const { data: user, error } = await supabase
      .from('users')
      .insert({
        id,
        ...toSnake({
          name: name.trim(),
          email: email.trim(),
          password: password,
          phone: null,
          role: 'super_admin',
          hotelId: null,
          partnerCode: null,
          isActive: true,
        }),
      })
      .select('id, name, email, role')
      .single()

    if (error) {
      console.error('Setup create admin error:', error)
      return NextResponse.json(
        { error: 'Failed to create admin user. Make sure the users table exists in Supabase.' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: 'Admin user created successfully! You can now log in.',
      user,
    })
  } catch (error) {
    console.error('Setup error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

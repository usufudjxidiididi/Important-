'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Booking } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Users,
  UserCheck,
  Clock,
  Smile,
  Search,
  Mail,
  Phone,
  CalendarDays,
} from 'lucide-react';

// ---------- helpers ----------

function formatINR(value: number): string {
  return '\u20b9' + value.toLocaleString('en-IN');
}

interface Guest {
  name: string;
  email: string;
  phone: string;
  bookings: Booking[];
}

// ---------- mock data ----------

const mockGuests: Guest[] = [
  {
    name: 'Rahul Sharma',
    email: 'rahul@email.com',
    phone: '+91 98765 43210',
    bookings: [
      { id: 'b1', bookingNumber: 'BK-2025-0142', hotelId: 'mock', customerName: 'Rahul Sharma', customerEmail: 'rahul@email.com', customerPhone: '+91 98765 43210', checkIn: '2025-01-15', checkOut: '2025-01-17', guests: 2, adults: 2, children: 0, totalAmount: 12500, commission: 1875, status: 'checked_out', paymentStatus: 'paid', createdAt: '2025-01-14' } as Booking,
      { id: 'b5', bookingNumber: 'BK-2025-0105', hotelId: 'mock', customerName: 'Rahul Sharma', customerEmail: 'rahul@email.com', customerPhone: '+91 98765 43210', checkIn: '2024-12-20', checkOut: '2024-12-22', guests: 2, adults: 2, children: 0, totalAmount: 10800, commission: 1620, status: 'checked_out', paymentStatus: 'paid', createdAt: '2024-12-18' } as Booking,
    ],
  },
  {
    name: 'Priya Mehta',
    email: 'priya@email.com',
    phone: '+91 87654 32109',
    bookings: [
      { id: 'b2', bookingNumber: 'BK-2025-0141', hotelId: 'mock', customerName: 'Priya Mehta', customerEmail: 'priya@email.com', customerPhone: '+91 87654 32109', checkIn: '2025-01-18', checkOut: '2025-01-20', guests: 1, adults: 1, children: 0, totalAmount: 8400, commission: 1260, status: 'confirmed', paymentStatus: 'paid', createdAt: '2025-01-16' } as Booking,
    ],
  },
  {
    name: 'Amit Patel',
    email: 'amit.p@email.com',
    phone: '+91 76543 21098',
    bookings: [
      { id: 'b3', bookingNumber: 'BK-2025-0140', hotelId: 'mock', customerName: 'Amit Patel', customerEmail: 'amit.p@email.com', customerPhone: '+91 76543 21098', checkIn: '2025-01-12', checkOut: '2025-01-16', guests: 4, adults: 2, children: 2, totalAmount: 22000, commission: 3300, status: 'checked_out', paymentStatus: 'paid', createdAt: '2025-01-10' } as Booking,
      { id: 'b8', bookingNumber: 'BK-2025-0098', hotelId: 'mock', customerName: 'Amit Patel', customerEmail: 'amit.p@email.com', customerPhone: '+91 76543 21098', checkIn: '2024-11-05', checkOut: '2024-11-07', guests: 2, adults: 2, children: 0, totalAmount: 9200, commission: 1380, status: 'checked_out', paymentStatus: 'paid', createdAt: '2024-11-03' } as Booking,
      { id: 'b11', bookingNumber: 'BK-2025-0072', hotelId: 'mock', customerName: 'Amit Patel', customerEmail: 'amit.p@email.com', customerPhone: '+91 76543 21098', checkIn: '2024-09-15', checkOut: '2024-09-17', guests: 2, adults: 2, children: 0, totalAmount: 8800, commission: 1320, status: 'checked_out', paymentStatus: 'paid', createdAt: '2024-09-12' } as Booking,
    ],
  },
  {
    name: 'Sneha Reddy',
    email: 'sneha.r@email.com',
    phone: '+91 65432 10987',
    bookings: [
      { id: 'b4', bookingNumber: 'BK-2025-0139', hotelId: 'mock', customerName: 'Sneha Reddy', customerEmail: 'sneha.r@email.com', customerPhone: '+91 65432 10987', checkIn: '2025-01-20', checkOut: '2025-01-23', guests: 3, adults: 2, children: 1, totalAmount: 16800, commission: 2520, status: 'confirmed', paymentStatus: 'pending', createdAt: '2025-01-17' } as Booking,
    ],
  },
  {
    name: 'Vikram Singh',
    email: 'vikram@email.com',
    phone: '+91 54321 09876',
    bookings: [
      { id: 'b6', bookingNumber: 'BK-2025-0138', hotelId: 'mock', customerName: 'Vikram Singh', customerEmail: 'vikram@email.com', customerPhone: '+91 54321 09876', checkIn: '2025-01-10', checkOut: '2025-01-11', guests: 1, adults: 1, children: 0, totalAmount: 9500, commission: 1425, status: 'checked_out', paymentStatus: 'paid', createdAt: '2025-01-09' } as Booking,
      { id: 'b9', bookingNumber: 'BK-2025-0088', hotelId: 'mock', customerName: 'Vikram Singh', customerEmail: 'vikram@email.com', customerPhone: '+91 54321 09876', checkIn: '2024-10-10', checkOut: '2024-10-12', guests: 2, adults: 2, children: 0, totalAmount: 11200, commission: 1680, status: 'checked_out', paymentStatus: 'paid', createdAt: '2024-10-08' } as Booking,
    ],
  },
];

// ---------- component ----------

export default function PartnerGuests() {
  const { user, bookings: storeBookings } = useAppStore();
  const hotelId = user?.hotelId;

  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    if (!hotelId) return;

    const fetchBookings = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/bookings?hotelId=${hotelId}`);
        if (res.ok) {
          const data: Booking[] = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            // Extract unique guests from bookings
            const guestMap = new Map<string, Guest>();
            data.forEach((b) => {
              const key = b.customerEmail;
              if (guestMap.has(key)) {
                guestMap.get(key)!.bookings.push(b);
              } else {
                guestMap.set(key, {
                  name: b.customerName,
                  email: b.customerEmail,
                  phone: b.customerPhone || '',
                  bookings: [b],
                });
              }
            });
            setGuests(Array.from(guestMap.values()));
          } else {
            setGuests(mockGuests);
          }
        } else {
          setGuests(mockGuests);
        }
      } catch {
        setGuests(mockGuests);
      } finally {
        setLoading(false);
      }
    };

    // Also check store bookings
    const storeFiltered = storeBookings.filter((b) => b.hotelId === hotelId);
    if (storeFiltered.length > 0) {
      const guestMap = new Map<string, Guest>();
      storeFiltered.forEach((b) => {
        const key = b.customerEmail;
        if (guestMap.has(key)) {
          guestMap.get(key)!.bookings.push(b);
        } else {
          guestMap.set(key, {
            name: b.customerName,
            email: b.customerEmail,
            phone: b.customerPhone || '',
            bookings: [b],
          });
        }
      });
      setGuests(Array.from(guestMap.values()));
      setLoading(false);
    } else {
      fetchBookings();
    }
  }, [hotelId, storeBookings]);

  const filteredGuests = useMemo(() => {
    if (!search.trim()) return guests;
    const q = search.toLowerCase();
    return guests.filter(
      (g) =>
        g.name.toLowerCase().includes(q) ||
        g.email.toLowerCase().includes(q) ||
        g.phone.includes(q)
    );
  }, [guests, search]);

  const summary = useMemo(() => {
    const totalGuests = guests.length;
    const repeatGuests = guests.filter((g) => g.bookings.length > 1).length;
    const allBookings = guests.flatMap((g) => g.bookings);
    const totalNights = allBookings.reduce((sum, b) => {
      const checkIn = new Date(b.checkIn);
      const checkOut = new Date(b.checkOut);
      return sum + Math.max(1, Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)));
    }, 0);
    const avgStay = allBookings.length > 0 ? (totalNights / allBookings.length).toFixed(1) : '0';
    return { totalGuests, repeatGuests, avgStay, satisfaction: 4.3 };
  }, [guests]);

  const getGuestTotalSpent = (guest: Guest) =>
    guest.bookings.reduce((sum, b) => sum + b.totalAmount, 0);

  const getGuestLastStay = (guest: Guest) => {
    const sorted = [...guest.bookings].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return sorted[0]?.checkIn || '—';
  };

  const getStayDuration = (checkIn: string, checkOut: string) => {
    const d1 = new Date(checkIn);
    const d2 = new Date(checkOut);
    return Math.max(1, Math.ceil((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24)));
  };

  const handleRowClick = (guest: Guest) => {
    setSelectedGuest(guest);
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-6 w-6 text-emerald-600" />
          <h1 className="text-2xl font-bold">Guest Management</h1>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 w-fit">
              <Users className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{summary.totalGuests}</p>
            <p className="text-sm text-muted-foreground">Total Guests</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-teal-100 text-teal-700 w-fit">
              <UserCheck className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{summary.repeatGuests}</p>
            <p className="text-sm text-muted-foreground">Repeat Guests</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-cyan-100 text-cyan-700 w-fit">
              <Clock className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{summary.avgStay}</p>
            <p className="text-sm text-muted-foreground">Avg Stay Duration</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-0">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700 w-fit">
              <Smile className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{summary.satisfaction}</p>
            <p className="text-sm text-muted-foreground">Guest Satisfaction</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search guests by name, email, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Guests Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Guest Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead className="text-center">Bookings</TableHead>
                <TableHead className="text-right">Total Spent</TableHead>
                <TableHead>Last Stay</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredGuests.map((guest, idx) => (
                <TableRow
                  key={idx}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => handleRowClick(guest)}
                >
                  <TableCell className="font-medium">{guest.name}</TableCell>
                  <TableCell className="text-muted-foreground">{guest.email}</TableCell>
                  <TableCell className="text-muted-foreground">{guest.phone || '—'}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="secondary">{guest.bookings.length}</Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium text-emerald-700">
                    {formatINR(getGuestTotalSpent(guest))}
                  </TableCell>
                  <TableCell>
                    {getGuestLastStay(guest) !== '—'
                      ? new Date(getGuestLastStay(guest)).toLocaleDateString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })
                      : '—'}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge
                      className={
                        guest.bookings.length > 1
                          ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200'
                      }
                    >
                      {guest.bookings.length > 1 ? 'Repeat' : 'New'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Guest Profile Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          {selectedGuest && (
            <>
              <DialogHeader>
                <DialogTitle>Guest Profile</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                {/* Profile Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Users className="h-3.5 w-3.5" /> Name
                    </div>
                    <p className="font-medium">{selectedGuest.name}</p>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Mail className="h-3.5 w-3.5" /> Email
                    </div>
                    <p className="font-medium">{selectedGuest.email}</p>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" /> Phone
                    </div>
                    <p className="font-medium">{selectedGuest.phone || '—'}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-emerald-50 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-emerald-700">
                      {selectedGuest.bookings.length}
                    </p>
                    <p className="text-xs text-muted-foreground">Bookings</p>
                  </div>
                  <div className="bg-teal-50 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-teal-700">
                      {formatINR(getGuestTotalSpent(selectedGuest))}
                    </p>
                    <p className="text-xs text-muted-foreground">Total Spent</p>
                  </div>
                  <div className="bg-cyan-50 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-cyan-700">
                      {selectedGuest.bookings.length > 1 ? 'Yes' : 'No'}
                    </p>
                    <p className="text-xs text-muted-foreground">Repeat Guest</p>
                  </div>
                </div>

                {/* Booking History */}
                <div>
                  <h3 className="font-medium mb-3 flex items-center gap-2">
                    <CalendarDays className="h-4 w-4 text-emerald-600" />
                    Booking History
                  </h3>
                  <div className="space-y-2">
                    {selectedGuest.bookings
                      .sort(
                        (a, b) =>
                          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                      )
                      .map((booking) => (
                        <div
                          key={booking.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card"
                        >
                          <div>
                            <p className="font-mono text-xs text-emerald-700">
                              {booking.bookingNumber}
                            </p>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {new Date(booking.checkIn).toLocaleDateString('en-IN', {
                                day: '2-digit',
                                month: 'short',
                              })}{' '}
                              —{' '}
                              {new Date(booking.checkOut).toLocaleDateString('en-IN', {
                                day: '2-digit',
                                month: 'short',
                              })}{' '}
                              ({getStayDuration(booking.checkIn, booking.checkOut)} nights)
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-sm">
                              {formatINR(booking.totalAmount)}
                            </p>
                            <Badge
                              className={`text-[10px] ${
                                booking.status === 'checked_out'
                                  ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200'
                                  : booking.status === 'confirmed'
                                  ? 'bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200'
                                  : 'bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200'
                              }`}
                            >
                              {booking.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "REVYORA HOSPITALITY - Enterprise Hotel Management Platform",
  description: "Modern, enterprise-grade Hotel Management & Registration Platform for managing multiple hotel partners, bookings, rooms, and revenue.",
  keywords: ["hotel management", "hotel booking", "room inventory", "hospitality", "SaaS"],
  authors: [{ name: "REVYORA HOSPITALITY" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

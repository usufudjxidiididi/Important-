'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { useAppStore } from '@/lib/store';
import {
  Settings, Shield, CreditCard, Mail, MessageSquare, Lock, Globe, Bell, Palette,
  Plus, Trash2, Edit, Save, CheckCircle2, XCircle, TrendingUp, Users, Loader2,
} from 'lucide-react';

// --- Shared helper: save settings to DB via /api/settings ---
async function saveSettingsToDb(settings: Record<string, string>, label: string) {
  try {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings }),
    });
    if (!res.ok) throw new Error();
    toast.success(`${label} saved successfully!`);
    return true;
  } catch {
    toast.error(`Failed to save ${label.toLowerCase()}`);
    return false;
  }
}

// --- Shared helper: load settings from DB ---
async function loadSettingsFromDb(): Promise<Record<string, string>> {
  try {
    const res = await fetch('/api/settings');
    if (res.ok) return await res.json();
  } catch {}
  return {};
}

// --- Types ---
interface DbUser {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string | null;
  isActive: boolean;
  hotelId: string | null;
  hotel: { id: string; name: string } | null;
  createdAt: string;
}

const ADMIN_ROLES = [
  { value: 'super_admin', label: 'Super Admin' },
  { value: 'sub_admin', label: 'Sub Admin' },
  { value: 'finance', label: 'Finance' },
  { value: 'support', label: 'Support' },
];

const HOTEL_ROLES = [
  { value: 'hotel_owner', label: 'Hotel Owner' },
  { value: 'hotel_manager', label: 'Hotel Manager' },
  { value: 'reception', label: 'Reception' },
  { value: 'housekeeping', label: 'Housekeeping' },
  { value: 'accountant', label: 'Accountant' },
];

const ROLE_STYLES: Record<string, string> = {
  super_admin: 'bg-primary/10 text-primary border-primary/20',
  sub_admin: 'bg-sky-100 text-sky-700 border-sky-200',
  finance: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  support: 'bg-amber-100 text-amber-700 border-amber-200',
  hotel_owner: 'bg-purple-100 text-purple-700 border-purple-200',
  hotel_manager: 'bg-indigo-100 text-indigo-700 border-indigo-200',
  reception: 'bg-pink-100 text-pink-700 border-pink-200',
  housekeeping: 'bg-orange-100 text-orange-700 border-orange-200',
  accountant: 'bg-teal-100 text-teal-700 border-teal-200',
};

function roleLabel(role: string): string {
  return [...ADMIN_ROLES, ...HOTEL_ROLES].find(r => r.value === role)?.label ?? role;
}

// --- Users Tab ---
function UsersTab() {
  const { hotels } = useAppStore();
  const [users, setUsers] = useState<DbUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('hotel_owner');
  const [hotelId, setHotelId] = useState('');
  const [panelType, setPanelType] = useState<'admin' | 'hotel'>('admin');

  const fetchUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      if (data.users) setUsers(data.users);
    } catch {
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const isAdminRole = (r: string) => ['super_admin', 'sub_admin', 'finance', 'support'].includes(r);

  const resetForm = () => {
    setName(''); setEmail(''); setPassword(''); setPhone('');
    setRole('super_admin'); setHotelId(''); setPanelType('admin');
  };

  const handlePanelTypeChange = (type: 'admin' | 'hotel') => {
    setPanelType(type);
    setRole(type === 'admin' ? 'super_admin' : 'hotel_owner');
    setHotelId('');
  };

  const handleCreate = async () => {
    if (!name.trim() || !email.trim()) {
      toast.error('Name and email are required');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password: password || undefined, phone: phone || undefined, role, hotelId: hotelId || undefined }),
      });
      const data = await res.json();
      if (data.error) {
        toast.error(data.error);
      } else {
        toast.success(`User "${name}" created. They can now sign in.`);
        setDialogOpen(false);
        resetForm();
        fetchUsers();
      }
    } catch {
      toast.error('Failed to create user');
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (id: string) => {
    try {
      await fetch(`/api/users/toggle?id=${id}`, { method: 'PATCH' });
      fetchUsers();
    } catch {
      toast.error('Failed to update user status');
    }
  };

  const handleDelete = async (id: string, userName: string) => {
    try {
      const res = await fetch(`/api/users?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.error) { toast.error(data.error); return; }
      toast.success(`User "${userName}" deleted`);
      fetchUsers();
    } catch {
      toast.error('Failed to delete user');
    }
  };

  const approvedHotels = hotels.filter(h => h.status === 'approved');

  return (
    <div className="space-y-4">
      {/* Header + Add Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">User Management</h2>
          <p className="text-sm text-muted-foreground">Add users for Admin Panel or Hotel Partner Panel. They can sign in immediately after creation.</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="bg-primary hover:bg-primary/90 text-primary-foreground">
          <Plus className="h-4 w-4 mr-1.5" />
          Add User
        </Button>
      </div>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-16 text-muted-foreground text-sm">Loading users...</div>
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Users className="h-10 w-10 mb-3 opacity-30" />
              <p className="font-medium">No users yet</p>
              <p className="text-sm mt-1">Click "Add User" to create your first user</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="font-semibold">Name</TableHead>
                    <TableHead className="font-semibold">Email</TableHead>
                    <TableHead className="font-semibold">Panel</TableHead>
                    <TableHead className="font-semibold">Role</TableHead>
                    <TableHead className="font-semibold">Hotel</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold w-24">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.name}</TableCell>
                      <TableCell className="text-muted-foreground">{u.email}</TableCell>
                      <TableCell>
                        <Badge variant={isAdminRole(u.role) ? 'default' : 'secondary'} className="text-xs">
                          {isAdminRole(u.role) ? 'Admin' : 'Hotel Partner'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={`text-xs border ${ROLE_STYLES[u.role] || 'bg-muted text-muted-foreground border-border'}`}>
                          {roleLabel(u.role)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{u.hotel?.name ?? '—'}</TableCell>
                      <TableCell>
                        <Badge className={u.isActive
                          ? 'bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-muted text-muted-foreground border-border hover:bg-muted'
                        }>
                          {u.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Switch checked={u.isActive} onCheckedChange={() => handleToggle(u.id)} className="data-[state=checked]:bg-primary" />
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(u.id, u.name)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add User Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Panel Type Selector */}
            <div className="space-y-2">
              <Label>Panel Access</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handlePanelTypeChange('admin')}
                  className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${panelType === 'admin' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'}`}
                >
                  <Shield className={`h-6 w-6 ${panelType === 'admin' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`text-sm font-medium ${panelType === 'admin' ? 'text-primary' : 'text-muted-foreground'}`}>Admin Panel</span>
                  <span className="text-[11px] text-muted-foreground">Full platform access</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePanelTypeChange('hotel')}
                  className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${panelType === 'hotel' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'}`}
                >
                  <Lock className={`h-6 w-6 ${panelType === 'hotel' ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`text-sm font-medium ${panelType === 'hotel' ? 'text-primary' : 'text-muted-foreground'}`}>Hotel Partner</span>
                  <span className="text-[11px] text-muted-foreground">Hotel management</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Full Name *</Label>
                <Input placeholder="John Doe" value={name} onChange={e => setName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input placeholder="+91 98765 43210" value={phone} onChange={e => setPhone(e.target.value)} />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Email Address *</Label>
              <Input type="email" placeholder="user@example.com" value={email} onChange={e => setEmail(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" placeholder="Set initial password (optional)" value={password} onChange={e => setPassword(e.target.value)} />
              <p className="text-[11px] text-muted-foreground">Leave empty for default password. User can sign in with any password.</p>
            </div>

            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(panelType === 'admin' ? ADMIN_ROLES : HOTEL_ROLES).map(r => (
                    <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {panelType === 'hotel' && approvedHotels.length > 0 && (
              <div className="space-y-2">
                <Label>Assign Hotel</Label>
                <Select value={hotelId} onValueChange={setHotelId}>
                  <SelectTrigger><SelectValue placeholder="Select a hotel (optional)" /></SelectTrigger>
                  <SelectContent>
                    {approvedHotels.map(h => (
                      <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {saving ? 'Creating...' : 'Create User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// --- General Tab ---
function GeneralTab() {
  const [platformName, setPlatformName] = useState('REVYORA HOSPITALITY');
  const [logoUrl, setLogoUrl] = useState('');
  const [currency, setCurrency] = useState('INR');
  const [timezone, setTimezone] = useState('Asia/Kolkata');
  const [language, setLanguage] = useState('en');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadSettingsFromDb();
      if (s.platform_name) setPlatformName(s.platform_name);
      if (s.logo_url) setLogoUrl(s.logo_url);
      if (s.currency) setCurrency(s.currency);
      if (s.timezone) setTimezone(s.timezone);
      if (s.language) setLanguage(s.language);
      if (s.maintenance_mode === 'true') setMaintenanceMode(true);
    })();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await saveSettingsToDb({
      platform_name: platformName,
      logo_url: logoUrl,
      currency,
      timezone,
      language,
      maintenance_mode: String(maintenanceMode),
    }, 'General settings');
    setSaving(false);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Globe className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            Platform Information
          </CardTitle>
          <CardDescription>Basic platform configuration and branding</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="platform-name">Platform Name</Label>
              <Input id="platform-name" value={platformName} onChange={(e) => setPlatformName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="logo-url">Logo URL</Label>
              <Input id="logo-url" value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="INR">INR (₹)</SelectItem>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Timezone</Label>
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Asia/Kolkata">Asia/Kolkata (IST)</SelectItem>
                  <SelectItem value="America/New_York">America/New_York (EST)</SelectItem>
                  <SelectItem value="Europe/London">Europe/London (GMT)</SelectItem>
                  <SelectItem value="Asia/Dubai">Asia/Dubai (GST)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Language</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="hi">Hindi</SelectItem>
                  <SelectItem value="es">Spanish</SelectItem>
                  <SelectItem value="fr">French</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Settings className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            System Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Maintenance Mode</p>
              <p className="text-sm text-muted-foreground">Disable the platform for maintenance</p>
            </div>
            <Switch checked={maintenanceMode} onCheckedChange={setMaintenanceMode} />
          </div>
          <Button onClick={handleSave} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Tax Tab ---
function TaxTab() {
  const [taxRules, setTaxRules] = useState([
    { id: '1', name: 'GST', rate: 18, status: 'active' },
    { id: '2', name: 'Service Tax', rate: 5, status: 'active' },
    { id: '3', name: 'Luxury Tax', rate: 10, status: 'active' },
  ]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRate, setNewRate] = useState('');

  const handleAdd = () => {
    if (!newName || !newRate) return;
    setTaxRules([...taxRules, { id: Date.now().toString(), name: newName, rate: Number(newRate), status: 'active' }]);
    setNewName('');
    setNewRate('');
    setDialogOpen(false);
    toast.success('Tax rule added successfully!');
  };

  const handleDelete = (id: string) => {
    setTaxRules(taxRules.filter((t) => t.id !== id));
    toast.success('Tax rule removed.');
  };

  const toggleStatus = (id: string) => {
    setTaxRules(taxRules.map((t) => t.id === id ? { ...t, status: t.status === 'active' ? 'inactive' : 'active' } : t));
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base">Tax Rules</CardTitle>
            <CardDescription>Manage applicable taxes on bookings</CardDescription>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                <Plus className="h-4 w-4" />
                Add Tax Rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Tax Rule</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Tax Name</Label>
                  <Input placeholder="e.g. State Tax" value={newName} onChange={(e) => setNewName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Rate (%)</Label>
                  <Input type="number" placeholder="e.g. 12" value={newRate} onChange={(e) => setNewRate(e.target.value)} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleAdd} className="bg-emerald-600 hover:bg-emerald-700">Add Rule</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tax Name</TableHead>
                <TableHead className="text-center">Rate %</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {taxRules.map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell className="font-medium">{rule.name}</TableCell>
                  <TableCell className="text-center">{rule.rate}%</TableCell>
                  <TableCell className="text-center">
                    <Badge variant={rule.status === 'active' ? 'default' : 'secondary'} className={rule.status === 'active' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}>
                      {rule.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => toggleStatus(rule.id)}>
                        {rule.status === 'active' ? <XCircle className="h-4 w-4 text-red-500" /> : <CheckCircle2 className="h-4 w-4 text-emerald-600" />}
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleDelete(rule.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Commission Tab ---
function CommissionTab() {
  const [rate, setRate] = useState([15]);
  const [tiers, setTiers] = useState([
    { id: '1', range: '0 - 100 bookings', rate: 15, status: 'active' },
    { id: '2', range: '100 - 500 bookings', rate: 12, status: 'active' },
    { id: '3', range: '500+ bookings', rate: 8, status: 'active' },
  ]);

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Default Commission Rate</CardTitle>
          <CardDescription>Set the platform commission percentage</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-6">
            <Slider value={rate} onValueChange={setRate} min={5} max={30} step={1} className="flex-1" />
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 min-w-[3rem] text-right">{rate[0]}%</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Commission Tiers</CardTitle>
          <CardDescription>Volume-based commission discounts</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tier</TableHead>
                <TableHead className="text-center">Rate</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tiers.map((tier) => (
                <TableRow key={tier.id}>
                  <TableCell className="font-medium">{tier.range}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="border-emerald-300 text-emerald-700 dark:border-emerald-700 dark:text-emerald-400">
                      {tier.rate}%
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge className="bg-emerald-600 hover:bg-emerald-700">Active</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Payments Tab ---
function PaymentsTab() {
  const [methods, setMethods] = useState([
    { id: 'stripe', name: 'Stripe', enabled: true },
    { id: 'razorpay', name: 'Razorpay', enabled: true },
    { id: 'paypal', name: 'PayPal', enabled: false },
    { id: 'cash', name: 'Cash at Hotel', enabled: true },
    { id: 'bank', name: 'Bank Transfer', enabled: false },
  ]);

  const [refundPolicy, setRefundPolicy] = useState('');
  const [savingPolicy, setSavingPolicy] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadSettingsFromDb();
      if (s.refund_policy) setRefundPolicy(s.refund_policy);
      if (s.payment_methods) {
        try {
          const saved = JSON.parse(s.payment_methods) as Record<string, boolean>;
          setMethods(prev => prev.map(m => ({ ...m, enabled: !!saved[m.id] })));
        } catch {}
      }
    })();
  }, []);

  const toggleMethod = (id: string) => {
    setMethods(methods.map((m) => m.id === id ? { ...m, enabled: !m.enabled } : m));
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <CreditCard className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            Payment Methods
          </CardTitle>
          <CardDescription>Enable or disable payment methods for the platform</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {methods.map((method) => (
            <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <CreditCard className={`h-5 w-5 ${method.enabled ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground'}`} />
                <div>
                  <p className="font-medium">{method.name}</p>
                  <p className="text-sm text-muted-foreground">{method.enabled ? 'Enabled' : 'Disabled'}</p>
                </div>
              </div>
              <Switch checked={method.enabled} onCheckedChange={() => toggleMethod(method.id)} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Refund Policy</CardTitle>
          <CardDescription>Configure the default refund policy</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={refundPolicy}
            onChange={(e) => setRefundPolicy(e.target.value)}
            rows={4}
          />
          <Button onClick={async () => {
            setSavingPolicy(true);
            await saveSettingsToDb({ refund_policy: refundPolicy }, 'Refund policy');
            setSavingPolicy(false);
          }} disabled={savingPolicy} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            {savingPolicy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save Policy
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Email Tab ---
function EmailTab() {
  const [smtpHost, setSmtpHost] = useState('');
  const [smtpPort, setSmtpPort] = useState('');
  const [smtpUser, setSmtpUser] = useState('');
  const [smtpPass, setSmtpPass] = useState('');
  const [savingSmtp, setSavingSmtp] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadSettingsFromDb();
      if (s.smtp_host) setSmtpHost(s.smtp_host);
      if (s.smtp_port) setSmtpPort(s.smtp_port);
      if (s.smtp_user) setSmtpUser(s.smtp_user);
      // Don't load password back for security
    })();
  }, []);

  const emailTemplates = [
    { name: 'Booking Confirmation', subject: 'Your booking is confirmed! #{{bookingId}}', status: 'active' },
    { name: 'Cancellation Notice', subject: 'Booking #{{bookingId}} has been cancelled', status: 'active' },
    { name: 'Welcome Email', subject: 'Welcome to {{platformName}}!', status: 'active' },
    { name: 'Payment Receipt', subject: 'Receipt for booking #{{bookingId}}', status: 'active' },
    { name: 'Review Request', subject: 'How was your stay at {{hotelName}}?', status: 'active' },
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Mail className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            SMTP Configuration
          </CardTitle>
          <CardDescription>Configure outgoing email server settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>SMTP Host</Label>
              <Input value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>SMTP Port</Label>
              <Input value={smtpPort} onChange={(e) => setSmtpPort(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Username</Label>
              <Input value={smtpUser} onChange={(e) => setSmtpUser(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" value={smtpPass} onChange={(e) => setSmtpPass(e.target.value)} />
            </div>
          </div>
          <Button onClick={async () => {
            setSavingSmtp(true);
            await saveSettingsToDb({
              smtp_host: smtpHost,
              smtp_port: smtpPort,
              smtp_user: smtpUser,
              smtp_pass: smtpPass,
            }, 'SMTP settings');
            setSavingSmtp(false);
          }} disabled={savingSmtp} className="bg-teal-600 hover:bg-teal-700 gap-2">
            {savingSmtp ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save SMTP Settings
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Email Templates</CardTitle>
          <CardDescription>Manage system email templates</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Template</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {emailTemplates.map((t, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{t.name}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{t.subject}</TableCell>
                  <TableCell className="text-center">
                    <Badge className="bg-emerald-600 hover:bg-emerald-700">Active</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// --- SMS Tab ---
function SMSTab() {
  const [provider, setProvider] = useState('twilio');
  const [apiKey, setApiKey] = useState('');
  const [senderId, setSenderId] = useState('');
  const [savingSms, setSavingSms] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadSettingsFromDb();
      if (s.sms_provider) setProvider(s.sms_provider);
      if (s.sms_sender_id) setSenderId(s.sms_sender_id);
      // Don't load API key back for security
    })();
  }, []);

  const smsTemplates = [
    { name: 'Booking OTP', message: 'Your OTP for booking #{{bookingId}} is {{otp}}. Valid for 5 mins.', status: 'active' },
    { name: 'Check-in Reminder', message: 'Reminder: Your check-in at {{hotelName}} is tomorrow at {{checkInTime}}.', status: 'active' },
    { name: 'Booking Cancelled', message: 'Your booking #{{bookingId}} has been cancelled. Refund will be processed within 5-7 days.', status: 'active' },
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <MessageSquare className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            SMS Provider Settings
          </CardTitle>
          <CardDescription>Configure SMS delivery provider</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Provider</Label>
              <Select value={provider} onValueChange={setProvider}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="twilio">Twilio</SelectItem>
                  <SelectItem value="msg91">MSG91</SelectItem>
                  <SelectItem value="smsgupshup">SMSGupshup</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sender ID</Label>
              <Input value={senderId} onChange={(e) => setSenderId(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>API Key</Label>
            <Input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} />
          </div>
          <Button onClick={async () => {
            setSavingSms(true);
            await saveSettingsToDb({
              sms_provider: provider,
              sms_api_key: apiKey,
              sms_sender_id: senderId,
            }, 'SMS settings');
            setSavingSms(false);
          }} disabled={savingSms} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            {savingSms ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save SMS Settings
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">SMS Templates</CardTitle>
          <CardDescription>Manage SMS message templates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {smsTemplates.map((t, i) => (
              <div key={i} className="p-4 border rounded-lg space-y-1">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-sm">{t.name}</p>
                  <Badge className="bg-emerald-600 hover:bg-emerald-700">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{t.message}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Security Tab ---
function SecurityTab() {
  const [minPasswordLen, setMinPasswordLen] = useState([8]);
  const [requireUppercase, setRequireUppercase] = useState(true);
  const [requireNumbers, setRequireNumbers] = useState(true);
  const [requireSpecial, setRequireSpecial] = useState(false);
  const [enforce2FA, setEnforce2FA] = useState(false);
  const [sessionTimeout, setSessionTimeout] = useState('30');
  const [rateLimit, setRateLimit] = useState('100');
  const [rateWindow, setRateWindow] = useState('15');
  const [savingSecurity, setSavingSecurity] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadSettingsFromDb();
      if (s.min_password_len) setMinPasswordLen([parseInt(s.min_password_len)]);
      if (s.require_uppercase === 'false') setRequireUppercase(false);
      if (s.require_numbers === 'false') setRequireNumbers(false);
      if (s.require_special === 'true') setRequireSpecial(true);
      if (s.enforce_2fa === 'true') setEnforce2FA(true);
      if (s.session_timeout) setSessionTimeout(s.session_timeout);
      if (s.rate_limit) setRateLimit(s.rate_limit);
      if (s.rate_window) setRateWindow(s.rate_window);
    })();
  }, []);

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Lock className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            Password Policy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Minimum Password Length: <strong className="text-emerald-600 dark:text-emerald-400">{minPasswordLen[0]}</strong></Label>
            <Slider value={minPasswordLen} onValueChange={setMinPasswordLen} min={6} max={20} step={1} />
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium text-sm">Require Uppercase Letters</p>
                <p className="text-xs text-muted-foreground">At least one uppercase character</p>
              </div>
              <Switch checked={requireUppercase} onCheckedChange={setRequireUppercase} />
            </div>
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium text-sm">Require Numbers</p>
                <p className="text-xs text-muted-foreground">At least one numeric digit</p>
              </div>
              <Switch checked={requireNumbers} onCheckedChange={setRequireNumbers} />
            </div>
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium text-sm">Require Special Characters</p>
                <p className="text-xs text-muted-foreground">At least one special character (!@#$%...)</p>
              </div>
              <Switch checked={requireSpecial} onCheckedChange={setRequireSpecial} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            Two-Factor Authentication
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Enforce 2FA for All Users</p>
              <p className="text-sm text-muted-foreground">Require two-factor authentication for every account</p>
            </div>
            <Switch checked={enforce2FA} onCheckedChange={setEnforce2FA} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Session & Rate Limiting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Session Timeout (minutes)</Label>
              <Input type="number" value={sessionTimeout} onChange={(e) => setSessionTimeout(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Rate Limit (requests)</Label>
              <Input type="number" value={rateLimit} onChange={(e) => setRateLimit(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Rate Limit Window (minutes)</Label>
            <Input type="number" value={rateWindow} onChange={(e) => setRateWindow(e.target.value)} />
          </div>
          <Button onClick={async () => {
            setSavingSecurity(true);
            await saveSettingsToDb({
              min_password_len: String(minPasswordLen[0]),
              require_uppercase: String(requireUppercase),
              require_numbers: String(requireNumbers),
              require_special: String(requireSpecial),
              enforce_2fa: String(enforce2FA),
              session_timeout: sessionTimeout,
              rate_limit: rateLimit,
              rate_window: rateWindow,
            }, 'Security settings');
            setSavingSecurity(false);
          }} disabled={savingSecurity} className="bg-teal-600 hover:bg-teal-700 gap-2">
            {savingSecurity ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save Security Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Main Component ---
export default function SettingsView() {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <div className="flex flex-col h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Platform Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Manage platform configuration, policies, and integrations</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className="bg-muted/50 mb-6 flex-wrap h-auto gap-1">
          <TabsTrigger value="general" className="gap-2">
            <Settings className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="tax" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Tax
          </TabsTrigger>
          <TabsTrigger value="commission" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Commission
          </TabsTrigger>
          <TabsTrigger value="payments" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Payments
          </TabsTrigger>
          <TabsTrigger value="email" className="gap-2">
            <Mail className="h-4 w-4" />
            Email
          </TabsTrigger>
          <TabsTrigger value="sms" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            SMS
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <Users className="h-4 w-4" />
            Users
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-0">
          {GeneralTab()}
        </TabsContent>
        <TabsContent value="tax" className="mt-0">
          {TaxTab()}
        </TabsContent>
        <TabsContent value="commission" className="mt-0">
          {CommissionTab()}
        </TabsContent>
        <TabsContent value="payments" className="mt-0">
          {PaymentsTab()}
        </TabsContent>
        <TabsContent value="email" className="mt-0">
          {EmailTab()}
        </TabsContent>
        <TabsContent value="sms" className="mt-0">
          {SMSTab()}
        </TabsContent>
        <TabsContent value="security" className="mt-0">
          {SecurityTab()}
        </TabsContent>
        <TabsContent value="users" className="mt-0">
          {UsersTab()}
        </TabsContent>
      </Tabs>
    </div>
  );
}

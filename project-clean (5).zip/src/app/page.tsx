'use client';

import { useAppStore } from '@/lib/store';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { TooltipProvider } from '@/components/ui/tooltip';

// Auth
import LoginPage from '@/components/auth/LoginPage';

// Layout
import AdminSidebar from '@/components/layout/AdminSidebar';
import PartnerSidebar from '@/components/layout/PartnerSidebar';
import Header from '@/components/layout/Header';

// Admin Views
import AdminDashboard from '@/components/dashboard/AdminDashboard';
import HotelManagement from '@/components/hotels/HotelManagement';
import HotelDetails from '@/components/hotels/HotelDetails';
import HotelRegistration from '@/components/hotels/HotelRegistration';
import RoomInventory from '@/components/rooms/RoomInventory';
import RateManagement from '@/components/rooms/RateManagement';
import BookingManagement from '@/components/bookings/BookingManagement';
import CustomerManagement from '@/components/customers/CustomerManagement';
import ReportsView from '@/components/reports/ReportsView';
import CMSView from '@/components/cms/CMSView';
import NotificationsView from '@/components/notifications/NotificationsView';
import SettingsView from '@/components/settings/SettingsView';
import BookingEngine from '@/components/bookings/BookingEngine';

// Partner Views
import PartnerDashboard from '@/components/partner/PartnerDashboard';
import PartnerRooms from '@/components/partner/PartnerRooms';
import PartnerInventory from '@/components/partner/PartnerInventory';
import PartnerPricing from '@/components/partner/PartnerPricing';
import PartnerBookings from '@/components/partner/PartnerBookings';
import PartnerGuests from '@/components/partner/PartnerGuests';
import PartnerGallery from '@/components/partner/PartnerGallery';
import PartnerPromotions from '@/components/partner/PartnerPromotions';
import PartnerReviews from '@/components/partner/PartnerReviews';
import PartnerFinancials from '@/components/partner/PartnerFinancials';
import PartnerNotifications from '@/components/partner/PartnerNotifications';
import PartnerSettings from '@/components/partner/PartnerSettings';

import type { ViewType } from '@/lib/types';

const ADMIN_VIEWS: ViewType[] = [
  'admin-dashboard', 'hotel-management', 'hotel-details',
  'admin-register-hotel',
  'room-inventory', 'rate-management', 'booking-management',
  'customer-management', 'reports', 'cms', 'notifications',
  'settings', 'booking-engine',
];

function isAdminView(view: ViewType): boolean {
  return ADMIN_VIEWS.includes(view);
}

function isAdminRole(role: string): boolean {
  return ['super_admin', 'sub_admin', 'finance', 'support'].includes(role);
}

function renderView(view: ViewType) {
  switch (view) {
    // Admin views
    case 'admin-dashboard': return <AdminDashboard />;
    case 'hotel-management': return <HotelManagement />;
    case 'hotel-details': return <HotelDetails />;
    case 'room-inventory': return <RoomInventory />;
    case 'rate-management': return <RateManagement />;
    case 'booking-management': return <BookingManagement />;
    case 'customer-management': return <CustomerManagement />;
    case 'reports': return <ReportsView />;
    case 'cms': return <CMSView />;
    case 'notifications': return <NotificationsView />;
    case 'settings': return <SettingsView />;
    case 'admin-register-hotel': return <HotelRegistration />;
    case 'booking-engine': return <BookingEngine />;
    // Partner views
    case 'partner-dashboard': return <PartnerDashboard />;
    case 'partner-rooms': return <PartnerRooms />;
    case 'partner-inventory': return <PartnerInventory />;
    case 'partner-pricing': return <PartnerPricing />;
    case 'partner-bookings': return <PartnerBookings />;
    case 'partner-guests': return <PartnerGuests />;
    case 'partner-gallery': return <PartnerGallery />;
    case 'partner-promotions': return <PartnerPromotions />;
    case 'partner-reviews': return <PartnerReviews />;
    case 'partner-financials': return <PartnerFinancials />;
    case 'partner-notifications': return <PartnerNotifications />;
    case 'partner-settings': return <PartnerSettings />;
    default: return <AdminDashboard />;
  }
}

export default function Home() {
  const { isAuthenticated, user, currentView, sidebarOpen } = useAppStore();
  const [mounted, setMounted] = useState(() => false);
  // Suppress hydration warning - this only runs on client
  const requestMount = () => {
    requestAnimationFrame(() => setMounted(true));
  };
  useEffect(requestMount, []);

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading REVYORA HOSPITALITY...</p>
        </div>
      </div>
    );
  }

  // Login page
  if (!isAuthenticated || currentView === 'login') {
    return (
      <TooltipProvider>
        <AnimatePresence mode="wait">
          <motion.div
            key="login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <LoginPage />
          </motion.div>
        </AnimatePresence>
      </TooltipProvider>
    );
  }

  // Booking engine - full page without sidebar
  if (currentView === 'booking-engine') {
    return (
      <TooltipProvider>
        <Header />
        <main className="min-h-[calc(100vh-4rem)]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderView(currentView)}
            </motion.div>
          </AnimatePresence>
        </main>
      </TooltipProvider>
    );
  }

  // Admin or Partner dashboard layout
  const isPartner = user && !isAdminRole(user.role);
  const Sidebar = isPartner ? PartnerSidebar : AdminSidebar;

  return (
    <TooltipProvider>
      <div className="min-h-screen flex bg-background">
        {/* Sidebar - desktop */}
        <div className={
          `hidden lg:flex flex-col border-r border-border bg-card transition-all duration-300 ` +
          (sidebarOpen ? 'w-64' : 'w-[72px]')
        }>
          <Sidebar />
        </div>

        {/* Sidebar - mobile overlay */}
        <AnimatePresence>
          {sidebarOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black z-40 lg:hidden"
                onClick={() => useAppStore.getState().setSidebarOpen(false)}
              />
              <motion.div
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                className="fixed left-0 top-0 bottom-0 w-72 z-50 lg:hidden"
              >
                <div className="h-full bg-card border-r border-border">
                  <Sidebar />
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Main content */}
        <div className="flex-1 flex flex-col min-w-0">
          <Header />
          <main className="flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentView}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="p-4 md:p-6"
              >
                {renderView(currentView)}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}

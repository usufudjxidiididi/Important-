import { NextResponse } from 'next/server';
import { supabase, toCamelArr } from '@/lib/supabase';

export async function GET() {
  try {
    if (!supabase) {
      return NextResponse.json([]);
    }

    const { data, error } = await supabase
      .from('coupons')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;

    return NextResponse.json(toCamelArr(data || []));
  } catch (error) {
    console.error('Coupons error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

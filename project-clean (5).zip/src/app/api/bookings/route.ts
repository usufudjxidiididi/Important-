import { NextRequest, NextResponse } from 'next/server';
import { supabase, toCamel, toCamelArr, toSnake } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const hotelId = searchParams.get('hotelId');
    const search = searchParams.get('search');

    let query = supabase
      .from('bookings')
      .select('*, hotels(id, name)')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    if (hotelId) {
      query = query.eq('hotel_id', hotelId);
    }

    if (search) {
      query = query.or(
        `customer_name.ilike.%${search}%,customer_email.ilike.%${search}%,booking_number.ilike.%${search}%`
      );
    }

    const { data, error } = await query;

    if (error) {
      console.error('Bookings list error:', error);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    return NextResponse.json(toCamelArr(data || []));
  } catch (error) {
    console.error('Bookings list error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    if (!supabase) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }
    const body = await request.json();
    const { id, status, notes } = body;

    if (!id) {
      return NextResponse.json({ error: 'Booking id is required' }, { status: 400 });
    }

    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status;
    if (notes !== undefined) updateData.notes = notes;

    const { data, error } = await supabase
      .from('bookings')
      .update(toSnake(updateData))
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Booking update error:', error);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }

    return NextResponse.json(toCamel(data));
  } catch (error) {
    console.error('Booking update error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

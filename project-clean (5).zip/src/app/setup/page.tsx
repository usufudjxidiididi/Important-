'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Building2, CheckCircle2, AlertTriangle, Loader2, Database } from 'lucide-react';

interface SetupStatus {
  success: boolean;
  results: { column: string; status: string; detail?: string }[];
  needs_manual_sql: boolean;
  user_count: number;
  sql_to_run: string | null;
}

export default function SetupPage() {
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string; error?: string } | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    fetch('/api/setup')
      .then(r => r.json())
      .then(data => {
        setStatus(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setResult(null);

    try {
      const res = await fetch('/api/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      setResult(data);
      if (data.success) {
        // Refresh status
        const statusRes = await fetch('/api/setup');
        const statusData = await statusRes.json();
        setStatus(statusData);
      }
    } catch {
      setResult({ success: false, error: 'Failed to connect to server' });
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFBFC]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const dbOk = status?.success;
  const hasUsers = (status?.user_count || 0) > 0;
  const needsSql = status?.needs_manual_sql;

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#FAFBFC]">
      <div className="w-full max-w-lg">
        {/* Logo */}
        <div className="flex items-center gap-2.5 justify-center mb-8">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <Building2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">
            REVYORA <span className="text-primary">HOSPITALITY</span>
          </span>
        </div>

        <Card className="shadow-xl shadow-black/5">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-2xl font-bold">Initial Setup</CardTitle>
            <CardDescription>
              Create your admin account to get started
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4 space-y-6">
            {/* Database Status */}
            <div className="rounded-lg border p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Database className="h-4 w-4" />
                Database Status
              </div>

              {!dbOk ? (
                <div className="flex items-start gap-2 text-sm text-destructive">
                  <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                  <span>Database not configured. Check your Supabase environment variables.</span>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    Connected to Supabase
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    Users in database: <strong>{status?.user_count || 0}</strong>
                  </div>
                  {needsSql && (
                    <div className="rounded-md bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
                      <p className="font-medium mb-1">Action needed:</p>
                      <code className="text-xs bg-amber-100 px-2 py-1 rounded block overflow-x-auto">
                        {status?.sql_to_run}
                      </code>
                      <p className="mt-1 text-xs">Run this in Supabase SQL Editor</p>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Create Admin Form */}
            {dbOk && !hasUsers && !result?.success && (
              <form onSubmit={handleCreateAdmin} className="space-y-4">
                <div className="text-sm text-muted-foreground text-center">
                  No users found. Create your super admin account:
                </div>
                <div className="space-y-2">
                  <Label htmlFor="setup-name">Full Name</Label>
                  <Input
                    id="setup-name"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Admin Name"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="setup-email">Email</Label>
                  <Input
                    id="setup-email"
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="admin@revyora.com"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="setup-password">Password</Label>
                  <Input
                    id="setup-password"
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Create a strong password"
                    required
                    minLength={4}
                  />
                </div>
                <Button
                  type="submit"
                  disabled={creating || !name || !email || !password}
                  className="w-full"
                >
                  {creating ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Creating...
                    </span>
                  ) : (
                    'Create Admin Account'
                  )}
                </Button>
              </form>
            )}

            {/* Result Messages */}
            {result?.success && (
              <div className="rounded-lg bg-green-50 border border-green-200 p-4 text-center space-y-3">
                <CheckCircle2 className="h-10 w-10 text-green-500 mx-auto" />
                <div>
                  <p className="font-medium text-green-800">Admin account created!</p>
                  <p className="text-sm text-green-600 mt-1">You can now log in from the main page.</p>
                </div>
                <Button
                  onClick={() => window.location.href = '/'}
                  className="mt-2"
                >
                  Go to Login
                </Button>
              </div>
            )}

            {result?.error && (
              <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-sm text-red-700">
                {result.error}
              </div>
            )}

            {hasUsers && (
              <div className="text-center space-y-3">
                <CheckCircle2 className="h-10 w-10 text-green-500 mx-auto" />
                <p className="text-sm text-muted-foreground">
                  Setup complete! {status?.user_count} user(s) exist.
                </p>
                <Button onClick={() => window.location.href = '/'}>
                  Go to Login
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} REVYORA HOSPITALITY
        </p>
      </div>
    </div>
  );
}
